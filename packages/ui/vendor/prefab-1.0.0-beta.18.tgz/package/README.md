# 🧰 Prefab

Prefab - Prefabricated React Components to build your UI!

## About
Library containing the set of common components in the Qube Design System. 
Note: This is still in a very early stage of development and so there might not be a lot of components.
For theme-ing support, can override the default sass variables and so need to ensure a sass compiler when using this library.

## Install

```bash
npm install git+https://{CI-USER-TOKEN}:x-oauth-basic@github.com/RealImage/prefab-ui.git#{tag or commit-ish}
```

## Available Scripts

  

In the project directory, you can run:

  

### `npm run build`

  

Using Rollup Pkg we will build the output to the build folder.<br>

The configurations can be found in root directory `rollup.config.js`

  

### `npm start`

  

The rollup will be running in watch mode and builds the changes when any changes are added<br>

The configurations can be found in root directory `rollup.config.js`

  

### `npm run storybook`

  

Storybook should start, on a 6006 port in dev-mode.

  

### `npm run build-storybook`

  

This will build the storybook configured in the Storybook directory into a static web app and place it inside the `storybook-static` directory. Now you can deploy the content in the `storybook-static` directory wherever you want.

  

### `npm run deploy-storybook`

  

- This will build the storybook configured in the Storybook directory into a static web app and place it inside the `storybook-static` directory and deploys the changes to the S3 bucket.

- This uses the `deploy.js` script to upload the build files.

- We need to export the `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN` variables before proceeding the deployment locally

### `npm test`

- This will run the unit test cases for the components and utility functions

### `npm run test:watch`

- This will run the unit test cases for the components and utility functions in watch mode.
- The advantage using the script is, it will update the snapshots and run test cases for each changes.


### `npm run lint`

- The linting script for the js and it uses the Eslint library


### `npm run format`

- The script uses the prettier to format the code spaces and alignments.

### `npm run check_formatting`

- The script validates code format and list the errors after the execution.


### `npm run stylelint`

- The script is for the linting the styles and all the errors will listed after the execution.

Note:

- Since this repo is private, installing this will require a GitHub PAT. Get the token created from the CI User's account and not from your own account.
- The version number in the url (after the #) at the end can be [any tag or commit-ish](https://docs.npmjs.com/files/package.json#git-urls-as-dependencies) in the repo or can be skipped altogether as well.
- However, this isn't recommended since not pinning the dependency to a release tag on master, can possibly cause unnecessary and/or breaking changes. [Please check here for the latest release tag.](https://github.com/RealImage/prefab-ui/releases/latest)
- For upgrading, use the version number in package.json on master branch, and use that version as tag.
- Can install using yarn as well, nothing special about any particular package manager in this regard.
