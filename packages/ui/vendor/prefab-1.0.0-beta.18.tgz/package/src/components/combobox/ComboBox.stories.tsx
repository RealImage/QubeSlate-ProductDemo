import { useCallback, useEffect, useState } from "react";
import { Button } from "../button/Button";
import { ChevronDownIcon, LoaderSimpleIcon, SearchIcon } from "../../assets/icon";
import { Tag } from "../tag/Tag";
import { ComboBox, type Key } from "./ComboBox";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/ComboBox",
  component: ComboBox,
  parameters: { layout: "centered" },
  args: {
    label: "Select Item",
    placeholder: "Select Item",
    maxHeight: 200,
  },
  decorators: [
    (Story) => (
      <div style={{ width: "min(320px, 70vw)", minHeight: "10rem" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => (
    <ComboBox {...props} label="Select Item" placeholder="Select Item">
      {Array.from({ length: 10 }, (_, i) => (
        <ComboBox.Item key={i} id={i + 1} textValue={`Item ${i + 1}`}>
          Item {i + 1}
        </ComboBox.Item>
      ))}
    </ComboBox>
  ),
});

export const Controlled = meta.story({
  render: function Render(props) {
    const [value, setValue] = useState(8);
    const items = Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      textValue: `Item ${i + 1}`,
    }));
    const currentItemTextValue = items.find((i) => i.id === value)?.textValue;
    return (
      <>
        <ComboBox
          {...props}
          selectionMode="single"
          value={value}
          onChange={(v) => setValue(Number(v))}
        >
          {items.map((item) => (
            <ComboBox.Item key={item.id} id={item.id} textValue={item.textValue}>
              {item.textValue}
            </ComboBox.Item>
          ))}
        </ComboBox>
        <output style={{ display: "flex", fontSize: "0.75rem", margin: "4px 0", lineHeight: 1.5 }}>
          Selected ID: {value} <br />
          {currentItemTextValue && <>(Text Value: {currentItemTextValue})</>}
        </output>
      </>
    );
  },
});

export const CustomSelection = meta.story({
  render: function Render(props) {
    const [selectedItems, setSelectedItems] = useState<{ id: Key; name: string }[]>([
      { id: 2, name: "Item 2" },
      { id: 4, name: "Item 4" },
    ]);
    const items = Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      name: `Item ${i + 1}`,
    }));
    return (
      <>
        <ComboBox {...props} selectionMode="multiple" value={selectedItems.map((i) => i.id)}>
          {items.map((item) => (
            <ComboBox.Item
              key={item.id}
              id={item.id}
              textValue={item.name}
              onClick={() =>
                setSelectedItems((prev) => {
                  const exists = prev.some((i) => i.id === item.id);
                  if (exists) return prev.filter((i) => i.id !== item.id);
                  return [...prev, item];
                })
              }
            >
              {item.name}
            </ComboBox.Item>
          ))}
        </ComboBox>
        <output style={{ display: "flex", fontSize: "0.75rem", margin: "4px 0", lineHeight: 1.5 }}>
          {selectedItems.map((i) => i.name).join(", ") || "No items selected"}
          <span
            role="button"
            onClick={() => setSelectedItems([])}
            style={{ marginLeft: "8px", color: "#007bff", cursor: "pointer" }}
          >
            Clear
          </span>
        </output>
      </>
    );
  },
});

export const MultipleSelection = meta.story({
  args: {
    selectionMode: "multiple",
  },
  render: (props) => (
    <ComboBox
      {...props}
      renderSelectedItems={({ state }) =>
        state.selectedItems.map((item) => (
          <Tag key={item.key} onClose={() => state.selectionManager.select(item.key)}>
            {item.textValue}
          </Tag>
        ))
      }
    >
      {Array.from({ length: 10 }, (_, i) => (
        <ComboBox.Item key={i} id={i + 1} textValue={`Item ${i + 1}`}>
          Item {i + 1}
        </ComboBox.Item>
      ))}
    </ComboBox>
  ),
});

export const CustomPrefixAndSuffixIcon = meta.story({
  render: (props) => (
    <ComboBox {...props} prefix={<SearchIcon />} suffix={<ChevronDownIcon />}>
      {Array.from({ length: 10 }, (_, i) => (
        <ComboBox.Item key={i} id={i + 1} textValue={`Item ${i + 1}`}>
          Item {i + 1}
        </ComboBox.Item>
      ))}
    </ComboBox>
  ),
});

export const MultipleLineOptions = meta.story({
  render: (props) => (
    <ComboBox {...props}>
      <ComboBox.Item id="1" textValue="Option 1">
        <div>
          <div>Option 1</div>
          <div style={{ color: "#6A6A6A" }}>This is a description</div>
        </div>
      </ComboBox.Item>
      <ComboBox.Item id="2" textValue="Option 2">
        <div>
          <div>Option 2</div>
          <div style={{ color: "#6A6A6A" }}>This is a longer description</div>
        </div>
      </ComboBox.Item>
      <ComboBox.Item id="3" textValue="Option 3">
        <div>
          <div>Option 3</div>
          <div style={{ color: "#6A6A6A" }}>This is a longer description</div>
        </div>
      </ComboBox.Item>
    </ComboBox>
  ),
});

export const AsyncComboBox = meta.story({
  render: function Render() {
    const [value, setValue] = useState<string | null>(null);
    const [data, setData] = useState<{
      items: string[] | undefined;
      isLoading: boolean;
      page: number;
    }>({
      items: undefined,
      isLoading: false,
      page: 1,
    });

    const simulateFetch = useCallback(() => {
      setData((prev) => ({ ...prev, isLoading: true }));
      setTimeout(() => {
        setData((prev) => ({
          ...prev,
          items: Array.from({ length: prev.page * 20 }, (_, i) => `Item ${i + 1}`),
          page: prev.page + 1,
          isLoading: false,
        }));
      }, 1000);
    }, []);

    useEffect(() => {
      simulateFetch();
    }, [simulateFetch]);

    const loadMore = () => {
      if (data.page > 10 || data.isLoading) return;
      simulateFetch();
    };

    return (
      <ComboBox
        label="Select Item"
        placeholder="Select an item"
        value={value}
        onChange={(value) => setValue(value ? value.toString() : null)}
        isLoading={!data.items && data.isLoading}
        maxHeight={200}
      >
        {data.items?.map((item) => (
          <ComboBox.Item key={item} id={item}>
            {item}
          </ComboBox.Item>
        ))}
        <ComboBox.LoadMore
          isLoading={!!data.items && data.isLoading}
          onLoadMore={loadMore}
          scrollOffset={1}
        >
          <LoaderSimpleIcon color="#677a90" strokeWidth={2} style={{ margin: "auto" }} />
        </ComboBox.LoadMore>
      </ComboBox>
    );
  },
});

export const WithSectionsAndFooter = meta.story({
  args: {
    selectionMode: "multiple",
  },
  render: (props) => (
    <ComboBox
      {...props}
      label="Select Versions"
      placeholder="Select versions"
      footer={(state) => (
        <Button
          size="small"
          variant="secondary"
          style={{ margin: "0.5rem 0.375rem 0.5rem auto" }}
          onClick={() => state?.selectionManager.clearSelection()}
        >
          Clear Selection
        </Button>
      )}
      renderSelectedItems={({ state }) =>
        state.selectedItems.map((item) => (
          <Tag key={item.key} onClose={() => state.selectionManager.select(item.key)}>
            {item.textValue}
          </Tag>
        ))
      }
    >
      <ComboBox.Section title="Active" id="active">
        {Array.from({ length: 2 }, (_, i) => (
          <ComboBox.Item
            key={i}
            id={`v${i + 1}.0.0`}
            textValue={`v${i + 1}.0.0`}
            indicator="checkbox"
          >
            v{i + 1}.0.0
          </ComboBox.Item>
        ))}
      </ComboBox.Section>
      <ComboBox.Section title="Deprecated" defaultCollapsed collapsible showCheckbox>
        {Array.from({ length: 5 }, (_, i) => (
          <ComboBox.Item key={i} id={`v0.0.${i}`} indicator="checkbox" textValue={`v0.0.${i}`}>
            v0.0.{i}
            <Tag size="small" variant="negative" style={{ borderRadius: "4px" }}>
              Deprecated
            </Tag>
          </ComboBox.Item>
        ))}
      </ComboBox.Section>
    </ComboBox>
  ),
});
