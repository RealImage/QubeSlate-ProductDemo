import { useContext, useId, useLayoutEffect, useRef, useState } from "react";
import {
  Button as AriaButton,
  ComboBox as AriaComboBox,
  ComboBoxStateContext,
  ComboBoxValue,
  composeRenderProps,
  Group,
  Header,
  Input,
  Popover,
  ListBox,
  ListBoxItem,
  ListBoxLoadMoreItem,
  ListBoxSection,
  Text,
  type ComboBoxProps as AriaComboBoxProps,
  type ComboBoxValueProps,
  type ListBoxItemProps,
  type ListBoxLoadMoreItemProps,
  type ListBoxSectionProps,
  type Key,
  type ComboBoxState,
} from "react-aria-components";
import cx from "classnames";
import {
  CancelIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  ConfirmIcon,
  LoaderSimpleIcon,
  SearchIcon,
} from "../../assets/icon";
import { FieldLabel, FieldError, FieldHint } from "../field/Field";
import { Checkbox } from "../checkbox/Checkbox";

type ComboBoxSlotContent<T extends object, M extends "single" | "multiple"> =
  | React.ReactNode
  | ((state: ComboBoxState<T, M> | null) => React.ReactNode);

export type ComboBoxProps<T extends object, M extends "single" | "multiple"> = {
  label?: string;
  optional?: boolean;
  description?: string | null;
  errorMessage?: React.ReactNode;
  children?: React.ReactNode | ((item: T) => React.ReactNode);
  placeholder?: string;
  popoverClassName?: string;
  placement?: "top" | "bottom";
  maxHeight?: number;
  /** Offset between the Select Input and the Options Dropdown. @default 4 */
  offset?: number;
  /** Whether to show the info icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Custom content for the empty state. Defaults to "No items found". */
  emptyState?: React.ReactNode;
  /** Custom Prefix element to be shown inside the input. */
  prefix?: React.ReactNode;
  /** Custom Suffix element to be shown inside the input. */
  suffix?: React.ReactNode;
  /** Whether to show the clear button when there is a value. @default true */
  allowClear?: boolean;
  /** Callback function to be called when the clear button is clicked. */
  onClear?: () => void;
  /** Position of the clear button. @default "replace-suffix" */
  clearPosition?: "replace-suffix" | "separate";
  /** Show a loading spinner in place of the trigger icon. */
  isLoading?: boolean;
  /**
   * Disable react-aria's built-in default filter function.
   * Useful for async/server-side filtering where items are already filtered externally.
   * @default false
   */
  disableFilter?: boolean;
  /** Custom content to render inside the popover header. Accepts either a ReactNode or a render function. */
  header?: ComboBoxSlotContent<T, M>;
  /** Custom content to render inside the popover footer. Accepts either a ReactNode or a render function. */
  footer?: ComboBoxSlotContent<T, M>;
  /** Custom render function for the selected value in multiple selection mode. */
  renderSelectedItems?: ComboBoxValueProps<T>["children"];
  /** Custom content for the loading state. Defaults to a spinner. */
  loadingState?: React.ReactNode;
} & Omit<AriaComboBoxProps<T, M>, "children">;

function ComboBox<T extends object, M extends "single" | "multiple" = "single">({
  label,
  isInvalid,
  optional,
  description,
  errorMessage,
  children,
  placeholder,
  showHintIcon = true,
  className,
  popoverClassName,
  placement = "bottom",
  menuTrigger = "focus",
  offset = 4,
  maxHeight = 300,
  suffix,
  allowClear,
  clearPosition,
  isLoading,
  prefix,
  disableFilter,
  defaultFilter,
  header,
  footer,
  renderSelectedItems,
  emptyState,
  loadingState,
  onClear,
  ...props
}: ComboBoxProps<T, M>) {
  const isFieldInvalid = isInvalid || !!errorMessage;

  const triggerRef = useRef<HTMLDivElement>(null);
  const [triggerWidth, setTriggerWidth] = useState(0);

  useLayoutEffect(() => {
    const el = triggerRef.current;
    if (!el) return;
    const observer = new ResizeObserver(([entry]) => {
      const inlineSize =
        entry.borderBoxSize?.[0]?.inlineSize ?? entry.target.getBoundingClientRect().width;
      setTriggerWidth(inlineSize);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const renderEmptyState = () => (
    <div className="pf-combobox-empty-state">
      {isLoading
        ? (loadingState ?? (
            <LoaderSimpleIcon className="pf-combobox-empty-state__loader" aria-label="Loading" />
          ))
        : emptyState}
    </div>
  );

  return (
    <AriaComboBox
      isInvalid={isFieldInvalid}
      className={cx("pf-combobox", className)}
      menuTrigger={menuTrigger}
      allowsEmptyCollection={isLoading || !!emptyState}
      defaultFilter={disableFilter ? () => true : defaultFilter}
      {...props}
    >
      {label && <FieldLabel optional={optional}>{label}</FieldLabel>}
      <ComboBoxInput
        placeholder={placeholder ?? label}
        triggerRef={triggerRef}
        prefix={prefix}
        suffix={suffix}
        allowClear={allowClear}
        clearPosition={clearPosition}
        onClear={onClear}
      />
      {renderSelectedItems && (
        <ComboBoxValue className="pf-combobox__value">{renderSelectedItems}</ComboBoxValue>
      )}
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
      <Popover
        className={cx("pf-combobox-popover", popoverClassName)}
        placement={placement}
        offset={offset}
        triggerRef={triggerRef}
        maxHeight={maxHeight}
        style={{ "--combobox-trigger-width": `${triggerWidth}px` } as React.CSSProperties}
      >
        {header && <ComboBoxSlot content={header} />}
        <ListBox
          orientation="vertical"
          className="pf-combobox-items"
          renderEmptyState={renderEmptyState}
        >
          {children}
        </ListBox>
        {footer && <ComboBoxSlot content={footer} />}
      </Popover>
    </AriaComboBox>
  );
}

function ComboBoxSlot<T extends object, M extends "single" | "multiple">({
  content,
}: {
  content: ComboBoxSlotContent<T, M>;
}) {
  const state = useContext(ComboBoxStateContext);
  return (
    <div className="pf-combobox-slot">
      {typeof content === "function" ? content(state) : content}
    </div>
  );
}

type ComboBoxInputProps = {
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  allowClear?: boolean;
  placeholder?: string;
  triggerRef?: React.RefObject<HTMLDivElement>;
  clearPosition?: "replace-suffix" | "separate";
  onClear?: () => void;
};

function ComboBoxInput({
  prefix,
  suffix,
  placeholder,
  allowClear = true,
  triggerRef,
  clearPosition = "replace-suffix",
  onClear,
}: ComboBoxInputProps) {
  const state = useContext(ComboBoxStateContext);

  const showClearButton =
    state?.selectionManager.selectionMode === "single"
      ? allowClear && (state?.value || state?.inputValue)
      : allowClear && state?.inputValue;

  const handleClear = () => {
    if (onClear) onClear();
    if (state?.selectionManager.selectionMode === "single") {
      state?.selectionManager.clearSelection();
    }
    state?.setInputValue("");
  };

  return (
    <Group className="pf-combobox-input" ref={triggerRef}>
      {prefix}
      <Input placeholder={placeholder} className="pf-combobox-input__input" />
      {showClearButton ? (
        <button aria-label="Clear" className="pf-combobox-input__button" onClick={handleClear}>
          <CancelIcon aria-hidden="true" />
        </button>
      ) : null}
      {clearPosition === "replace-suffix" && showClearButton ? null : (
        <AriaButton className="pf-combobox-input__button">
          {suffix ?? <SearchIcon aria-hidden="true" />}
        </AriaButton>
      )}
    </Group>
  );
}

type ComboBoxItemProps = {
  indicator?: "default" | "checkbox" | "none";
} & ListBoxItemProps;

function ComboBoxItem({
  className,
  textValue,
  children,
  indicator = "default",
  ...props
}: ComboBoxItemProps) {
  const value = textValue ?? (typeof children === "string" ? children : undefined);

  return (
    <ListBoxItem
      {...props}
      className={cx("pf-combobox-item", `pf-combobox-item--indicator-${indicator}`, className)}
      textValue={value}
    >
      {composeRenderProps(children, (children, renderProps) => (
        <>
          {indicator === "checkbox" && (
            <Checkbox
              isSelected={renderProps.isSelected}
              aria-label="Select item"
              excludeFromTabOrder
            />
          )}
          {typeof children === "string" ? <Text slot="label">{children}</Text> : children}
          {indicator === "default" && renderProps.isSelected && (
            <ConfirmIcon aria-hidden="true" className="pf-combobox-item__icon" />
          )}
        </>
      ))}
    </ListBoxItem>
  );
}

export interface ComboBoxSectionProps<T = object> extends Omit<ListBoxSectionProps<T>, "children"> {
  /** Section title displayed in the header */
  title: string;
  /** Whether the section should start collapsed. @default false */
  defaultCollapsed?: boolean;
  /** Children items in the section */
  children: React.ReactNode;
  /** Whether to show a checkbox in the section header */
  showCheckbox?: boolean;
  /** Whether the section is collapsed */
  collapsible?: boolean;
  showCount?: boolean;
}

function ComboBoxSection<T extends object = object>({
  title,
  defaultCollapsed = false,
  className,
  children,
  collapsible = false,
  showCheckbox = false,
  showCount = true,
  id,
  ...props
}: ComboBoxSectionProps<T>) {
  const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed && collapsible);
  const uniqueId = useId();
  const sectionId = id ?? uniqueId;

  return (
    <ListBoxSection
      id={sectionId}
      className={cx(
        "pf-combobox-section",
        { "pf-combobox-section--collapsed": isCollapsed },
        className,
      )}
      {...props}
    >
      <Header
        className={cx(
          "pf-combobox-section__header",
          collapsible && "pf-combobox-section__header--collapsible",
        )}
      >
        <ComboBoxSectionHeader
          id={sectionId}
          collapsible={collapsible}
          isCollapsed={isCollapsed}
          setIsCollapsed={setIsCollapsed}
          title={title}
          showCount={showCount}
          showCheckbox={showCheckbox}
        />
      </Header>
      {children}
    </ListBoxSection>
  );
}

function ComboBoxSectionHeader({
  id,
  title,
  showCount,
  collapsible,
  isCollapsed,
  setIsCollapsed,
  showCheckbox,
}: {
  id: Key;
  title?: string;
  showCount?: boolean;
  collapsible?: boolean;
  isCollapsed?: boolean;
  setIsCollapsed?: (collapsed: boolean) => void;
  showCheckbox?: boolean;
}) {
  const state = useContext(ComboBoxStateContext);
  const sectionKeys = Array.from(state?.collection.getChildren?.(id) || [])
    .filter((node) => node.type === "item")
    .map((item) => item.key);

  const allSelected =
    sectionKeys.length > 0 && sectionKeys.every((k) => state?.selectionManager.isSelected(k));
  const someSelected =
    !allSelected && sectionKeys.some((k) => state?.selectionManager.isSelected(k));

  const handleToggle = () => {
    const currentValue = Array.from(state?.selectionManager.selectedKeys || []);
    if (allSelected) {
      state?.selectionManager.setSelectedKeys(
        new Set(currentValue.filter((k) => !sectionKeys.includes(k))),
      );
    } else {
      state?.selectionManager.setSelectedKeys(new Set([...currentValue, ...sectionKeys]));
    }
  };

  return (
    <>
      {showCheckbox && (
        <Checkbox
          aria-label={`Select all items in ${title} section`}
          isSelected={allSelected}
          isIndeterminate={!allSelected && someSelected}
          onChange={handleToggle}
        />
      )}
      {collapsible ? (
        <button
          type="button"
          className="pf-combobox-section__toggle"
          onClick={() => setIsCollapsed?.(!isCollapsed)}
          aria-expanded={!isCollapsed}
        >
          <span className="pf-combobox-section__title">
            {title}
            {showCount && ` (${sectionKeys.length})`}
          </span>
          {isCollapsed ? (
            <ChevronDownIcon
              className="pf-combobox-section__chevron"
              viewBox="4 4 16 16"
              width="16"
              height="16"
            />
          ) : (
            <ChevronUpIcon
              className="pf-combobox-section__chevron"
              viewBox="4 4 16 16"
              width="16"
              height="16"
            />
          )}
        </button>
      ) : (
        <span className="pf-combobox-section__title">
          {title}
          {showCount && ` (${sectionKeys.length})`}
        </span>
      )}
    </>
  );
}

function ComboBoxLoadMore({
  className,
  children,
  onLoadMore,
  isLoading,
  scrollOffset,
  ...props
}: ListBoxLoadMoreItemProps) {
  return (
    <ListBoxLoadMoreItem
      className={cx("pf-combobox-loader-state", className)}
      onLoadMore={onLoadMore}
      isLoading={isLoading}
      scrollOffset={scrollOffset}
      {...props}
    >
      {children}
    </ListBoxLoadMoreItem>
  );
}

export type { Key };

ComboBox.Item = ComboBoxItem;
ComboBox.Section = ComboBoxSection;
ComboBox.LoadMore = ComboBoxLoadMore;

export { ComboBox };
