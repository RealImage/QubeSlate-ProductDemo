import {
  DialogTrigger,
  Popover,
  ListBox,
  ListBoxItem,
  SearchField,
  Input as AriaInput,
  Button as AriaButton,
  Autocomplete,
  Text,
  type PopoverProps,
  type ListBoxItemProps,
  type AutocompleteProps,
  composeRenderProps,
  useFilter,
  Group,
} from "react-aria-components";
import cx from "classnames";
import { Button, type ButtonProps } from "../button/Button";
import { Checkbox } from "../checkbox/Checkbox";
import { ChevronDownIcon, SearchIcon, CancelIcon, LoaderSimpleIcon } from "../../assets/icon";
import { FieldLabel } from "@/components/field/Field";

export type FilterSelectorItemProps = Omit<ListBoxItemProps, "children" | "id"> & {
  children: React.ReactNode;
  id?: string;
};

function FilterSelectorItem({ children, className, ...props }: FilterSelectorItemProps) {
  const textValue = props.textValue ?? (typeof children === "string" ? children : undefined);

  return (
    <ListBoxItem
      className={cx("pf-filter-selector__item", className)}
      textValue={textValue}
      {...props}
    >
      {composeRenderProps(children, (children, renderProps) => (
        <>
          <Checkbox
            isSelected={renderProps.isSelected}
            isDisabled={renderProps.isDisabled}
            aria-label={textValue}
            excludeFromTabOrder
          />
          {typeof children === "string" ? <Text slot="label">{children}</Text> : children}
        </>
      ))}
    </ListBoxItem>
  );
}

export type FilterSelectorProps = {
  /** Text shown in the trigger button when nothing is selected. */
  triggerLabel?: React.ReactNode;
  /** Custom trigger icon. */
  triggerIcon?: React.ReactNode;
  className?: string;
  /** Placement of the popover relative to the trigger. @default "bottom left" */
  placement?: PopoverProps["placement"];
  /** Pixel offset between the trigger and the popover. @default 4 */
  offset?: number;
  /** Whether to show the "Clear Selected" footer button. @default true */
  showActionButtons?: boolean;
  /** Currently selected keys. */
  selectedKeys?: Set<string>;
  /** Called when the selection changes. */
  onSelectionChange?: (keys: Set<string>) => void;
  /**
   * Called when "Clear Selected" is pressed.
   * Falls back to `onSelectionChange(new Set())` when omitted.
   */
  onClear?: () => void;
  /** Whether to show a search field. @default false */
  hideSearch?: boolean;
  /** Placeholder for the search input. @default "Search…" */
  searchPlaceholder?: string;
  /** Current value of the search input. */
  inputValue?: string;
  /**
   * Async search handler.
   * When provided, internal Autocomplete filtering is disabled.
   */
  onInputChange?: (query: string) => void;
  /** Called when the search input is cleared. */
  onInputClear?: () => void;
  /** Shows a loading state. */
  isLoading?: boolean;
  /** Custom empty state content. */
  emptyState?: React.ReactNode;
  children?: React.ReactNode;
  /** Disable React Aria's built-in filter function. @default false */
  disableFilter?: boolean;
  filter?: AutocompleteProps["filter"];
  buttonProps?: ButtonProps;
  loadingState?: React.ReactNode;
  count?: number;
  searchLabel?: string;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  maxHeight?: number;
  showFooter?: boolean;
  clearButtonText?: string;
  isDisabled?: boolean;
  style?: React.CSSProperties;
};

function FilterSelector({
  triggerLabel,
  triggerIcon,
  className,
  searchLabel,
  placement = "bottom left",
  offset = 4,
  selectedKeys,
  onSelectionChange,
  onClear,
  hideSearch,
  searchPlaceholder = "Search",
  isDisabled,
  inputValue,
  onInputChange,
  isLoading,
  emptyState,
  children,
  disableFilter,
  filter,
  buttonProps,
  loadingState,
  count,
  header,
  footer,
  clearButtonText = "Clear Selected",
  maxHeight = 250,
  style,
  onInputClear,
}: FilterSelectorProps) {
  const { contains } = useFilter({ sensitivity: "base" });

  const renderEmptyState = () => (
    <div className="pf-filter-selector__empty-state">
      {isLoading
        ? (loadingState ?? (
            <LoaderSimpleIcon className="pf-filter-selector__loader" aria-label="Loading" />
          ))
        : emptyState}
    </div>
  );

  return (
    <DialogTrigger>
      <Button selected={!!count} {...buttonProps} isDisabled={isDisabled}>
        {count ? (
          <span className="pf-filter-selector__trigger">
            <span>{triggerLabel}</span>
            <span className="pf-filter-selector__badge">{count}</span>
          </span>
        ) : (
          triggerLabel
        )}
        {triggerIcon ?? <ChevronDownIcon aria-hidden />}
      </Button>

      <Popover
        placement={placement}
        maxHeight={maxHeight}
        offset={offset}
        className={cx("pf-filter-selector", className)}
        style={style}
      >
        {header}
        <Autocomplete
          inputValue={inputValue}
          onInputChange={onInputChange}
          filter={disableFilter ? () => true : filter ? filter : contains}
        >
          {!hideSearch && (
            <SearchField aria-label="Search" autoFocus className="pf-filter-selector__search-field">
              {({ isEmpty }) => (
                <>
                  {searchLabel && (
                    <FieldLabel className="pf-filter-selector__label">{searchLabel}</FieldLabel>
                  )}
                  <Group className="pf-filter-selector__search">
                    <AriaInput
                      className="pf-filter-selector__input"
                      placeholder={searchPlaceholder}
                    />
                    <AriaButton
                      slot="clear"
                      className="pf-filter-selector__search-clear"
                      onClick={onInputClear}
                    >
                      {isEmpty ? <SearchIcon aria-hidden /> : <CancelIcon aria-hidden />}
                    </AriaButton>
                  </Group>
                </>
              )}
            </SearchField>
          )}
          <ListBox
            selectionMode="multiple"
            selectedKeys={selectedKeys}
            onSelectionChange={(keys) => onSelectionChange?.(new Set(Array.from(keys).map(String)))}
            aria-label="Filter options"
            className="pf-filter-selector__list"
            renderEmptyState={renderEmptyState}
          >
            {children}
          </ListBox>
        </Autocomplete>
        {footer ??
          (typeof onClear === "function" && (
            <div className="pf-filter-selector__footer">
              <Button variant="secondary" size="small" onPress={onClear}>
                {clearButtonText}
              </Button>
            </div>
          ))}
      </Popover>
    </DialogTrigger>
  );
}

FilterSelector.Item = FilterSelectorItem;

export { FilterSelector };
