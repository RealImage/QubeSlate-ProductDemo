import { useState } from "react";
import { FilterSelector } from "./FilterSelector";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/FilterSelector",
  component: FilterSelector,
  parameters: { layout: "centered" },
  decorators: [
    (Story) => (
      <div style={{ minHeight: "22rem", display: "flex", alignItems: "flex-start" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: function Render(props) {
    const [selected, setSelected] = useState<Set<string>>(new Set());
    console.log(selected);
    return (
      <FilterSelector
        {...props}
        triggerLabel="Status"
        selectedKeys={selected}
        onSelectionChange={setSelected}
        onClear={() => setSelected(new Set())}
      >
        <FilterSelector.Item id="active">Active</FilterSelector.Item>
        <FilterSelector.Item id="inactive">Inactive</FilterSelector.Item>
        <FilterSelector.Item id="pending">Pending</FilterSelector.Item>
        <FilterSelector.Item id="archived">Archived</FilterSelector.Item>
      </FilterSelector>
    );
  },
});

export const WithAsyncSearch = meta.story({
  render: function Render(props) {
    const ITEMS = Array.from({ length: 50 }, (_, i) => ({
      id: `item-${i + 1}`,
      label: `Item ${i + 1}`,
    }));
    const [selectedItems, setSelectedItems] = useState([
      { id: "item-1", label: "Item 1" },
      { id: "item-5", label: "Item 5" },
    ]);
    const [results, setResults] = useState<typeof ITEMS>([]);
    const [inputValue, setInputValue] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSearch = (q: string) => {
      setInputValue(q);
      if (!q.trim()) {
        setResults([]);
        return;
      }
      setLoading(true);
      setTimeout(() => {
        setResults(ITEMS.filter((u) => u.label.toLowerCase().includes(q.toLowerCase())));
        setLoading(false);
      }, 400);
    };

    return (
      <FilterSelector
        {...props}
        triggerLabel="Filter Items"
        searchPlaceholder="Search Items"
        inputValue={inputValue}
        onInputChange={handleSearch}
        isLoading={loading}
        selectedKeys={new Set(selectedItems.map((i) => i.id))}
        onClear={() => setSelectedItems([])}
        disableFilter
        emptyState={inputValue ? "No Items found" : "Type to search items"}
      >
        {(inputValue.trim() ? results : selectedItems).map((u) => (
          <FilterSelector.Item
            key={u.id}
            id={u.id}
            onClick={() =>
              setSelectedItems((prev) =>
                prev.some((i) => i.id === u.id) ? prev.filter((i) => i.id !== u.id) : [...prev, u],
              )
            }
          >
            {u.label}
          </FilterSelector.Item>
        ))}
      </FilterSelector>
    );
  },
});
