import React from "react";
import cx from "classnames";
import { CancelRoundedIcon } from "../../assets/icon";

export type TagVariant =
  | "default"
  | "secondary"
  | "positive"
  | "notice"
  | "negative"
  | "primary-secondary"
  | "primary"
  | "orange"
  | "violet"
  | "invert";

export type TagSize = "large" | "medium" | "small" | "xsmall";

export type TagProps = {
  variant?: TagVariant;
  size?: TagSize;
  prefixIcon?: React.ReactNode;
  closeIcon?: React.ReactNode;
  onClose?: () => void;
} & React.HTMLAttributes<HTMLSpanElement>;

export function Tag({
  className,
  variant = "default",
  size = "medium",
  prefixIcon,
  closeIcon,
  children,
  onClose,
  ...props
}: TagProps) {
  return (
    <span className={cx("pf-tag", `pf-tag--${variant}`, `pf-tag--${size}`, className)} {...props}>
      {prefixIcon && <span className="pf-tag__prefix">{prefixIcon}</span>}
      <span className="pf-tag__content">{children}</span>
      {onClose || closeIcon ? (
        <button className="pf-tag__close" onClick={onClose}>
          {closeIcon || <CancelRoundedIcon />}
        </button>
      ) : null}
    </span>
  );
}
