import { CircleIcon } from "../../assets/icon";
import { Tag } from "./Tag";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Tag",
  component: Tag,
  parameters: { layout: "centered" },
  args: {
    variant: "default",
    size: "medium",
    children: "Value",
    onClose: undefined,
  },
});

export const Default = meta.story({
  render: (props) => <Tag {...props} />,
});

export const CloseIcon = meta.story({
  args: {
    onClose: () => {},
  },
  render: (props) => <Tag {...props} />,
});

export const PrefixIcon = meta.story({
  args: {
    prefixIcon: <CircleIcon />,
  },
  render: (props) => <Tag {...props} />,
});

export const PrefixAndCloseIcon = meta.story({
  args: {
    prefixIcon: <CircleIcon />,
    onClose: () => {},
  },
  render: (props) => <Tag {...props} />,
});

export const AllVariants = meta.story({
  args: {
    size: "medium",
    style: { textTransform: "capitalize" },
  },
  render: (props, options) => (
    <div
      style={{
        display: "flex",
        gap: "1rem",
        flexWrap: "wrap",
        justifyContent: "center",
        maxWidth: "500px",
      }}
    >
      {options.argTypes.variant?.options?.map((variant) => (
        <Tag {...props} key={variant} variant={variant}>
          {variant?.split("-").join(" ")}
        </Tag>
      ))}
    </div>
  ),
});
