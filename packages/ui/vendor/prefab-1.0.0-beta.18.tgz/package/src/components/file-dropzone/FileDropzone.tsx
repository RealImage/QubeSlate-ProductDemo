import { useId, useRef } from "react";
import { DropZone, Group, type DropZoneProps } from "react-aria-components";
import cx from "classnames";
import { AttachFileOutlineIcon } from "../../assets/icon";
import { FieldError, FieldHint, FieldLabel } from "../field/Field";

export type FileDropzoneProps = Omit<DropZoneProps, "children"> & {
  /** Label for the field. */
  label?: React.ReactNode;
  /** Accepted file types as MIME type strings (e.g., "application/json", "image/png"). Do not use file extensions (e.g., ".json"). */
  acceptedTypes?: string[];
  /** Whether multiple files can be selected. */
  multiple?: boolean;
  /** Called when files are selected via the file picker or drag-and-drop. */
  onFileSelect?: (files: File[]) => void;
  /** Whether the field is optional. */
  optional?: boolean;
  /** Additional class name(s) to apply to the dropzone. */
  className?: string;
  /** Additional props to spread onto the underlying file input element. */
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
  /** Additional content to be rendered inside the dropzone. */
  children?: React.ReactNode;
  /** Whether the field is invalid. */
  isInvalid?: boolean;
  /** Error message to be displayed below the Dropzone. */
  errorMessage?: React.ReactNode;
  /** Hint message to be displayed below the Dropzone. */
  description?: React.ReactNode;
  /** Shows an info icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Whether to open the file picker when the dropzone is clicked. @default true */
  openFilePickerOnClick?: boolean;
};

function FileDropzone({
  className,
  label,
  acceptedTypes,
  multiple,
  optional,
  onFileSelect,
  onDrop,
  isDisabled,
  inputProps,
  children,
  isInvalid,
  errorMessage,
  description,
  showHintIcon = true,
  openFilePickerOnClick = true,
  ...props
}: FileDropzoneProps) {
  const id = useId();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleOpenFilePicker = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" && openFilePickerOnClick && !isDisabled) {
      e.preventDefault();
      if (fileInputRef.current) {
        fileInputRef.current.click();
      }
    }
  };

  const handleDropzoneClick = () => {
    if (openFilePickerOnClick && !isDisabled) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div
      className={cx(
        "pf-file-dropzone",
        { "pf-file-dropzone--clickable": openFilePickerOnClick && !isDisabled },
        className,
      )}
    >
      {label && (
        <FieldLabel optional={optional} elementType="span">
          {label}
        </FieldLabel>
      )}
      <Group
        isInvalid={isInvalid}
        isDisabled={isDisabled}
        className="pf-file-dropzone__group"
        onKeyUp={handleOpenFilePicker}
        onClick={handleDropzoneClick}
      >
        <DropZone
          className="pf-file-dropzone__target"
          getDropOperation={(types) => {
            if (!acceptedTypes || acceptedTypes.length === 0) return "copy";
            return acceptedTypes.some((type) => types.has(type)) ? "copy" : "cancel";
          }}
          onDrop={async (e) => {
            onDrop?.(e);
            if (onFileSelect) {
              let items = multiple ? e.items : e.items.slice(0, 1);
              if (acceptedTypes) {
                items = items.filter(
                  (item) => item.kind === "file" && acceptedTypes?.includes(item.type),
                );
              }
              const files = await Promise.all(
                items.filter((item) => item.kind === "file").map((item) => item.getFile()),
              );
              if (files.length > 0) onFileSelect(files);
            }
          }}
          isDisabled={isDisabled}
          {...props}
        >
          {children}
        </DropZone>
        <input
          id={id}
          ref={fileInputRef}
          type="file"
          hidden
          accept={acceptedTypes?.join(",")}
          multiple={multiple}
          disabled={isDisabled}
          onChange={(e) => {
            if (e.target.files && onFileSelect) {
              onFileSelect(Array.from(e.target.files));
            }
            e.target.value = "";
          }}
          {...inputProps}
        />
      </Group>
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {!!errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
    </div>
  );
}

type FileDropzoneIconProps = React.HTMLAttributes<HTMLDivElement> & {
  /** Custom icon to display inside the dropzone. @default AttachFileOutlineIcon */
  children?: React.ReactNode;
};

function FileDropzoneIcon({ children, ...props }: FileDropzoneIconProps) {
  return (
    <div className="pf-file-dropzone__icon" {...props}>
      {children ?? <AttachFileOutlineIcon />}
    </div>
  );
}

function FileDropzoneTitle({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className="pf-file-dropzone__title" {...props}>
      {children}
    </div>
  );
}

function FileDropzoneDescription({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className="pf-file-dropzone__description" {...props}>
      {children}
    </div>
  );
}

FileDropzone.Icon = FileDropzoneIcon;
FileDropzone.Title = FileDropzoneTitle;
FileDropzone.Description = FileDropzoneDescription;

export { FileDropzone };
