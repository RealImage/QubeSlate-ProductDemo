import { AttachFileOutlineIcon } from "../../assets/icon";
import { FileDropzone } from "./FileDropzone";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/FileDropzone",
  component: FileDropzone,
  parameters: { layout: "centered" },
  args: {
    acceptedTypes: ["text/csv"],
    label: "Upload CSV",
  },
});

export const Default = meta.story({
  render: (props) => {
    return (
      <FileDropzone {...props}>
        <FileDropzone.Icon />
        <FileDropzone.Title>Click to upload or Drag and Drop</FileDropzone.Title>
        <FileDropzone.Description>
          Upload your files here. Supported formats: .csv
        </FileDropzone.Description>
      </FileDropzone>
    );
  },
});

export const Disabled = meta.story({
  args: {
    isDisabled: true,
  },
  render: (props) => (
    <FileDropzone {...props}>
      <FileDropzone.Icon>
        <AttachFileOutlineIcon />
      </FileDropzone.Icon>
      <FileDropzone.Title>Click to upload or Drag and Drop</FileDropzone.Title>
      <FileDropzone.Description>
        Upload your files here. Supported formats: .csv
      </FileDropzone.Description>
    </FileDropzone>
  ),
});
