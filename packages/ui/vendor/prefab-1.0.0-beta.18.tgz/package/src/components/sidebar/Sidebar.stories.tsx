import { useState } from "react";
import { Title, Subtitle, Description, Primary, Controls } from "@storybook/addon-docs/blocks";
import {
  AdvertiserIcon,
  FilmIcon,
  HeartbeatBoxIcon,
  HistoryIcon,
  InfoOutlineIcon,
  MoreHorizontalIcon,
  QubeLogoOnlyBlueIcon,
  QubeWireLogoBlueFullIcon,
  SettingsOutlineIcon,
  SupportOutlineIcon,
  TheatreGalleryIcon,
} from "../../assets/icon";
import { Button } from "../../components/button/Button";
import { Menu } from "../menu/Menu";
import { Sidebar, SidebarMobileHeader } from "./Sidebar";
import preview from "#storybook/preview";

const LogoSmall = QubeLogoOnlyBlueIcon;
const LogoFull = QubeWireLogoBlueFullIcon;

const componentDocs = `
The sidebar is a compound navigation layout for application shells. It supports desktop collapse, nested navigation groups, and a mobile drawer using the same composition.

## Base structure

- Use \`Sidebar.Header\` for logo and branding at the top.
- Use \`Sidebar.Nav\` for the primary navigation tree.
- Use \`Sidebar.NavGroup\` for expandable nested sections.
- Use \`Sidebar.NavItem\` for direct links. Render your router \`Link\` inside the NavItem.
- Use \`Sidebar.Actions\` for secondary actions such as help or info.
- Use \`Sidebar.Footer\` for the user section and trailing actions.
- Use \`SidebarMobileHeader\` to render the mobile top header that controls the sidebar drawer. This is optional. You can render your own header if needed.

## Router integration

- Drive \`isActive\` from your router's current pathname. Use prefix checks such as \`pathname.startsWith('/settings')\` to determine the \`isActive\` state.
- Render your router's \`Link\` component inside each navigation item.

\`\`\`tsx
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";

function AppSidebar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  return (
    <>
      <SidebarMobileHeader open={open} onOpenChange={setOpen}>
        <LogoFull />
      </SidebarMobileHeader>

      <Sidebar open={open} onOpenChange={setOpen}>
        <Sidebar.Header>
          {({ collapsed, isMobile }) => (collapsed ? <LogoSmall /> : <LogoFull />)}
        </Sidebar.Header>

        <Sidebar.Nav>
          <Sidebar.NavItem isActive={pathname === "/compositions"}>
            <Link to="/compositions">
              <FilmIcon />
              <Sidebar.Label>Compositions</Sidebar.Label>
            </Link>
          </Sidebar.NavItem>

          <Sidebar.NavGroup label="Monitoring" icon={<HeartbeatBoxIcon />}>
            <Sidebar.NavItem isActive={pathname.startsWith("/monitoring/dcp")}>
              <Link to="/monitoring/dcp">
                <Sidebar.Label>DCP Monitoring</Sidebar.Label>
              </Link>
            </Sidebar.NavItem>
          </Sidebar.NavGroup>
        </Sidebar.Nav>

        <Sidebar.Footer>
          <Sidebar.User name="User Name" subtitle="Company Name" />
        </Sidebar.Footer>
      </Sidebar>
    </>
  );
}
\`\`\`

This same pattern works with Next.js, TanStack Router, or any other router. Replace \`Link\` and pathname access with the equivalent API from your app.
`;

const meta = preview.meta({
  title: "Components/Sidebar",
  component: Sidebar,
  parameters: {
    docs: {
      page: () => (
        <>
          <Title />
          <Subtitle />
          <Description />
          <Primary />
          <Controls />
        </>
      ),
      description: { component: componentDocs },
      story: { inline: false, iframeHeight: "35rem" },
    },
    layout: "fullscreen",
  },
  decorators: [
    (Story) => (
      <div style={{ height: "100vh", background: "#f7f8f9" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: function Render(props) {
    // For this story, we'll just simulate current path with a state variable.
    // In real apps, use pathname from the router library.
    const [simulatedPath, setSimulatedPath] = useState("/monitoring/dcp");
    const [open, setOpen] = useState(false);

    const handleLinkSimulation = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
      e.preventDefault();
      setSimulatedPath(e.currentTarget.getAttribute("href") || "/");
    };

    return (
      <div style={{ position: "relative", height: "100vh", overflow: "hidden", display: "flex" }}>
        <Sidebar {...props} open={open} onOpenChange={setOpen}>
          <Sidebar.Header>
            {({ collapsed }) =>
              collapsed ? <LogoSmall style={{ marginLeft: -0.52 }} /> : <LogoFull />
            }
          </Sidebar.Header>
          <Sidebar.Nav>
            <Sidebar.NavItem isActive={simulatedPath.startsWith("/compositions")}>
              <a href="/compositions" onClick={handleLinkSimulation}>
                <FilmIcon />
                <Sidebar.Label>Compositions</Sidebar.Label>
              </a>
            </Sidebar.NavItem>

            <Sidebar.NavGroup label="Monitoring" icon={<HeartbeatBoxIcon />}>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/monitoring/dcp")}>
                <a href="/monitoring/dcp" onClick={handleLinkSimulation}>
                  <Sidebar.Label>DCP Monitoring</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/monitoring/kdm")}>
                <a href="/monitoring/kdm" onClick={handleLinkSimulation}>
                  <Sidebar.Label>KDM Monitoring</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
            </Sidebar.NavGroup>

            <Sidebar.NavGroup label="History" icon={<HistoryIcon />}>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/history/bookings")}>
                <a href="/history/bookings" onClick={handleLinkSimulation}>
                  <Sidebar.Label>Bookings</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/history/rights")}>
                <a href="/history/rights" onClick={handleLinkSimulation}>
                  <Sidebar.Label>Rights</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
            </Sidebar.NavGroup>

            <Sidebar.NavGroup label="Settings" icon={<SettingsOutlineIcon />}>
              {Array.from({ length: 4 }).map((_, index) => (
                <Sidebar.NavItem
                  key={index}
                  isActive={simulatedPath.startsWith(`/settings/setting-${index + 1}`)}
                >
                  <a href={`/settings/setting-${index + 1}`} onClick={handleLinkSimulation}>
                    <Sidebar.Label>{`Setting ${index + 1}`}</Sidebar.Label>
                  </a>
                </Sidebar.NavItem>
              ))}
            </Sidebar.NavGroup>
          </Sidebar.Nav>

          <Sidebar.Actions>
            <Sidebar.Button>
              <SupportOutlineIcon />
              <Sidebar.Label>Help</Sidebar.Label>
            </Sidebar.Button>
            <Menu>
              <Sidebar.Button>
                <InfoOutlineIcon />
                <Sidebar.Label>Info</Sidebar.Label>
              </Sidebar.Button>
              <Menu.Items>
                <Menu.Item>About Us</Menu.Item>
                <Menu.Item>Terms of Service</Menu.Item>
                <Menu.Item>Privacy Policy</Menu.Item>
                <Menu.Item>Contact Support</Menu.Item>
              </Menu.Items>
            </Menu>
          </Sidebar.Actions>
          <Sidebar.Footer>
            <Sidebar.User name="Kube Wireson" subtitle="Qube Cinemas" />
            <Menu>
              <Sidebar.Button aria-label="Options">
                <MoreHorizontalIcon />
              </Sidebar.Button>
              <Menu.Items>
                <Menu.Item>Switch Company</Menu.Item>
                <Menu.Item>Logout</Menu.Item>
              </Menu.Items>
            </Menu>
          </Sidebar.Footer>
        </Sidebar>
        <main style={{ flex: 1, overflow: "auto", padding: "2rem", backgroundColor: "#f7f8f9" }}>
          <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
            <header style={{ marginBottom: "2rem" }}>
              <h1 style={{ fontSize: "1.75rem", marginBottom: "0.5rem" }}>
                {simulatedPath
                  .split("/")
                  .filter(Boolean)
                  .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
                  .join(" / ") || "Dashboard"}
              </h1>
              <p style={{ color: "#666", fontSize: "0.875rem" }}>
                Current route: <code>{simulatedPath}</code>
              </p>
            </header>

            <p style={{ color: "#374151", lineHeight: 1.6 }}>
              Click on navigation items in the sidebar to see the route change.
            </p>

            <Button style={{ marginTop: "1rem" }} onClick={() => setOpen((prev) => !prev)}>
              Toggle Sidebar
            </Button>

            <div style={{ height: "100vh" }} />
          </div>
        </main>
      </div>
    );
  },
});

export const WithMobileHeader = meta.story({
  parameters: { docs: { disable: true } },
  render: function Render(props) {
    const [simulatedPath, setSimulatedPath] = useState("/compositions");
    const [open, setOpen] = useState(false);

    const handleLinkSimulation = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
      e.preventDefault();
      setSimulatedPath(e.currentTarget.getAttribute("href") || "/");
    };

    return (
      <div style={{ position: "relative", height: "100vh", overflow: "hidden" }}>
        <SidebarMobileHeader open={open} onOpenChange={setOpen}>
          <LogoFull />
        </SidebarMobileHeader>
        <div style={{ display: "flex", height: "100%" }}>
          <Sidebar {...props} open={open} onOpenChange={setOpen}>
            <Sidebar.Header>
              {({ collapsed }) =>
                collapsed ? <LogoSmall style={{ marginLeft: -0.52 }} /> : <LogoFull />
              }
            </Sidebar.Header>
            <Sidebar.Nav>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/compositions")}>
                <a href="/compositions" onClick={handleLinkSimulation}>
                  <FilmIcon />
                  <Sidebar.Label>Compositions</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
              <Sidebar.NavItem isActive={simulatedPath.startsWith("/theatres")}>
                <a href="/theatres" onClick={handleLinkSimulation}>
                  <TheatreGalleryIcon />
                  <Sidebar.Label>Theatres</Sidebar.Label>
                </a>
              </Sidebar.NavItem>
              <Sidebar.NavGroup label="Work Orders" icon={<AdvertiserIcon />}>
                <Sidebar.NavItem isActive={simulatedPath.startsWith("/workorder/active")}>
                  <a href="/workorder/active" onClick={handleLinkSimulation}>
                    <Sidebar.Label>Active</Sidebar.Label>
                  </a>
                </Sidebar.NavItem>
                <Sidebar.NavItem isActive={simulatedPath.startsWith("/workorder/archived")}>
                  <a href="/workorder/archived" onClick={handleLinkSimulation}>
                    <Sidebar.Label>Archived</Sidebar.Label>
                  </a>
                </Sidebar.NavItem>
              </Sidebar.NavGroup>
            </Sidebar.Nav>
            <Sidebar.Footer>
              <Sidebar.User name="Kube Wireson" subtitle="Qube Cinemas" />
              <Menu>
                <Sidebar.Button aria-label="Options">
                  <MoreHorizontalIcon />
                </Sidebar.Button>
                <Menu.Items>
                  <Menu.Item>Switch Company</Menu.Item>
                  <Menu.Item>Logout</Menu.Item>
                </Menu.Items>
              </Menu>
            </Sidebar.Footer>
          </Sidebar>
          <main style={{ flex: 1, overflow: "auto", padding: "2rem", backgroundColor: "#f7f8f9" }}>
            <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
              <header style={{ marginBottom: "2rem" }}>
                <h1 style={{ fontSize: "1.75rem", marginBottom: "0.5rem" }}>
                  {simulatedPath
                    .split("/")
                    .filter(Boolean)
                    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
                    .join(" / ") || "Dashboard"}
                </h1>
                <p style={{ color: "#666", fontSize: "0.875rem" }}>
                  Current route: <code>{simulatedPath}</code>
                </p>
              </header>

              <p style={{ color: "#374151", lineHeight: 1.6 }}>
                Click on navigation items in the sidebar to see the route change.
              </p>

              <div style={{ height: "100vh" }} />
            </div>
          </main>
        </div>
      </div>
    );
  },
});
