import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Button,
  Disclosure,
  DisclosureGroup,
  DisclosurePanel,
  Modal,
  ModalOverlay,
  SharedElement,
  SharedElementTransition,
  type ButtonProps as AriaButtonProps,
  type Key,
} from "react-aria-components";
import cx from "classnames";
import { CancelIcon, ChevronLeftIcon, ChevronDownIcon, HamburgerIcon } from "../../assets/icon";
import { Tooltip, type TooltipTriggerProps } from "../tooltip/Tooltip";

type SidebarContextType = {
  /** Indicates whether the sidebar is open or closed.
   *  @note
   * - In desktop view, `open: true` means the sidebar is expanded, and `false` means it is collapsed.
   * - In mobile view, `open: true` means the sidebar is visible, and `false` means it is hidden.
   */
  open: boolean;
  setOpen: (open: boolean) => void;
  isMobile: boolean;
  /** Whether the sidebar is in collapsed mode.
   *  @note In mobile view, this value will always be `false` because the sidebar is either hidden or visible.
   */
  collapsed?: boolean;
  /** Opens the collapsed sidebar temporarily when a nav group is clicked, so users can select nested items. It closes on blur, mouse leave, or Escape. */
  setTemporarilyOpen: (open: boolean) => void;
  /** Whether the sidebar is currently in its **temporary expanded** mode. */
  temporarilyOpen: boolean;
  /** Sets the active navigation item in the current group. */
  setActiveNavItem: (item: { groupId: string | null; itemId: string | null }) => void;
  /** The currently active navigation item in the current group. */
  activeNavItem: { groupId: string | null; itemId: string | null };
  /** The set of currently expanded navigation groups. */
  expandedGroups: Set<Key>;
  /** Sets the expanded navigation groups. */
  setExpandedGroups: (groups: Set<Key>) => void;
};

const SidebarContext = createContext<SidebarContextType>({
  open: false,
  setOpen: () => {},
  isMobile: false,
  collapsed: true,
  temporarilyOpen: false,
  setTemporarilyOpen: () => {},
  setActiveNavItem: () => {},
  activeNavItem: { groupId: null, itemId: null },
  expandedGroups: new Set(),
  setExpandedGroups: () => {},
});

export const useSidebarInternals = () => useContext(SidebarContext);

type SidebarProps = {
  /** Controlled open state. Omit to use internal state. */
  open?: boolean;
  /** Called when the sidebar open state changes. */
  onOpenChange?: (open: boolean) => void;
  /** Mobile drawer breakpoint in pixels. @default 767 */
  mobileBreakpoint?: number;
  /** Whether the mobile sidebar closes when the user interacts outside of it. @default true */
  isDismissable?: boolean;
  className?: string;
  children?: React.ReactNode;
};

function Sidebar({
  children,
  className,
  open,
  onOpenChange,
  mobileBreakpoint = 767,
  isDismissable = true,
}: SidebarProps) {
  const isHovered = useRef(false);
  const [internalOpen, setInternalOpen] = useState(false);
  const [isTemporarilyOpen, setIsTemporarilyOpen] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState(new Set<Key>([]));
  const [activeNavItem, setActiveNavItem] = useState<SidebarContextType["activeNavItem"]>({
    groupId: null,
    itemId: null,
  });
  const isOpen = open ?? internalOpen;
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia(`(max-width: ${mobileBreakpoint}px)`).matches;
  });
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mediaQuery = window.matchMedia(`(max-width: ${mobileBreakpoint}px)`);
    const handleChange = (event: MediaQueryListEvent) => {
      setIsMobile(event.matches);
      setIsTemporarilyOpen(false);
    };
    setIsMobile(mediaQuery.matches);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, [mobileBreakpoint]);

  const isSidebarVisible = isOpen || (!isMobile && isTemporarilyOpen);
  const isCollapsed = !isMobile && !isSidebarVisible;

  const handleOpenSidebar = useCallback(
    (value: boolean) => {
      if (onOpenChange) onOpenChange(value);
      if (!isMobile && value && activeNavItem.groupId) {
        setExpandedGroups(new Set([activeNavItem.groupId]));
      }
      setIsTemporarilyOpen(false);
      if (open === undefined) setInternalOpen(value);
    },
    [activeNavItem.groupId, isMobile, onOpenChange, open],
  );

  const handleTempOpenChange = useCallback(
    (value: boolean) => {
      if (isMobile) return;
      if (!isOpen) {
        setIsTemporarilyOpen(value);
        setIsAnimating(true);
      }
    },
    [isMobile, isOpen],
  );

  const handleMouseEnter = () => {
    isHovered.current = true;
  };

  const focusableRegions = '[role="menu"]';

  const handleMouseLeave = () => {
    isHovered.current = false;
    if (isMobile) return;
    const isFocusWithinAllowedRegion = Boolean(document.activeElement?.closest(focusableRegions));
    if (isTemporarilyOpen && !isAnimating && !isFocusWithinAllowedRegion) {
      setIsTemporarilyOpen(false);
      setIsAnimating(true);
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLDivElement>) => {
    if (isMobile) return;
    if (!isTemporarilyOpen) return;

    const nextFocused = e.relatedTarget instanceof HTMLElement ? e.relatedTarget : null;

    const isFocusWithinAllowedRegion = Boolean(nextFocused?.closest(focusableRegions));
    if (isFocusWithinAllowedRegion) return;

    const isFocusWithinSidebar = !nextFocused && e.target?.closest(focusableRegions);
    if (isFocusWithinSidebar || isHovered.current) return;

    if (!e.currentTarget.contains(nextFocused)) {
      setIsTemporarilyOpen(false);
      setIsAnimating(true);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (isTemporarilyOpen && e.key === "Escape") {
      setIsTemporarilyOpen(false);
    }
  };

  const handleTransitionEnd = (e: React.TransitionEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget && e.propertyName === "width") {
      const isKeyboardFocused =
        e.currentTarget.contains(document.activeElement) &&
        document.activeElement?.matches(":focus-visible");
      if (!isHovered.current && isTemporarilyOpen && !isKeyboardFocused) {
        handleTempOpenChange(false);
        return;
      }
      setIsAnimating(false);
    }
  };

  const sidebarContent = (
    <nav
      className={cx("pf-sidebar", {
        "pf-sidebar--mobile": isMobile,
        "pf-sidebar--mobile-open": isMobile && isOpen,
        "pf-sidebar--collapsed": isCollapsed,
      })}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onBlur={handleBlur}
      onKeyDown={handleKeyDown}
      onTransitionEnd={handleTransitionEnd}
    >
      {children}
      {!isMobile && <SidebarToggle />}
    </nav>
  );

  const providerValues = useMemo(
    () => ({
      open: isSidebarVisible,
      setOpen: handleOpenSidebar,
      isMobile,
      collapsed: isCollapsed,
      temporarilyOpen: isTemporarilyOpen,
      setTemporarilyOpen: handleTempOpenChange,
      setActiveNavItem,
      activeNavItem,
      expandedGroups,
      setExpandedGroups,
    }),
    [
      isSidebarVisible,
      isCollapsed,
      handleOpenSidebar,
      isMobile,
      isTemporarilyOpen,
      handleTempOpenChange,
      setActiveNavItem,
      activeNavItem,
      expandedGroups,
      setExpandedGroups,
    ],
  );

  return (
    <SidebarContext.Provider value={providerValues}>
      {isMobile ? (
        <ModalOverlay
          className={cx("pf-sidebar-modal-overlay", className)}
          isDismissable={isDismissable}
          isOpen={isSidebarVisible}
          onOpenChange={handleOpenSidebar}
        >
          <Modal className="pf-sidebar-modal">{sidebarContent}</Modal>
        </ModalOverlay>
      ) : (
        <div
          className={cx("pf-sidebar-root", className, {
            "pf-sidebar-root--peek": isTemporarilyOpen,
            "pf-sidebar-root--animating": isAnimating,
          })}
        >
          {sidebarContent}
        </div>
      )}
    </SidebarContext.Provider>
  );
}

type SidebarHeaderProps = {
  children?:
    | React.ReactNode
    | ((props: Pick<SidebarContextType, "open" | "isMobile" | "collapsed">) => React.ReactNode);
} & Omit<React.HTMLAttributes<HTMLElement>, "children">;

function SidebarHeader({ children, className, ...props }: SidebarHeaderProps) {
  const state = useSidebarInternals();
  return (
    <div className={cx("pf-sidebar__header", className)} {...props}>
      {typeof children === "function" ? children(state) : children}
    </div>
  );
}

type SidebarNavProps = React.HTMLAttributes<HTMLElement>;

function SidebarNav({ children, className, ...props }: SidebarNavProps) {
  const { collapsed, expandedGroups, setExpandedGroups, activeNavItem } = useSidebarInternals();

  const handleExpandedChange = (keys: Set<Key>) => {
    if (keys.size <= 2) {
      setExpandedGroups(keys);
      return;
    }

    const opened = [...keys];
    const newest = opened[opened.length - 1];
    const secondNewest = opened[opened.length - 2];

    // Always keep the newest group. Its companion is the active group
    //  otherwise fall back to the second-newest group.
    const activeGroup = activeNavItem.groupId;
    const companion =
      activeGroup && keys.has(activeGroup) && activeGroup !== newest ? activeGroup : secondNewest;

    setExpandedGroups(new Set<Key>([newest, companion]));
  };

  return (
    <DisclosureGroup
      allowsMultipleExpanded
      expandedKeys={collapsed ? new Set<Key>() : expandedGroups}
      onExpandedChange={handleExpandedChange}
      className={cx("pf-sidebar__nav", className)}
      {...props}
    >
      {children}
    </DisclosureGroup>
  );
}

type SidebarNavGroupProps = {
  /** Unique identifier for the group. */
  id?: string;
  /** Label to display in the group header. */
  label: string;
  /** Icon to display in the group header. */
  icon?: React.ReactNode;
  /** Whether to highlight the group as active. (Optional) */
  isActive?: boolean;
  children: React.ReactNode;
  className?: string;
};

const SidebarNavGroupContext = createContext<{ groupId: string | null }>({ groupId: null });

function SidebarNavGroup({ id, children, label, className, icon, isActive }: SidebarNavGroupProps) {
  const { collapsed, open, setTemporarilyOpen, activeNavItem } = useSidebarInternals();
  const groupId = id || label;
  const active = isActive ?? groupId === activeNavItem.groupId;

  const providerValues = useMemo(() => ({ groupId }), [groupId]);

  return (
    <SidebarNavGroupContext.Provider value={providerValues}>
      <SharedElementTransition>
        <Disclosure id={groupId} className={cx("pf-sidebar__nav-group", className)}>
          <Tooltip isDisabled={open} animated={false} placement="right" offset={10}>
            <Button
              slot="trigger"
              className={cx("pf-sidebar__nav-group-trigger", { "is-active": active })}
              onClick={() => {
                if (collapsed) setTemporarilyOpen(true);
              }}
            >
              {icon}
              <SidebarLabel>{label}</SidebarLabel>
              <span className="pf-sidebar__chevron" aria-hidden="true">
                <ChevronDownIcon />
              </span>
            </Button>
          </Tooltip>
          <DisclosurePanel className="pf-sidebar__nav-group-panel">{children}</DisclosurePanel>
        </Disclosure>
      </SharedElementTransition>
    </SidebarNavGroupContext.Provider>
  );
}

type SidebarNavItemProps = {
  children: TooltipTriggerProps["children"];
  isActive?: boolean;
  className?: string;
} & React.HTMLAttributes<HTMLElement>;

function SidebarNavItem({ children, isActive, className, ...props }: SidebarNavItemProps) {
  const { open, setActiveNavItem } = useSidebarInternals();
  const { groupId } = useContext(SidebarNavGroupContext);
  const itemId = useId();

  useEffect(() => {
    if (isActive) setActiveNavItem({ groupId, itemId });
    return () => {
      setActiveNavItem({ groupId: null, itemId: null });
    };
  }, [groupId, isActive, setActiveNavItem, itemId]);

  const isNested = Boolean(groupId);

  return (
    <div className={cx("pf-sidebar__nav-item", { "is-active": isActive }, className)} {...props}>
      {isNested ? (
        <>
          <SharedElement
            name="sidebar-active-indicator"
            className="pf-sidebar__active-indicator"
            isVisible={isActive}
          />
          {children}
        </>
      ) : (
        <Tooltip delay={100} animated={false} placement="right" offset={10} isDisabled={open}>
          <Tooltip.Trigger>{children}</Tooltip.Trigger>
        </Tooltip>
      )}
    </div>
  );
}

type SidebarFooterProps = {
  children?:
    | React.ReactNode
    | ((props: Pick<SidebarContextType, "open" | "isMobile" | "collapsed">) => React.ReactNode);
} & Omit<React.HTMLAttributes<HTMLElement>, "children">;

function SidebarFooter({ children, className, ...props }: SidebarFooterProps) {
  const state = useSidebarInternals();
  return (
    <div className={cx("pf-sidebar__footer", className)} {...props}>
      {typeof children === "function" ? children(state) : children}
    </div>
  );
}

function SidebarToggle({
  className,
  onClick,
  ...props
}: React.ComponentProps<typeof Button> & { collapsed?: boolean }) {
  const { open, setOpen, temporarilyOpen, setTemporarilyOpen } = useSidebarInternals();
  const label = open ? "Collapse" : "Expand";
  return (
    <Tooltip animated={false} placement="right" offset={10}>
      <Button
        aria-label={label}
        className={cx("pf-sidebar__toggle", { "pf-sidebar__toggle--collapsed": !open }, className)}
        onClick={(e) => {
          if (onClick) onClick(e);
          if (temporarilyOpen) {
            setTemporarilyOpen(false);
          } else {
            setOpen(!open);
          }
        }}
        {...props}
      >
        <ChevronLeftIcon />
      </Button>
      <Tooltip.Content className="pf-sidebar__tooltip">{label}</Tooltip.Content>
    </Tooltip>
  );
}

function SidebarActions({ children, className }: React.HTMLAttributes<HTMLElement>) {
  return <div className={cx("pf-sidebar__actions", className)}>{children}</div>;
}

function SidebarButton({ children, className, ...props }: AriaButtonProps) {
  const { open } = useSidebarInternals();
  const ariaLabel = props["aria-label"];
  return (
    <Tooltip animated={false} placement="right" isDisabled={open && !ariaLabel} offset={10}>
      <Button className={cx("pf-sidebar__button", className)} {...props}>
        {children}
      </Button>
      {ariaLabel && <Tooltip.Content className="pf-sidebar__tooltip">{ariaLabel}</Tooltip.Content>}
    </Tooltip>
  );
}

type SidebarLabelProps = {
  children?: string;
  className?: string;
};

/**
 * Renders the nav item label. When the sidebar is collapsed, the label is
 * visually hidden and shown in the tooltip.
 */
function SidebarLabel({ children, className }: SidebarLabelProps) {
  return (
    <span className={cx("pf-sidebar__label", className)}>
      <Tooltip.Content className="pf-sidebar__tooltip">{children}</Tooltip.Content>
      {children}
    </span>
  );
}

type SidebarUserProps = {
  name: string;
  subtitle: string;
  className?: string;
};

function SidebarUser({ name, subtitle, className }: SidebarUserProps) {
  const { collapsed, setTemporarilyOpen, setExpandedGroups, activeNavItem } = useSidebarInternals();

  const initials = useMemo(
    () =>
      name
        ?.split(" ")
        .slice(0, 2)
        .map((word) => word?.[0] || "")
        .join(""),
    [name],
  );

  if (collapsed) {
    return (
      <div
        className={cx("pf-sidebar__user", "pf-sidebar__user--collapsed", className)}
        onClick={() => {
          if (activeNavItem.groupId) {
            setExpandedGroups(new Set([activeNavItem.groupId]));
          }
          setTemporarilyOpen(true);
        }}
      >
        <div className="pf-sidebar__user-initials">{initials}</div>
      </div>
    );
  }

  return (
    <div className={cx("pf-sidebar__user", className)}>
      <div className="pf-sidebar__user-name">{name}</div>
      <div className="pf-sidebar__user-subtitle">{subtitle}</div>
    </div>
  );
}

type SidebarMobileHeaderProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  className?: string;
  children?: React.ReactNode;
};

function SidebarMobileHeader({
  children,
  className,
  open,
  onOpenChange,
}: SidebarMobileHeaderProps) {
  return (
    <div className={cx("pf-sidebar-mobile-header", className)} data-react-aria-top-layer>
      <Button
        aria-label={open ? "Close menu" : "Open menu"}
        className="pf-sidebar-mobile-header__button"
        onClick={() => onOpenChange(!open)}
      >
        {open ? <CancelIcon /> : <HamburgerIcon />}
      </Button>
      {children}
    </div>
  );
}

Sidebar.Header = SidebarHeader;
Sidebar.Footer = SidebarFooter;
Sidebar.Actions = SidebarActions;
Sidebar.Button = SidebarButton;
Sidebar.Label = SidebarLabel;
Sidebar.Nav = SidebarNav;
Sidebar.NavItem = SidebarNavItem;
Sidebar.NavGroup = SidebarNavGroup;
Sidebar.User = SidebarUser;

export { Sidebar, SidebarMobileHeader };
