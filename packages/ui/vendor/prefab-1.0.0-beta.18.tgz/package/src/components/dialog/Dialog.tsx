import { useMemo } from "react";
import {
  Button as AriaButton,
  Dialog as AriaDialog,
  Heading,
  Modal,
  ModalOverlay,
  DialogTrigger,
  type DialogTriggerProps as AriaDialogTriggerProps,
  type DialogProps as AriaDialogProps,
  type ModalOverlayProps,
} from "react-aria-components";
import cx from "classnames";
import { CancelIcon } from "../../assets/icon";

export type DialogProps = Omit<ModalOverlayProps, "children" | "isDismissable"> & {
  /** Whether to close the modal when the user interacts outside it.
   *
   *  If not provided, defaults to `true` for role="dialog" and `false` for role="alertdialog".
   **/
  isDismissable?: boolean;
  /**
   * ARIA role for the inner dialog element.
   * @description The default role of "dialog" is suitable for most cases. Use "alertdialog" if the dialog requires immediate attention and contains critical information or actions.
   * @default "dialog"
   **/
  role?: AriaDialogProps["role"];
  children?: AriaDialogProps["children"];
  width?: React.CSSProperties["width"];
  maxWidth?: React.CSSProperties["maxWidth"];
  maxHeight?: React.CSSProperties["maxHeight"];
  containerStyles?: React.CSSProperties;
};

function Dialog({
  children,
  className,
  isDismissable,
  role = "dialog",
  width,
  maxWidth,
  maxHeight,
  containerStyles,
  ...props
}: DialogProps) {
  const styles = useMemo(
    () => ({ ...containerStyles, width, maxWidth, maxHeight }),
    [width, maxWidth, maxHeight, containerStyles],
  );
  return (
    <ModalOverlay
      className={cx("pf-dialog-overlay", className)}
      isDismissable={isDismissable ?? role !== "alertdialog"}
      {...props}
    >
      <Modal className="pf-dialog-modal" style={styles}>
        <AriaDialog className="pf-dialog" role={role}>
          {children}
        </AriaDialog>
      </Modal>
    </ModalOverlay>
  );
}

export type DialogHeaderProps = React.HTMLAttributes<HTMLDivElement> & {
  /** Whether to hide the default close button in the header. @default false */
  hideCloseButton?: boolean;
};

function DialogHeader({ children, className, hideCloseButton, ...props }: DialogHeaderProps) {
  return (
    <div className={cx("pf-dialog__header", className)} {...props}>
      <Heading slot="title" className="pf-dialog__heading">
        {children}
      </Heading>
      {!hideCloseButton && (
        <AriaButton slot="close" aria-label="Close dialog" className="pf-dialog__close">
          <CancelIcon />
        </AriaButton>
      )}
    </div>
  );
}

export type DialogBodyProps = React.HTMLAttributes<HTMLDivElement>;

function DialogBody({ children, className, ...props }: DialogBodyProps) {
  return (
    <div className={cx("pf-dialog__body", className)} {...props}>
      {children}
    </div>
  );
}

export type DialogFooterProps = React.HTMLAttributes<HTMLDivElement>;

function DialogFooter({ children, className, ...props }: DialogFooterProps) {
  return (
    <div className={cx("pf-dialog__footer", className)} {...props}>
      {children}
    </div>
  );
}

export type DialogTriggerProps = AriaDialogTriggerProps;

Dialog.Header = DialogHeader;
Dialog.Body = DialogBody;
Dialog.Footer = DialogFooter;

export { Dialog, DialogTrigger };
