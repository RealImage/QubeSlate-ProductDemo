import { useState } from "react";
import { Button } from "../button/Button";
import { AlertFilledIcon } from "../../assets/icon";
import { Dialog, DialogTrigger } from "./Dialog";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Dialog",
  component: Dialog,
  parameters: { layout: "centered" },
});

export const Default = meta.story({
  render: function Render(props) {
    const [open, setOpen] = useState(false);
    return (
      <>
        <Button variant="primary" onPress={() => setOpen(true)}>
          Open Dialog
        </Button>
        <Dialog isOpen={open} onOpenChange={setOpen} {...props}>
          <Dialog.Header>Leave without publishing?</Dialog.Header>
          <Dialog.Body>
            <p style={{ margin: 0, color: "#677a90" }}>
              You have unpublished changes. Save as draft to continue later, discard changes, or
              keep editing.
            </p>
          </Dialog.Body>
          <Dialog.Footer>
            <Button variant="negative" style={{ marginRight: "auto" }} slot="close">
              Discard
            </Button>
            <Button variant="secondary" slot="close">
              Keep editing
            </Button>
            <Button variant="primary" slot="close">
              Save draft
            </Button>
          </Dialog.Footer>
        </Dialog>
      </>
    );
  },
});

export const AlertDialog = meta.story({
  render: () => (
    <DialogTrigger>
      <Button variant="negative">Alert Dialog</Button>
      <Dialog role="alertdialog">
        <Dialog.Header>
          <AlertFilledIcon color="#cf1322" />
          Discard draft?
        </Dialog.Header>
        <Dialog.Body>
          You have unsaved changes that will be lost. Are you sure you want to discard the draft?
        </Dialog.Body>
        <Dialog.Footer>
          <Button variant="secondary" slot="close">
            Cancel
          </Button>
          <Button variant="negative" slot="close">
            Discard
          </Button>
        </Dialog.Footer>
      </Dialog>
    </DialogTrigger>
  ),
});
