import {
  Link as AriaLink,
  composeRenderProps,
  type LinkProps as AriaLinkProps,
} from "react-aria-components";
import cx from "classnames";

export type LinkProps = AriaLinkProps &
  React.RefAttributes<HTMLAnchorElement> & {
    variant?:
      | "default"
      | "primary"
      | "secondary"
      | "positive"
      | "negative"
      | "link"
      | "invert-default"
      | "invert-primary"
      | "invert-secondary";
    size?: "small" | "medium" | "large";
    iconOnly?: boolean;
  };

export function Link({
  className,
  variant = "link",
  size = "medium",
  iconOnly,
  ...props
}: LinkProps) {
  return (
    <AriaLink
      className={composeRenderProps(className, (className, state) =>
        cx("pf-button", className, {
          [`pf-button--${variant}`]: variant,
          [`pf-button--${size}`]: size,
          "pf-button--icon-only": iconOnly,
          "pf-button--pressed": state.isPressed,
          "pf-button--disabled": state.isDisabled,
        }),
      )}
      {...props}
    />
  );
}
