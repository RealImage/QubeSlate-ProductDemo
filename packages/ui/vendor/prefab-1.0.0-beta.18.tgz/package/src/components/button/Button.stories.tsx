import preview from "#storybook/preview";
import { Button, type ButtonProps } from "@/components/button/Button";
import { AddFilledIcon, ChevronRightIcon, ExternalLinkIcon, FilterFunnelIcon } from "@/assets/icon";

const meta = preview.meta({
  title: "Components/Button",
  component: Button,
  parameters: { layout: "centered" },
  args: {
    variant: "default",
    size: "medium",
    selected: false,
    iconOnly: false,
    isDisabled: false,
  },
});

export const Default = meta.story({
  render: (props) => <Button {...props}>Default Button</Button>,
});

export const AllButtons = meta.story({
  render: () => {
    const normalButtons: NonNullable<ButtonProps["variant"]>[] = [
      "default",
      "primary",
      "secondary",
      "positive",
      "negative",
      "link",
    ];
    const invertedButtons: NonNullable<ButtonProps["variant"]>[] = [
      "invert-default",
      "invert-primary",
      "invert-secondary",
    ];
    const sizes: NonNullable<ButtonProps["size"]>[] = ["small", "medium", "large"];

    return (
      <div style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "0.75rem",
            padding: "1.5rem",
            borderRadius: "0.75rem",
            backgroundColor: "#fafafa",
            border: "1px solid #e5e5e5",
          }}
        >
          {normalButtons.map((variant) => (
            <div key={variant} style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
              <h5 style={{ margin: 0, color: "#333", textTransform: "capitalize" }}>
                {variant.replace("-", " ")}
              </h5>
              <div style={{ display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap" }}>
                {sizes.map((size, index) => (
                  <>
                    <div key={size} style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                      <Button variant={variant} size={size}>
                        {variant === "link" ? <ExternalLinkIcon /> : <AddFilledIcon />}
                        {size.charAt(0).toUpperCase() + size.slice(1)}
                      </Button>
                      <Button variant={variant} size={size} iconOnly aria-label="Add Button">
                        {variant === "link" ? <ExternalLinkIcon /> : <AddFilledIcon />}
                      </Button>
                    </div>
                    {index < sizes.length - 1 && (
                      <div style={{ width: "1px", height: "2rem", backgroundColor: "#ddd" }} />
                    )}
                  </>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "0.75rem",
            padding: "1.5rem",
            borderRadius: "0.75rem",
            height: "max-content",
            backgroundColor: "#222",
            border: "1px solid #333",
          }}
        >
          {invertedButtons.map((variant) => (
            <div key={variant} style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
              <h5 style={{ margin: 0, color: "#fff", textTransform: "capitalize" }}>
                {variant.split("-").join(" ")}
              </h5>
              <div style={{ display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap" }}>
                {sizes.map((size, index) => (
                  <>
                    <div key={size} style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                      <Button variant={variant} size={size}>
                        <AddFilledIcon />
                        {size.charAt(0).toUpperCase() + size.slice(1)}
                      </Button>
                      <Button variant={variant} size={size} iconOnly aria-label="Add Button">
                        <AddFilledIcon />
                      </Button>
                    </div>
                    {index < sizes.length - 1 && (
                      <div style={{ width: "1px", height: "2rem", backgroundColor: "#555" }} />
                    )}
                  </>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  },
});

export const ButtonWithLeftIcon = meta.story({
  render: (props) => (
    <Button {...props}>
      <FilterFunnelIcon />
      Default Button
    </Button>
  ),
});

export const ButtonWithRightIcon = meta.story({
  render: (props) => (
    <Button {...props}>
      Default Button
      <ChevronRightIcon />
    </Button>
  ),
});

export const ButtonWithMultipleIcons = meta.story({
  render: (props) => (
    <Button {...props}>
      <FilterFunnelIcon />
      Default Button
      <ChevronRightIcon />
    </Button>
  ),
});

export const ButtonWithIconOnly = meta.story({
  render: (props) => (
    <Button {...props} aria-label="Add Button" iconOnly>
      <AddFilledIcon />
    </Button>
  ),
});
