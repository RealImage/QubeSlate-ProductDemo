import { Link } from "@/components/button/Link";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Link",
  component: Link,
  parameters: { layout: "centered" },
  args: {
    variant: "link",
    size: "medium",
    isDisabled: false,
  },
});

export const Default = meta.story({
  args: {
    href: "/",
  },
  render: (props) => <Link {...props}>Link</Link>,
});
