import {
  Button as AriaButton,
  composeRenderProps,
  type ButtonProps as AriaButtonProps,
} from "react-aria-components";
import cx from "classnames";

export type ButtonProps = AriaButtonProps &
  React.RefAttributes<HTMLButtonElement> & {
    variant?:
      | "default"
      | "primary"
      | "secondary"
      | "positive"
      | "negative"
      | "link"
      | "invert-default"
      | "invert-primary"
      | "invert-secondary";
    size?: "small" | "medium" | "large";
    selected?: boolean;
    iconOnly?: boolean;
  };

export function Button({
  className,
  variant = "default",
  size = "medium",
  iconOnly,
  selected,
  ...props
}: ButtonProps) {
  return (
    <AriaButton
      className={composeRenderProps(className, (className, state) =>
        cx("pf-button", className, {
          [`pf-button--${variant}`]: variant,
          [`pf-button--${size}`]: size,
          "pf-button--icon-only": iconOnly,
          "pf-button--pressed": state.isPressed,
          "pf-button--disabled": state.isDisabled || state.isPending,
          "pf-button--selected": selected,
        }),
      )}
      {...props}
    />
  );
}
