import cx from "classnames";

function Header({ className, children, ...props }: React.HTMLAttributes<HTMLElement>) {
  return (
    <header className={cx("pf-header", className)} {...props}>
      {children}
    </header>
  );
}

function Title({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("pf-header__title", className)} {...props}>
      {children}
    </div>
  );
}

function Actions({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("pf-header__actions", className)} {...props}>
      {children}
    </div>
  );
}

function Meta({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("pf-header__meta", className)} {...props}>
      {children}
    </div>
  );
}

Header.Title = Title;
Header.Actions = Actions;
Header.Meta = Meta;

export { Header };
