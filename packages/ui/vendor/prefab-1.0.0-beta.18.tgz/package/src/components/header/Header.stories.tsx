import { AddIcon } from "../../assets/icon";
import { Button } from "../button/Button";
import { Header } from "./Header";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Header",
  component: Header,
  parameters: { layout: "fullscreen" },
  decorators: [
    (Story) => (
      <div style={{ height: "100vh", background: "#f7f8f9" }}>
        <Story />
      </div>
    ),
  ],
});

export const TitleOnly = meta.story({
  render: () => (
    <Header>
      <Header.Title>Page Title</Header.Title>
    </Header>
  ),
});

export const TitleWithMetaAndActions = meta.story({
  render: () => (
    <Header>
      <Header.Title>
        <h1>Task Management</h1>
      </Header.Title>
      <Header.Meta>
        <p>Manage and monitor fleet update tasks</p>
      </Header.Meta>
      <Header.Actions>
        <Button variant="primary">
          <AddIcon />
          Add Tasks
        </Button>
      </Header.Actions>
    </Header>
  ),
});
