import { useContext, useMemo, useState } from "react";
import {
  Button as AriaButton,
  CalendarCell,
  CalendarHeaderCell,
  CalendarGrid,
  CalendarGridHeader,
  CalendarGridBody,
  ListBox,
  ListBoxItem,
  CalendarStateContext,
  RangeCalendarStateContext,
  useLocale,
} from "react-aria-components";
import { ChevronLeftIcon, ChevronRightIcon } from "../../assets/icon";

const YEAR_LIST = { size: 12, offset: -4 };

type CalendarView = "days" | "months" | "years";

const useCalendarState = () => {
  const calendarState = useContext(CalendarStateContext);
  const rangeCalendarState = useContext(RangeCalendarStateContext);
  return calendarState || rangeCalendarState!;
};

export function CalendarInner({
  monthOffset = 0,
  visibleMonths = 1,
}: {
  monthOffset?: number;
  visibleMonths?: number;
}) {
  const state = useCalendarState();
  const { locale } = useLocale();
  const [view, setView] = useState<CalendarView>("days");

  const currentDate = state.visibleRange.start.add({ months: monthOffset });

  const years = useMemo(() => {
    return new Map(
      Array.from({ length: YEAR_LIST.size }, (_, i) => {
        const year = currentDate.year + YEAR_LIST.offset + i;
        const date = currentDate.set({ year }).toDate(state.timeZone);
        return [year, { numeric: date.toLocaleString(locale, { year: "numeric" }) }];
      }),
    );
  }, [locale, currentDate, state.timeZone]);

  const months = useMemo(() => {
    const numMonths = currentDate.calendar.getMonthsInYear(currentDate);
    return new Map(
      Array.from({ length: numMonths }, (_, i) => {
        const month = i + 1;
        const date = currentDate.set({ month }).toDate(state.timeZone);
        return [
          month,
          {
            short: date.toLocaleString(locale, { month: "short" }),
            long: date.toLocaleString(locale, { month: "long" }),
          },
        ];
      }),
    );
  }, [locale, state.timeZone, currentDate]);

  function handleMonthSelect(month: number) {
    state.setFocusedDate(state.focusedDate.set({ month }));
    setView("days");
    state.setFocused(true);
  }

  function handleYearSelect(year: number) {
    state.setFocusedDate(state.focusedDate.set({ year }));
    setView("months");
    state.setFocused(true);
  }

  function handlePrev() {
    if (view === "months") {
      state.setFocusedDate(state.focusedDate.set({ year: state.focusedDate.year - 1 }));
    } else if (view === "years") {
      state.setFocusedDate(state.focusedDate.set({ year: state.focusedDate.year - 10 }));
    }
  }

  function handleNext() {
    if (view === "months") {
      state.setFocusedDate(state.focusedDate.set({ year: state.focusedDate.year + 1 }));
    } else if (view === "years") {
      state.setFocusedDate(state.focusedDate.set({ year: state.focusedDate.year + 10 }));
    }
  }

  return (
    <div className="pf-calendar__inner">
      <div className="pf-calendar__header">
        {monthOffset === 0 && (
          <AriaButton
            className="pf-calendar__nav-button"
            slot={view === "days" ? "previous" : null}
            onClick={handlePrev}
          >
            <ChevronLeftIcon />
          </AriaButton>
        )}
        <div className="pf-calendar__heading">
          {visibleMonths > 1 ? (
            <span>
              {months.get(currentDate.month)?.long} {currentDate.year}
            </span>
          ) : (
            <>
              {view === "days" && (
                <AriaButton slot={null} onClick={() => setView("months")}>
                  {months.get(currentDate.month)?.long}
                </AriaButton>
              )}
              {view === "years" ? (
                <span>
                  {currentDate.year + YEAR_LIST.offset} {" - "}
                  {currentDate.year + YEAR_LIST.offset + YEAR_LIST.size - 1}
                </span>
              ) : (
                <AriaButton slot={null} onClick={() => setView("years")}>
                  {currentDate.year}
                </AriaButton>
              )}
            </>
          )}
        </div>

        {monthOffset === visibleMonths - 1 && (
          <AriaButton
            slot={view === "days" ? "next" : null}
            className="pf-calendar__nav-button"
            onClick={handleNext}
          >
            <ChevronRightIcon />
          </AriaButton>
        )}
      </div>

      {view === "days" && (
        <CalendarGrid
          className="pf-calendar__grid"
          weekdayStyle="short"
          offset={{ months: monthOffset }}
        >
          <CalendarGridHeader className="pf-calendar__weekdays">
            {(day) => <CalendarHeaderCell className="pf-calendar__day">{day}</CalendarHeaderCell>}
          </CalendarGridHeader>
          <CalendarGridBody className="pf-calendar__grid-body">
            {(date) => (
              <CalendarCell className="pf-calendar__cell" date={date}>
                {({ formattedDate }) => <span>{formattedDate}</span>}
              </CalendarCell>
            )}
          </CalendarGridBody>
        </CalendarGrid>
      )}

      {view === "months" && (
        <ListBox
          autoFocus
          aria-label="Select month"
          className="pf-calendar__months-grid"
          layout="grid"
          selectionMode="none"
          onPointerUp={(e) => e.stopPropagation()}
        >
          {Array.from(months.entries()).map(([monthNumber, month]) => (
            <ListBoxItem
              key={monthNumber}
              id={monthNumber}
              textValue={month.short}
              className="pf-calendar__month-item"
              onAction={() => handleMonthSelect(monthNumber)}
            >
              {month.short}
            </ListBoxItem>
          ))}
        </ListBox>
      )}

      {view === "years" && (
        <ListBox
          autoFocus
          aria-label="Select year"
          className="pf-calendar__years-grid"
          layout="grid"
          selectionMode="none"
          onPointerUp={(e) => e.stopPropagation()}
        >
          {Array.from(years.entries()).map(([yearNumber, year]) => (
            <ListBoxItem
              key={yearNumber}
              id={yearNumber}
              textValue={year.numeric}
              className="pf-calendar__year-item"
              onAction={() => handleYearSelect(yearNumber)}
            >
              {year.numeric}
            </ListBoxItem>
          ))}
        </ListBox>
      )}
    </div>
  );
}
