import { useMemo } from "react";
import cx from "classnames";
import {
  RangeCalendar as AriaRangeCalendar,
  type DateValue,
  type RangeCalendarProps as AriaRangeCalendarProps,
  I18nProvider,
  type RangeValue,
} from "react-aria-components";
import {
  dateValueToIsoString,
  parseAriaDateTime,
  parseAriaDateTimeRange,
} from "../../utils/dateUtils";
import { CalendarInner } from "./CalendarInner";

export type RangeCalendarProps = {
  /** The current value (controlled). ISO 8601 string range: {start: "2026-05-03", end: "2026-05-10"}. */
  value?: { start: string; end: string } | null;
  /** The default value (uncontrolled). ISO 8601 string range. */
  defaultValue?: { start: string; end: string } | null;
  /** Handler called when the value changes. Returns ISO 8601 string range or null. */
  onChange?: (
    range: { start: string; end: string } | null,
    rawRange: RangeValue<DateValue> | null,
  ) => void;
  /** The minimum allowed date. ISO 8601 string. */
  minValue?: string;
  /** The maximum allowed date. ISO 8601 string. */
  maxValue?: string;
  /** Locale to use for the calendar. @default "en-US" */
  locale?: string;
} & Omit<
  AriaRangeCalendarProps<DateValue>,
  "value" | "defaultValue" | "onChange" | "minValue" | "maxValue"
>;

export function RangeCalendar({
  value,
  defaultValue,
  onChange,
  minValue,
  maxValue,
  className,
  locale = "en-US",
  ...props
}: RangeCalendarProps) {
  const ariaValue = useMemo(() => parseAriaDateTimeRange(value), [value]);
  const ariaDefaultValue = useMemo(() => parseAriaDateTimeRange(defaultValue), [defaultValue]);
  const ariaMinValue = useMemo(() => parseAriaDateTime(minValue), [minValue]);
  const ariaMaxValue = useMemo(() => parseAriaDateTime(maxValue), [maxValue]);

  const handleChange = (dateRange: RangeValue<DateValue> | null) => {
    if (onChange) {
      const formattedRange = dateRange
        ? { start: dateValueToIsoString(dateRange.start), end: dateValueToIsoString(dateRange.end) }
        : null;
      onChange(formattedRange, dateRange);
    }
  };
  return (
    <I18nProvider locale={locale}>
      <AriaRangeCalendar
        className={cx("pf-calendar pf-calendar--range", className)}
        value={ariaValue}
        defaultValue={ariaDefaultValue}
        onChange={handleChange}
        minValue={ariaMinValue}
        maxValue={ariaMaxValue}
        {...props}
      >
        {[...Array(props.visibleDuration?.months).keys()].map((i) => (
          <CalendarInner key={i} monthOffset={i} visibleMonths={props.visibleDuration?.months} />
        ))}
      </AriaRangeCalendar>
    </I18nProvider>
  );
}
