import { useState } from "react";
import { Calendar } from "./Calendar";
import { RangeCalendar } from "./RangedCalendar";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Calendar",
  component: Calendar,
  parameters: { layout: "centered" },
});

export const Default = meta.story({
  render: () => <Calendar />,
});

export const RangedCalendar = meta.story({
  render: () => <RangeCalendar />,
});

export const ControlledCalendar = meta.story({
  render: function Render() {
    const [date, setDate] = useState<string | null>(new Date().toISOString());
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        <Calendar value={date} onChange={setDate} />
        <div style={{ fontSize: "14px", color: "#666" }}>
          Selected: {date ? new Date(date.toString()).toLocaleDateString() : "None"}
        </div>
      </div>
    );
  },
});

export const ControlledRangeCalendar = meta.story({
  render: function Render() {
    const [range, setRange] = useState<{ start: string; end: string } | null>({
      start: new Date().toISOString(),
      end: new Date(new Date().getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    });

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        <RangeCalendar value={range} onChange={setRange} />
        <div style={{ fontSize: "14px", color: "#666" }}>
          Selected:{" "}
          {range
            ? `${new Date(range.start.toString()).toLocaleDateString()} - ${new Date(range.end.toString()).toLocaleDateString()}`
            : "None"}
        </div>
      </div>
    );
  },
});
