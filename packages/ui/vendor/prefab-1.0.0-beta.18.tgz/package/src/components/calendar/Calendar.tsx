import { useMemo } from "react";
import cx from "classnames";
import {
  Calendar as AriaCalendar,
  I18nProvider,
  type CalendarProps as AriaCalendarProps,
  type DateValue,
} from "react-aria-components";
import { dateValueToIsoString, parseAriaDateTime } from "../../utils/dateUtils";
import { CalendarInner } from "./CalendarInner";

export type CalendarProps = {
  /** The current value (controlled). ISO 8601 string: "2026-05-03" (date only) or "2026-05-03T06:03:00" (with time). */
  value?: string | null;
  /** The default value (uncontrolled). ISO 8601 string. */
  defaultValue?: string | null;
  /** Handler called when the value changes. Returns ISO 8601 string or null. */
  onChange?: (date: string | null) => void;
  /** The minimum allowed date. ISO 8601 string. */
  minValue?: string;
  /** The maximum allowed date. ISO 8601 string. */
  maxValue?: string;
  /** Locale to use for the calendar. @default "en-US" */
  locale?: string;
} & Omit<
  AriaCalendarProps<DateValue>,
  "value" | "defaultValue" | "onChange" | "minValue" | "maxValue"
>;

export function Calendar({
  className,
  value,
  defaultValue,
  onChange,
  minValue,
  maxValue,
  locale = "en-US",
  ...props
}: CalendarProps) {
  const ariaValue = useMemo(() => parseAriaDateTime(value), [value]);
  const ariaDefaultValue = useMemo(() => parseAriaDateTime(defaultValue), [defaultValue]);
  const ariaMinValue = useMemo(() => parseAriaDateTime(minValue), [minValue]);
  const ariaMaxValue = useMemo(() => parseAriaDateTime(maxValue), [maxValue]);

  const handleChange = (dateValue: DateValue | null) => {
    if (onChange) {
      onChange(dateValue ? dateValueToIsoString(dateValue) : null);
    }
  };
  return (
    <I18nProvider locale={locale}>
      <AriaCalendar
        className={cx("pf-calendar pf-calendar--single", className)}
        value={ariaValue}
        defaultValue={ariaDefaultValue}
        onChange={handleChange}
        minValue={ariaMinValue}
        maxValue={ariaMaxValue}
        {...props}
      >
        <CalendarInner />
      </AriaCalendar>
    </I18nProvider>
  );
}
