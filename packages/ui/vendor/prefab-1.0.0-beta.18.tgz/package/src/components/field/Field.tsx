import {
  Label as AriaLabel,
  Text,
  type LabelProps as AriaLabelProps,
  type TextProps,
} from "react-aria-components";
import cx from "classnames";
import { InfoFilledIcon } from "../../assets/icon";

export type FieldLabelProps = AriaLabelProps & {
  /** Renders an "(Optional)" badge next to the label text. */
  optional?: boolean;
  /** HTML Element type to render the label as. @default "label" */
  elementType?: string;
};

export function FieldLabel({
  children,
  optional,
  className,
  elementType,
  ...props
}: FieldLabelProps) {
  return (
    <AriaLabel className={cx("pf-field-label", className)} elementType={elementType} {...props}>
      {children}
      {optional && <span className="pf-field-label__optional">(Optional)</span>}
    </AriaLabel>
  );
}

export type FieldHintProps = Omit<TextProps, "slot"> & {
  children?: React.ReactNode;
  /** Shows an info icon next to the hint text. */
  showIcon?: boolean;
};

export function FieldHint({ children, className, showIcon, ...props }: FieldHintProps) {
  return (
    <Text slot="description" className={cx("pf-field-hint", className)} {...props}>
      {showIcon && <InfoFilledIcon className="pf-field-hint__icon" />}
      {children}
    </Text>
  );
}

export type FieldErrorProps = Omit<TextProps, "slot"> & {
  /** Shows an info icon next to the error text. */
  showIcon?: boolean;
};

export function FieldError({ children, className, showIcon, ...props }: FieldErrorProps) {
  return (
    <Text slot="errorMessage" className={cx("pf-field-error", className)} {...props}>
      {showIcon && <InfoFilledIcon className="pf-field-error__icon" />}
      {children}
    </Text>
  );
}
