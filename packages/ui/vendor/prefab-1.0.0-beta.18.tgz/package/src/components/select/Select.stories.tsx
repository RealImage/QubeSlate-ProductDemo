import { useEffect, useState } from "react";
import { LoaderSimpleIcon } from "../../assets/icon";
import { Select, type SelectKey } from "./Select";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Select",
  component: Select,
  parameters: { layout: "centered" },
  decorators: [
    (Story) => (
      <div style={{ width: "min(300px, 70vw)" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => (
    <Select {...props} label="Choose an option">
      <Select.Option>Option 1</Select.Option>
      <Select.Option>Option 2</Select.Option>
      <Select.Option>Option 3</Select.Option>
    </Select>
  ),
});

export const Controlled = meta.story({
  render: function Render() {
    const [value, setValue] = useState<SelectKey | null>(20);
    return (
      <Select label="Select Page Size" value={value} onChange={setValue}>
        <Select.Option id={10}>10</Select.Option>
        <Select.Option id={20}>20</Select.Option>
        <Select.Option id={30}>30</Select.Option>
      </Select>
    );
  },
});

export const MultipleLineOptions = meta.story({
  render: (props) => (
    <Select {...props} label="Choose an option">
      <Select.Option textValue="Option 1">
        <div>
          <div>Option 1</div>
          <div className="subtext" style={{ color: "#6A6A6A" }}>
            This is a description
          </div>
        </div>
      </Select.Option>
      <Select.Option textValue="Option 2">
        <div>
          <div>Option 2</div>
          <div className="subtext" style={{ color: "#6A6A6A" }}>
            This is a longer description
          </div>
        </div>
      </Select.Option>
      <Select.Option textValue="Option 3">
        <div>
          <div>Option 3</div>
          <div className="subtext" style={{ color: "#6A6A6A" }}>
            This is a longer description
          </div>
        </div>
      </Select.Option>
    </Select>
  ),
});

export const AsyncSelect = meta.story({
  render: function Render() {
    const [value, setValue] = useState("Item 1");
    const [data, setData] = useState<{
      items: string[] | undefined;
      isLoading: boolean;
      page: number;
    }>({
      items: undefined,
      isLoading: false,
      page: 1,
    });

    useEffect(() => {
      setData((prev) => ({ ...prev, isLoading: true }));
      /* Simulate loading initial items */
      setTimeout(() => {
        setData((prev) => ({
          ...prev,
          items: Array.from({ length: prev.page * 20 }, (_, i) => `Item ${i + 1}`),
          page: prev.page + 1,
          isLoading: false,
        }));
      }, 1000);
    }, []);

    const loadMore = () => {
      if (data.page > 10 || data.isLoading) return;
      setData((prev) => ({ ...prev, isLoading: true }));
      /* Simulate loading more items */
      setTimeout(() => {
        setData((prev) => ({
          ...prev,
          items: Array.from({ length: prev.page * 20 }, (_, i) => `Item ${i + 1}`),
          page: prev.page + 1,
          isLoading: false,
        }));
      }, 1000);
    };

    return (
      <Select
        label="Select"
        maxHeight={210}
        placeholder={data.isLoading && !data.items ? "Loading items..." : "Select an item"}
        value={value}
        onChange={(value) => value && setValue(value.toString())}
        renderEmptyState={() =>
          !data.isLoading &&
          !data.items && <div style={{ padding: "0.25rem 0.5rem" }}>No Items</div>
        }
      >
        {data.items?.map((item) => (
          <Select.Option key={item} id={item}>
            {item}
          </Select.Option>
        ))}
        <Select.LoadMore isLoading={data.isLoading} onLoadMore={loadMore} scrollOffset={10}>
          <LoaderSimpleIcon color="#677a90" strokeWidth={2} style={{ margin: "auto" }} />
        </Select.LoadMore>
      </Select>
    );
  },
});
