import {
  Button,
  Select as AriaSelect,
  SelectValue,
  Popover,
  type ListBoxItemProps,
  type SelectProps as AriaSelectProps,
  ListBox,
  ListBoxItem,
  composeRenderProps,
  Text,
  type Key,
  type SelectValueProps,
  ListBoxLoadMoreItem,
  type ListBoxLoadMoreItemProps,
  type ListBoxProps,
} from "react-aria-components";
import cx from "classnames";
import { ChevronDownIcon, ConfirmIcon } from "../../assets/icon";
import { FieldError, FieldHint, FieldLabel } from "../field/Field";

export type SelectProps<T extends object = object, M extends "single" | "multiple" = "single"> = {
  label?: React.ReactNode;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  items?: Iterable<T>;
  children?: React.ReactNode | ((item: T) => React.ReactNode);
  popoverClassName?: string;
  placement?: "top" | "bottom";
  maxHeight?: number;
  /** Offset between the Select Input and the Options Dropdown. @default 4 */
  offset?: number;
  /** Whether to display the textValue or the children of the selected item. @default "textValue" */
  display?: "text" | "children";
  /** Whether to show the info icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Custom render function for the selected value. */
  renderValue?: SelectValueProps<T>["children"];
  /** Custom trigger element to be used instead of the default button. */
  selectTrigger?: React.ReactNode;
  /** Custom render function for the empty state. */
  renderEmptyState?: ListBoxProps<T>["renderEmptyState"];
} & Omit<AriaSelectProps<T, M>, "children">;

function Select<T extends object, M extends "single" | "multiple" = "single">({
  label,
  isInvalid,
  description,
  errorMessage,
  children,
  className,
  items,
  popoverClassName,
  placement = "bottom",
  offset = 4,
  display = "text",
  maxHeight,
  showHintIcon = true,
  renderValue,
  selectTrigger,
  renderEmptyState,
  ...props
}: SelectProps<T, M>) {
  const isFieldInvalid = isInvalid || !!errorMessage;
  return (
    <AriaSelect
      isInvalid={isFieldInvalid}
      allowsEmptyCollection={!!renderEmptyState}
      className={composeRenderProps(className, (className, state) =>
        cx("pf-select", state.isOpen && "pf-select--open", className),
      )}
      {...props}
    >
      {label && <FieldLabel>{label}</FieldLabel>}
      {selectTrigger ?? (
        <Button className="pf-select__trigger">
          <SelectValue className={cx("pf-select__display", `pf-select__display--${display}`)}>
            {composeRenderProps(renderValue, (renderValue, { defaultChildren, selectedText }) =>
              renderValue !== undefined
                ? renderValue
                : display === "children"
                  ? defaultChildren
                  : selectedText || defaultChildren,
            )}
          </SelectValue>
          <ChevronDownIcon className="pf-select__icon" />
        </Button>
      )}
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
      <Popover
        className={cx("pf-select-popover", popoverClassName)}
        data-trigger="Select"
        offset={offset}
        placement={placement}
        maxHeight={maxHeight}
      >
        <ListBox className="pf-select-items" items={items} renderEmptyState={renderEmptyState}>
          {children}
        </ListBox>
      </Popover>
    </AriaSelect>
  );
}

export type SelectOptionProps = ListBoxItemProps;

function SelectOption({ className, textValue, children, ...props }: SelectOptionProps) {
  const value = textValue || (typeof children === "string" ? children : undefined);

  return (
    <ListBoxItem {...props} className={cx("pf-select-item", className)} textValue={value}>
      {composeRenderProps(children, (children, renderProps) => (
        <>
          {typeof children === "string" ? <Text slot="label">{children}</Text> : children}
          {renderProps.isSelected && (
            <ConfirmIcon aria-hidden="true" className="pf-select-item__icon" />
          )}
        </>
      ))}
    </ListBoxItem>
  );
}

function SelectLoadMore({ className, ...props }: ListBoxLoadMoreItemProps) {
  return (
    <ListBoxLoadMoreItem
      className={cx("pf-select-item", "pf-select-item--load-more", className)}
      {...props}
    />
  );
}

export type SelectKey = Key;

Select.Option = SelectOption;
Select.LoadMore = SelectLoadMore;

export { Select };
