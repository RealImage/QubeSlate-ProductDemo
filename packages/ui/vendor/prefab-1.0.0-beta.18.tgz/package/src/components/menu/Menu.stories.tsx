import { useState } from "react";
import {
  CheckboxIcon,
  CheckboxSelectedIcon,
  CircleIcon,
  MoreHorizontalIcon,
} from "../../assets/icon";
import { Button } from "../button/Button";
import { Menu, type MenuSelection } from "./Menu";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Menu",
  component: Menu,
  parameters: {
    layout: "centered",
  },
});

export const DefaultMenu = meta.story({
  render: () => (
    <Menu>
      <Button iconOnly aria-label="Open menu">
        <MoreHorizontalIcon />
      </Button>
      <Menu.Items placement="bottom left">
        <Menu.Item>Switch Company</Menu.Item>
        <Menu.Item>Logout</Menu.Item>
      </Menu.Items>
    </Menu>
  ),
});

export const CustomTrigger = meta.story({
  render: () => (
    <Menu>
      <Menu.Trigger>
        <span role="button">Custom Trigger</span>
      </Menu.Trigger>
      <Menu.Items placement="bottom">
        <Menu.Item>Switch Company</Menu.Item>
        <Menu.Item>Logout</Menu.Item>
      </Menu.Items>
    </Menu>
  ),
});

export const Submenu = meta.story({
  render: () => (
    <Menu>
      <Button>Open Menu</Button>
      <Menu.Items>
        <Menu.Item>Item 1</Menu.Item>
        <Menu.Item>Item 2</Menu.Item>
        <Menu.Item isDisabled>Item 3 (Disabled)</Menu.Item>
        <Menu.Submenu>
          <Menu.Item>Item with Submenu</Menu.Item>
          <Menu.Items placement="right" offset={8}>
            <Menu.Item>Submenu Item 1</Menu.Item>
            <Menu.Item>Submenu Item 2</Menu.Item>
            <Menu.Item>Submenu Item 3</Menu.Item>
          </Menu.Items>
        </Menu.Submenu>
      </Menu.Items>
    </Menu>
  ),
});

export const Sections = meta.story({
  render: () => (
    <Menu>
      <Button aria-label="Open menu" iconOnly>
        <MoreHorizontalIcon />
      </Button>
      <Menu.Items>
        <Menu.Section>
          <Menu.SectionHeader>Manage User</Menu.SectionHeader>
          <Menu.Item>Invite Users</Menu.Item>
          <Menu.Item>Logs</Menu.Item>
        </Menu.Section>
        <Menu.Section>
          <Menu.SectionHeader>Account</Menu.SectionHeader>
          <Menu.Item>Profile Settings</Menu.Item>
          <Menu.Item>Switch Account</Menu.Item>
          <Menu.Item>Logout</Menu.Item>
        </Menu.Section>
      </Menu.Items>
    </Menu>
  ),
});

export const MultilineText = meta.story({
  render: () => (
    <Menu>
      <Button>Theatres</Button>
      <Menu.Items>
        <Menu.Item textValue="Theatre 1">
          <div>
            <div>Theatre 1</div>
            <div style={{ color: "#6b7280" }}>Chennai, Tamil Nadu, India</div>
          </div>
        </Menu.Item>
        <Menu.Item textValue="Theatre 2">
          <div>
            <div>Theatre 2</div>
            <div style={{ color: "#6b7280" }}>Mumbai, Maharashtra, India</div>
          </div>
        </Menu.Item>
      </Menu.Items>
    </Menu>
  ),
});

export const MatchTargetWidth = meta.story({
  render: () => (
    <Menu>
      <Button>Open Menu</Button>
      <Menu.Items matchTargetWidth>
        <Menu.Item>Option 1</Menu.Item>
        <Menu.Item>Option 2</Menu.Item>
        <Menu.Item>Option 3</Menu.Item>
      </Menu.Items>
    </Menu>
  ),
});

const options = ["name", "email", "status", "last-updated"];

export const SingleSelection = meta.story({
  render: function Render() {
    const [selected, setSelected] = useState<MenuSelection>(new Set(["name"]));
    return (
      <Menu>
        <Button>Single Select</Button>
        <Menu.Items selectionMode="single" selectedKeys={selected} onSelectionChange={setSelected}>
          {options.map((option) => (
            <Menu.Item id={option} key={option}>
              {({ isSelected }) => (
                <>
                  {isSelected ? (
                    <CircleIcon width="16" height="16" />
                  ) : (
                    <span style={{ width: "16px" }} />
                  )}
                  {option
                    .split("-")
                    .map((word) => word[0].toUpperCase() + word.slice(1))
                    .join(" ")}
                </>
              )}
            </Menu.Item>
          ))}
        </Menu.Items>
      </Menu>
    );
  },
});

export const MultipleSelection = meta.story({
  render: () => (
    <Menu>
      <Button>Multiple Select</Button>
      <Menu.Items selectionMode="multiple" defaultSelectedKeys={["name", "email"]}>
        {options.map((option) => (
          <Menu.Item id={option} key={option}>
            {({ isSelected }) => (
              <>
                {isSelected ? <CheckboxSelectedIcon /> : <CheckboxIcon />}
                {option
                  .split("-")
                  .map((word) => word[0].toUpperCase() + word.slice(1))
                  .join(" ")}
              </>
            )}
          </Menu.Item>
        ))}
      </Menu.Items>
    </Menu>
  ),
});
