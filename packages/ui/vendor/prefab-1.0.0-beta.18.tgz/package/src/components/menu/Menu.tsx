import React from "react";
import {
  Menu as AriaMenu,
  MenuItem as AriaMenuItem,
  MenuSection as AriaMenuSection,
  MenuTrigger as AriaMenuTrigger,
  SubmenuTrigger as AriaSubmenuTrigger,
  Popover,
  Pressable,
  Text,
  Header as AriaHeader,
  type MenuItemProps as AriaMenuItemProps,
  type MenuProps as AriaMenuProps,
  type MenuSectionProps as AriaMenuSectionProps,
  type MenuTriggerProps as AriaMenuTriggerProps,
  type SubmenuTriggerProps as AriaSubmenuTriggerProps,
  type HeaderProps as AriaHeaderProps,
  type PopoverProps,
  composeRenderProps,
  type Selection,
} from "react-aria-components";
import cx from "classnames";
import { ChevronRightIcon } from "../../assets/icon";

export type MenuProps = AriaMenuTriggerProps;

function Menu({ children, ...props }: MenuProps) {
  return <AriaMenuTrigger {...props}>{children}</AriaMenuTrigger>;
}

export type MenuTriggerProps = React.ComponentProps<typeof Pressable>;

function MenuTrigger({ children, ...props }: MenuTriggerProps) {
  return <Pressable {...props}>{children}</Pressable>;
}

export type MenuItemsProps<T> = AriaMenuProps<T> & {
  /**
   * Whether the element should flip its orientation (e.g. top to bottom or left to right) when
   * there is insufficient room for it to render completely.
   */
  shouldFlip?: PopoverProps["shouldFlip"];
  /** The placement of the menu with respect to the trigger. */
  placement?: PopoverProps["placement"];
  /** The offset of the menu in pixels. @default 4 */
  offset?: number;
  /** The offset of the menu along the cross axis in pixels. */
  crossOffset?: number;
  /**
   * The placement padding that should be applied between the element and its
   * surrounding container.
   */
  containerPadding?: number;
  popoverClassName?: string;
  /** Whether the menu should match the width of the trigger element. @default false */
  matchTargetWidth?: boolean;
  /** The maximum height of the menu. */
  maxHeight?: PopoverProps["maxHeight"];
};

function MenuItems<T extends object>({
  className,
  offset = 4,
  shouldFlip,
  placement,
  crossOffset,
  containerPadding,
  popoverClassName,
  matchTargetWidth,
  children,
  maxHeight,
  ...props
}: MenuItemsProps<T>) {
  return (
    <Popover
      className={cx("pf-menu-popover", popoverClassName)}
      offset={offset}
      shouldFlip={shouldFlip}
      placement={placement}
      crossOffset={crossOffset}
      containerPadding={containerPadding}
      maxHeight={maxHeight}
    >
      <AriaMenu<T>
        className={cx(
          "pf-menu-items",
          { "pf-menu-items--match-width": matchTargetWidth },
          className,
        )}
        {...props}
      >
        {children}
      </AriaMenu>
    </Popover>
  );
}

export type MenuItemProps = AriaMenuItemProps;

function MenuItem({ className, children, ...props }: MenuItemProps) {
  const textValue = props.textValue || (typeof children === "string" ? children : undefined);
  return (
    <AriaMenuItem className={cx("pf-menu-item", className)} {...props} textValue={textValue}>
      {composeRenderProps(children, (children, renderProps) => (
        <>
          {typeof children === "string" ? <Text slot="label">{children}</Text> : children}
          {renderProps.hasSubmenu && (
            <ChevronRightIcon aria-hidden="true" className="pf-submenu-icon" />
          )}
        </>
      ))}
    </AriaMenuItem>
  );
}

export type MenuSectionProps<T> = AriaMenuSectionProps<T>;

function MenuSection<T extends object>({ className, children, ...props }: MenuSectionProps<T>) {
  return (
    <AriaMenuSection className={cx("pf-menu-section", className)} {...props}>
      {children}
    </AriaMenuSection>
  );
}

export type MenuSectionHeaderProps = AriaHeaderProps;

function MenuSectionHeader({ className, children, ...props }: MenuSectionHeaderProps) {
  return (
    <AriaHeader className={cx("pf-menu-section-header", className)} {...props}>
      {children}
    </AriaHeader>
  );
}

export type SubmenuTriggerProps = AriaSubmenuTriggerProps;

function Submenu({ children, ...props }: SubmenuTriggerProps) {
  return <AriaSubmenuTrigger {...props}>{children}</AriaSubmenuTrigger>;
}

export type MenuSelection = Selection;

Menu.Trigger = MenuTrigger;
Menu.Item = MenuItem;
Menu.Section = MenuSection;
Menu.SectionHeader = MenuSectionHeader;
Menu.Items = MenuItems;
Menu.Submenu = Submenu;

export { Menu };
