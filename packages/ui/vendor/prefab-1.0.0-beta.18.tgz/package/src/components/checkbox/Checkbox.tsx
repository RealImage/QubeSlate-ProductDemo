import { useMemo } from "react";
import {
  Checkbox as AriaCheckbox,
  CheckboxGroup as AriaCheckboxGroup,
  type CheckboxProps as AriaCheckboxProps,
  type CheckboxGroupProps as AriaCheckboxGroupProps,
} from "react-aria-components";
import cx from "classnames";
import { CheckboxIcon, CheckboxIntermediateIcon, CheckboxSelectedIcon } from "../../assets/icon";
import { FieldError, FieldHint, FieldLabel } from "../field/Field";

export type CheckboxProps = Omit<AriaCheckboxProps, "children"> & {
  children?: React.ReactNode;
  checkboxSize?: string;
  checkboxColor?: string;
};

export function Checkbox({
  children,
  className,
  checkboxSize,
  checkboxColor,
  ...props
}: CheckboxProps) {
  const checkboxStyles = useMemo(() => {
    return {
      "--checkbox-size": checkboxSize,
      "--checkbox-color": checkboxColor,
    } as React.CSSProperties;
  }, [checkboxSize, checkboxColor]);

  return (
    <AriaCheckbox className={cx("pf-checkbox", className)} {...props}>
      {({ isIndeterminate, isSelected, isDisabled }) => (
        <>
          <span
            className={cx(
              "pf-checkbox__indicator",
              isIndeterminate && "pf-checkbox__indicator--indeterminate",
              isSelected && "pf-checkbox__indicator--selected",
              isDisabled && "pf-checkbox__indicator--disabled",
            )}
            style={checkboxStyles}
          >
            {isIndeterminate ? (
              <CheckboxIntermediateIcon aria-hidden="true" viewBox="4 4 16 16" />
            ) : isSelected ? (
              <CheckboxSelectedIcon aria-hidden="true" viewBox="4 4 16 16" />
            ) : (
              <CheckboxIcon aria-hidden="true" viewBox="4 4 16 16" />
            )}
          </span>
          {children}
        </>
      )}
    </AriaCheckbox>
  );
}

export type CheckboxGroupProps = Omit<AriaCheckboxGroupProps, "children"> & {
  children?: React.ReactNode;
  label?: React.ReactNode;
  optional?: boolean;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  orientation?: "horizontal" | "vertical";
  itemsClassName?: string;
  showHintIcon?: boolean;
};

export function CheckboxGroup({
  label,
  description,
  errorMessage,
  children,
  orientation = "vertical",
  itemsClassName,
  className,
  optional,
  showHintIcon,
  isInvalid,
  ...props
}: CheckboxGroupProps) {
  const isFieldInvalid = isInvalid || !!errorMessage;
  return (
    <AriaCheckboxGroup
      className={cx("pf-checkbox-group", `pf-checkbox-group--${orientation}`, className)}
      isInvalid={isFieldInvalid}
      {...props}
    >
      {label && <FieldLabel optional={optional}>{label}</FieldLabel>}
      <div className={cx("pf-checkbox-group__items", itemsClassName)}>{children}</div>
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
    </AriaCheckboxGroup>
  );
}
