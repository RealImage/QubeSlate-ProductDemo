import { useState } from "react";
import { Checkbox, CheckboxGroup } from "./Checkbox";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Checkbox",
  component: Checkbox,
  parameters: { layout: "centered" },
  args: {
    children: "Checkbox Label",
  },
  subcomponents: { CheckboxGroup },
});

export const Default = meta.story({
  render: ({ children, ...props }) => <Checkbox {...props}>{children}</Checkbox>,
});

export const WithoutLabel = meta.story({
  parameters: {
    docs: {
      description: {
        story:
          "A checkbox without a visible label. Provide an `aria-label` prop for accessibility.",
      },
    },
  },
  args: {
    children: null,
    "aria-label": "Icon Only Checkbox Example",
  },
  render: (props) => <Checkbox {...props} />,
});

export const Controlled = meta.story({
  render: function Render({ children, ...props }) {
    const [value, setValue] = useState<"checked" | "unchecked" | "indeterminate">("indeterminate");
    return (
      <>
        <Checkbox
          {...props}
          isSelected={value === "checked"}
          isIndeterminate={value == "indeterminate"}
          onChange={() =>
            setValue((prev) =>
              prev === "indeterminate"
                ? "checked"
                : prev === "checked"
                  ? "unchecked"
                  : "indeterminate",
            )
          }
        >
          {children}
        </Checkbox>
        <output style={{ minWidth: 150, fontSize: "0.75rem", margin: "4px 0" }}>
          Current State: {value}
        </output>
      </>
    );
  },
});

export const Disabled = meta.story({
  args: {
    isDisabled: true,
    isSelected: false,
    isIndeterminate: false,
  },
  render: ({ children, ...props }) => <Checkbox {...props}>{children}</Checkbox>,
});

export const CheckboxGroupStory = meta.story({
  name: "Checkbox Group",
  render: function Render() {
    const [selectedValues, setSelectedValues] = useState<string[]>(["option1"]);
    return (
      <CheckboxGroup
        name="checkbox-group"
        label="Checkbox Group"
        orientation="vertical"
        value={selectedValues}
        onChange={setSelectedValues}
      >
        <Checkbox value="option1">Option 1</Checkbox>
        <Checkbox value="option2">Option 2</Checkbox>
        <Checkbox value="option3">Option 3</Checkbox>
      </CheckboxGroup>
    );
  },
});
