import { useState } from "react";
import { CalendarIcon, DownloadIcon, FilterAdjustIcon, SettingsIcon } from "../../assets/icon";
import { Button } from "../button/Button";
import { Tag } from "../tag/Tag";
import { TableControls } from "./TableControls";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/TableControls",
  component: TableControls,
  parameters: { layout: "padded" },
  args: {
    slot: "default",
  },
});

export const Default = meta.story({
  render: (props) => (
    <TableControls {...props}>
      <TableControls.Title>Table Title</TableControls.Title>
      <TableControls.Row>
        <TableControls.Section>
          <Button variant="default" size="medium">
            <CalendarIcon />
            01 Jul 2025 - 30 Jul 2025
          </Button>
          <TableControls.Search placeholder="Search" style={{ maxWidth: 350 }} />
          <Button variant="default">
            <FilterAdjustIcon />
            Filter
          </Button>
        </TableControls.Section>

        <TableControls.Section align="end">
          <Button variant="default">Download</Button>
          <Button variant="default">Upload CSV</Button>
          <Button variant="default" iconOnly aria-label="Settings">
            <SettingsIcon />
          </Button>
        </TableControls.Section>
      </TableControls.Row>
    </TableControls>
  ),
});

export const SingleRow = meta.story({
  render: (props) => (
    <TableControls {...props}>
      <TableControls.Row>
        <TableControls.Search placeholder="Search" style={{ flex: 1 }} />
        <Button>
          <FilterAdjustIcon />
        </Button>
        <Button variant="default">
          Export <DownloadIcon />
        </Button>
      </TableControls.Row>
    </TableControls>
  ),
});

export const MultipleRows = meta.story({
  render: (props) => (
    <TableControls {...props}>
      <TableControls.Row>
        <TableControls.Section>
          <TableControls.Title>Target Appliances</TableControls.Title>
          <Tag className="pf-table-controls__title-badge">250 Appliances</Tag>
        </TableControls.Section>
        <TableControls.Section align="end">
          <Button variant="primary">Add Appliance</Button>
        </TableControls.Section>
      </TableControls.Row>

      <TableControls.Row>
        <TableControls.Search placeholder="Search..." style={{ flex: 1 }} />
        <Button>Download</Button>
        <Button>Upload CSV</Button>
      </TableControls.Row>
    </TableControls>
  ),
});

export const ControlsForTableFooter = meta.story({
  args: {
    slot: "footer",
  },
  render: function Render(props) {
    const [pageSize, setPageSize] = useState(10);
    const [pagination, setPagination] = useState(1);
    return (
      <TableControls slot="footer" {...props}>
        <TableControls.Row>
          <TableControls.Caption>Showing {pageSize} of 100 entries</TableControls.Caption>
          <TableControls.Section align="end">
            <TableControls.PageSizeSelector
              value={pageSize}
              onChange={(value) => setPageSize(Number(value))}
            />
            <TableControls.Pagination
              currentPage={pagination}
              totalPages={100 / pageSize}
              onPageChange={setPagination}
            />
          </TableControls.Section>
        </TableControls.Row>
      </TableControls>
    );
  },
});
