import cx from "classnames";
import { CancelIcon, SearchIcon } from "../../assets/icon";
import { Input, type InputProps } from "../input/Input";
import { Pagination, type PaginationProps } from "../pagination/Pagination";
import { Select, type SelectProps } from "../select/Select";

type TableControlsProps = {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  /** Whether the controls are rendered in the table header (default) or footer. @default "default" */
  slot?: "default" | "footer";
};

function TableControls({ className, slot = "default", ...props }: TableControlsProps) {
  return (
    <div
      className={cx("pf-table-controls", `pf-table-controls--slot-${slot}`, className)}
      {...props}
    />
  );
}

type TableControlsRowProps = {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

function TableControlsRow({ className, style, ...props }: TableControlsRowProps) {
  return <div className={cx("pf-table-controls__row", className)} style={style} {...props} />;
}

type TableControlsSectionProps = {
  className?: string;
  style?: React.CSSProperties;
  /** The alignment of the section in the row. @default "start" */
  align?: "start" | "end";
  children: React.ReactNode;
};

function TableControlsSection({ className, align = "start", ...props }: TableControlsSectionProps) {
  return (
    <div
      className={cx(
        "pf-table-controls__section",
        `pf-table-controls__section--${align}`,
        className,
      )}
      {...props}
    />
  );
}

type TableControlsTitleProps = {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

function TableControlsTitle({ className, children, ...props }: TableControlsTitleProps) {
  return (
    <div className={cx("pf-table-controls__title", className)} {...props}>
      {children}
    </div>
  );
}

type TableControlsSearchProps = InputProps & {
  onClear?: () => void;
};

function TableControlsSearch({ onClear, ...props }: TableControlsSearchProps) {
  return (
    <Input
      aria-label="Search"
      suffix={props.value && onClear ? <CancelIcon aria-label="Clear Search" /> : <SearchIcon />}
      onSuffixClick={props.value && onClear ? onClear : undefined}
      {...props}
    />
  );
}

function TableControlsPagination(props: PaginationProps) {
  return <Pagination {...props} />;
}

function TableControlsPageSizeSelector({
  label = "Show",
  options = [10, 20, 50],
  className,
  ...props
}: {
  label?: string;
  options?: number[];
} & SelectProps) {
  return (
    <div className={cx("pf-table-controls__page-size-selector", className)}>
      {label && <span>{label}</span>}
      <Select aria-label="Select Page Size" {...props}>
        {options.map((size) => (
          <Select.Option key={size} id={size}>
            {size}
          </Select.Option>
        ))}
      </Select>
    </div>
  );
}

type TableControlsCaptionProps = {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

function TableControlsCaption({ className, ...props }: TableControlsCaptionProps) {
  return <div className={cx("pf-table-controls__caption", className)} {...props} />;
}

TableControls.Row = TableControlsRow;
TableControls.Section = TableControlsSection;
TableControls.Title = TableControlsTitle;
TableControls.Search = TableControlsSearch;
TableControls.Pagination = TableControlsPagination;
TableControls.PageSizeSelector = TableControlsPageSizeSelector;
TableControls.Caption = TableControlsCaption;

export { TableControls };
