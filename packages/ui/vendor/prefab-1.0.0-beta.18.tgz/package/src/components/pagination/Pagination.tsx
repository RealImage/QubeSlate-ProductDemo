import { useState } from "react";
import cx from "classnames";
import { ChevronLeftIcon, ChevronRightIcon } from "../../assets/icon";
import { Button } from "../button/Button";

type PageItem = number | "ellipsis-start" | "ellipsis-end";

export type PaginationProps = {
  /** Total number of pages */
  totalPages?: number;
  /** Controlled current page number. */
  currentPage?: number;
  /** Initial page number for uncontrolled usage. @default 1 */
  defaultPage?: number;
  /** Called when the user requests a different page */
  onPageChange?: (page: number) => void;
  /** Additional class name applied to the root `<nav>` element */
  className?: string;
  /** Whether there are more pages to show */
  hasMore?: boolean;
  /** Specifies the number of items to show before and after the current page */
  siblingCount?: number;
};

function buildPageItems(totalPages: number, currentPage: number, siblingCount: number): PageItem[] {
  if (totalPages <= 0) return [];

  const totalVisible = 2 * siblingCount + 5;

  if (totalPages <= totalVisible) {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  const leftSiblingIndex = Math.max(2, currentPage - siblingCount);
  const rightSiblingIndex = Math.min(totalPages - 1, currentPage + siblingCount);

  const showLeftEllipsis = leftSiblingIndex > siblingCount + 2;
  const showRightEllipsis = rightSiblingIndex < totalPages - siblingCount - 1;

  if (!showLeftEllipsis) {
    const leftRange = Array.from({ length: 2 * siblingCount + 3 }, (_, i) => i + 1);
    return [...leftRange, "ellipsis-end", totalPages];
  }

  if (!showRightEllipsis) {
    const rightRange = Array.from(
      { length: 2 * siblingCount + 3 },
      (_, i) => totalPages - (2 * siblingCount + 2) + i,
    );
    return [1, "ellipsis-start", ...rightRange];
  }

  const middleRange = Array.from(
    { length: rightSiblingIndex - leftSiblingIndex + 1 },
    (_, i) => leftSiblingIndex + i,
  );
  return [1, "ellipsis-start", ...middleRange, "ellipsis-end", totalPages];
}

export function Pagination({
  totalPages,
  currentPage,
  defaultPage = 1,
  siblingCount = 1,
  hasMore,
  className,
  onPageChange,
}: PaginationProps) {
  const [internalPage, setInternalPage] = useState(defaultPage);

  const value = currentPage === undefined ? internalPage : currentPage;

  const pageItems =
    totalPages !== undefined ? buildPageItems(totalPages, value, siblingCount) : [value];

  const goTo = (page: number) => {
    if (currentPage === undefined) setInternalPage(page);
    if (onPageChange) onPageChange(page);
  };

  return (
    <nav aria-label="Pagination" className={cx("pf-pagination", className)}>
      <Button
        iconOnly
        variant="secondary"
        isDisabled={value <= 1}
        onClick={() => goTo(Math.max(1, value - 1))}
        aria-label="Previous page"
        className="pf-pagination__nav"
      >
        <ChevronLeftIcon aria-hidden="true" />
      </Button>

      {pageItems.length > 0 && (
        <div className="pf-pagination__pages" aria-label="Page list">
          {pageItems.map((item) =>
            typeof item === "number" ? (
              <Button
                key={item}
                className="pf-pagination__item"
                variant="secondary"
                selected={item === value}
                aria-label={`Page ${item}`}
                aria-current={item === value ? "page" : undefined}
                onClick={() => goTo(item)}
              >
                {item}
              </Button>
            ) : (
              <span key={item} className="pf-pagination__ellipsis" aria-hidden="true">
                &hellip;
              </span>
            ),
          )}
        </div>
      )}

      <Button
        iconOnly
        variant="secondary"
        isDisabled={value >= (totalPages || 0) && !hasMore}
        onClick={() => goTo(totalPages ? Math.min(totalPages, value + 1) : value + 1)}
        aria-label="Next page"
        className="pf-pagination__nav"
      >
        <ChevronRightIcon aria-hidden="true" />
      </Button>
    </nav>
  );
}
