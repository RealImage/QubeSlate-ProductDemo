import { useState } from "react";
import { Pagination } from "./Pagination";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Pagination",
  component: Pagination,
  parameters: { layout: "centered" },
});

export const Default = meta.story({
  args: { totalPages: 15 },
  render: function Render(props) {
    const [page, setPage] = useState(1);
    return <Pagination {...props} currentPage={page} onPageChange={setPage} />;
  },
});

export const SinglePage = meta.story({
  args: { totalPages: 1 },
  render: (props) => <Pagination {...props} />,
});

export const UnknownTotalPages = meta.story({
  render: function Render(props) {
    const [page, setPage] = useState(2);
    const hasMore = page < 5;

    return <Pagination {...props} currentPage={page} onPageChange={setPage} hasMore={hasMore} />;
  },
});
