import { action } from "storybook/actions";
import { Button } from "../button/Button";
import { CSVSelectIcon, FolderIcon } from "../../assets/icon";
import { FileTrigger } from "./FileTrigger";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/FileTrigger",
  component: FileTrigger,
  parameters: { layout: "centered" },
  args: {
    allowsMultiple: false,
    acceptDirectory: false,
    acceptedFileTypes: ["text/csv", "image/*", "application/json"],
  },
});

export const Default = meta.story({
  render: (props) => {
    return (
      <FileTrigger
        {...props}
        onSelect={(e) => {
          const files = e ? Array.from(e) : [];
          const filenames = files.map((file) => file.name);
          action("Selected File")(filenames);
        }}
      >
        <Button>
          Upload File
          <CSVSelectIcon />
        </Button>
      </FileTrigger>
    );
  },
});

export const AllowMultiple = meta.story({
  args: {
    allowsMultiple: true,
  },
  render: (props) => {
    return (
      <FileTrigger
        {...props}
        onSelect={(e) => {
          const files = e ? Array.from(e) : [];
          const filenames = files.map((file) => file.name);
          action("Selected Files")(filenames);
        }}
      >
        <Button>
          Upload Files
          <CSVSelectIcon />
        </Button>
      </FileTrigger>
    );
  },
});

export const AcceptDirectory = meta.story({
  args: {
    acceptDirectory: true,
  },
  render: (props) => {
    return (
      <FileTrigger
        {...props}
        onSelect={(e) => {
          const files = e ? Array.from(e) : [];
          const filenames = files.map((file) => file.webkitRelativePath || file.name);
          action("Selected Directory")({
            directoryName: e?.[0]?.webkitRelativePath.split("/")[0],
            files: filenames,
          });
        }}
      >
        <Button>
          Upload Directory
          <FolderIcon />
        </Button>
      </FileTrigger>
    );
  },
});

export const CustomElement = meta.story({
  args: {
    withPressable: true,
  },
  render: (props) => {
    return (
      <FileTrigger
        withPressable
        {...props}
        onSelect={(e) => {
          const files = e ? Array.from(e) : [];
          const filenames = files.map((file) => file.name);
          action("Selected Files")(filenames);
        }}
      >
        <span role="button">Click here to upload</span>
      </FileTrigger>
    );
  },
});
