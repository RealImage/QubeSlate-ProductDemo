import {
  FileTrigger as AriaFileTrigger,
  Pressable,
  type FileTriggerProps as AriaFileTriggerProps,
} from "react-aria-components";

type FileTriggerProps = Omit<AriaFileTriggerProps, "children"> & {
  withPressable?: boolean;
  children?: React.ComponentProps<typeof Pressable>["children"];
};

export function FileTrigger({ children, withPressable, ...props }: FileTriggerProps) {
  return (
    <AriaFileTrigger {...props}>
      {withPressable && children ? <Pressable>{children}</Pressable> : children}
    </AriaFileTrigger>
  );
}
