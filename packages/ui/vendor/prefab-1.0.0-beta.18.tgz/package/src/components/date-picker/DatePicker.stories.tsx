import { useState } from "react";
import { DatePicker } from "./DatePicker";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/DatePicker",
  component: DatePicker,
  parameters: { layout: "centered" },
  args: {
    label: "Date Picker",
    placeholder: "Select a date",
  },
  decorators: [
    (Story) => (
      <div style={{ width: "min(242px, 70vw)", minHeight: "12rem" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => <DatePicker {...props} />,
});

export const WithDefaultValue = meta.story({
  render: function Render(props) {
    return <DatePicker {...props} defaultValue="2026-05-03" />;
  },
});

export const Controlled = meta.story({
  render: function Render(props) {
    const [date, setDate] = useState<string | null>("2026-05-03");
    return (
      <>
        <DatePicker {...props} value={date} onChange={setDate} />
        <output style={{ minWidth: 150, fontSize: "0.75rem", margin: "4px 0" }}>
          Selected: {date ?? "None"}
        </output>
      </>
    );
  },
});

export const WithMinMax = meta.story({
  render: (props) => (
    <DatePicker {...props} minValue="2026-03-10" maxValue="2026-04-10" defaultValue="2026-03-12" />
  ),
});

export const UnavailableDates = meta.story({
  args: {
    description: "Saturdays and Sundays are unavailable.",
  },
  render: (props) => {
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return (
      <DatePicker
        {...props}
        isDateUnavailable={(date) =>
          /* Disable weekends (Saturday=6, Sunday=0) */
          date?.toDate(timezone).getDay() === 0 || date?.toDate(timezone).getDay() === 6
        }
        defaultValue="2026-03-12"
      />
    );
  },
});
