import { useState } from "react";
import { DateRangePicker } from "./DateRangePicker";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/DateRangePicker",
  component: DateRangePicker,
  parameters: { layout: "centered" },
  args: {
    label: "Date Range Picker",
    placeholder: "Select date range",
  },
  decorators: [
    (Story) => (
      <div style={{ width: "min(242px, 70vw)", minHeight: "12rem" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => <DateRangePicker {...props} />,
});

export const WithDefaultValue = meta.story({
  render: () => (
    <DateRangePicker label="Date Range" defaultValue={{ start: "2026-01-02", end: "2026-01-12" }} />
  ),
});

export const Controlled = meta.story({
  render: function Render() {
    const [range, setRange] = useState<{ start: string; end: string } | null>({
      start: "2026-01-02",
      end: "2026-01-12",
    });
    return (
      <>
        <DateRangePicker label="Controlled Date Range" value={range} onChange={setRange} />
        <output style={{ minWidth: 150, fontSize: "0.75rem", margin: "4px 0" }}>
          Selected: {range ? range.start + " to " + range.end : "None"}
        </output>
      </>
    );
  },
});
