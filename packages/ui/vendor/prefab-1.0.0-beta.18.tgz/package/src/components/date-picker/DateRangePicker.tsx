import { useContext, useRef, useState, useMemo, useId } from "react";
import {
  DateRangePicker as AriaDateRangePicker,
  Button as AriaButton,
  DateInput,
  DateSegment,
  I18nProvider,
  Popover,
  DateRangePickerStateContext,
  Input,
  Group,
  type DateValue,
  type PopoverProps,
  type DateRangePickerProps as AriaDateRangePickerProps,
  type RangeValue,
} from "react-aria-components";
import { getLocalTimeZone, fromDate } from "@internationalized/date";
import cx from "classnames";
import { CalendarIcon } from "../../assets/icon";
import { FieldError, FieldHint, FieldLabel } from "../field/Field";
import { RangeCalendar } from "../calendar/RangedCalendar";
import {
  dateValueToIsoString,
  defaultFormatDateValue,
  defaultParseDateValue,
  isValidDate,
  parseAriaDateTime,
  parseAriaDateTimeRange,
} from "../../utils/dateUtils";

export type DateRangePickerProps = {
  className?: string;
  /** The current value (controlled). ISO 8601 string range: {start: "2026-05-03", end: "2026-05-10"}. */
  value?: { start: string; end: string } | null;
  /** The default value (uncontrolled). ISO 8601 string range. */
  defaultValue?: { start: string; end: string } | null;
  /** Handler called when the value changes. Returns ISO 8601 string range or null. */
  onChange?: (
    range: { start: string; end: string } | null,
    rawRange: RangeValue<DateValue> | null,
  ) => void;
  /** The input variant to use. @default "text" */
  inputVariant?: "text" | "segmented";
  /** Label text for date range picker. */
  label?: string;
  /** Popover placement. */
  placement?: PopoverProps["placement"];
  /** Minimum allowed date. ISO 8601 string. e.g. "2026-05-03" */
  minValue?: string | null;
  /** Maximum allowed date. ISO 8601 string. e.g. "2026-05-03" */
  maxValue?: string | null;
  /** Whether to show the info icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Whether to show the optional label. */
  optional?: boolean;
  /** Description text shown below the input. */
  description?: string;
  /** Error message text shown below the input when in an error state. */
  errorMessage?: string;
  /** Locale to use for the date picker. @default "en-US" */
  locale?: string;
  /** Placeholder text for the input. */
  placeholder?: string;
  /** Separator between start and end date in the text input. @default " - " */
  rangeSeparator?: string;
  /**
   * Custom formatter for a single date value in the text input.
   * Applied to both start and end dates.
   */
  formatValue?: (date: Date) => string;
  /**
   * Custom parser for a single date value in the text input.
   * Applied to both start and end dates. Should return null when parsing fails.
   */
  parseValue?: (input: string) => Date | null;
  /** Custom class name for the popover. */
  popoverClassName?: string | null;
  /** Prefix element to be shown inside the input. */
  prefix?: React.ReactNode;
  /** Suffix element to be shown inside the input. */
  suffix?: React.ReactNode;
} & Omit<
  AriaDateRangePickerProps<DateValue>,
  "value" | "defaultValue" | "onChange" | "minValue" | "maxValue"
>;

export function DateRangePicker({
  value,
  defaultValue,
  onChange,
  inputVariant = "text",
  label,
  placement = "bottom",
  minValue,
  maxValue,
  showHintIcon = true,
  isInvalid,
  className,
  optional,
  description,
  errorMessage,
  locale = "en-US",
  placeholder,
  rangeSeparator = " - ",
  formatValue,
  parseValue,
  popoverClassName,
  prefix,
  suffix,
  ...props
}: DateRangePickerProps) {
  const isFieldInvalid = !!errorMessage || isInvalid;
  const triggerRef = useRef<HTMLDivElement>(null);
  const labelId = useId();

  const ariaDefaultValue = useMemo(() => parseAriaDateTimeRange(defaultValue), [defaultValue]);
  const ariaValue = useMemo(() => parseAriaDateTimeRange(value), [value]);
  const ariaMinValue = useMemo(() => parseAriaDateTime(minValue), [minValue]);
  const ariaMaxValue = useMemo(() => parseAriaDateTime(maxValue), [maxValue]);

  const handleChange = (dateRange: RangeValue<DateValue> | null) => {
    if (onChange) {
      const formattedRange = dateRange
        ? { start: dateValueToIsoString(dateRange.start), end: dateValueToIsoString(dateRange.end) }
        : null;
      onChange(formattedRange, dateRange);
    }
  };

  return (
    <I18nProvider locale={locale}>
      <AriaDateRangePicker
        value={ariaValue}
        defaultValue={ariaDefaultValue}
        onChange={handleChange}
        minValue={ariaMinValue}
        maxValue={ariaMaxValue}
        className={cx("pf-date-picker", "pf-date-picker--range", className)}
        shouldForceLeadingZeros
        aria-label="Date Range Picker"
        isInvalid={isFieldInvalid}
        {...props}
      >
        {label && (
          <FieldLabel
            htmlFor={inputVariant === "text" ? labelId : undefined}
            elementType="label"
            optional={optional}
          >
            {label}
          </FieldLabel>
        )}
        <div className="pf-date-picker__field" ref={triggerRef}>
          {prefix}
          <div className="pf-date-picker__input-wrapper">
            {inputVariant === "segmented" ? (
              <DateRangePickerSegmentedInput rangeSeparator={rangeSeparator} />
            ) : (
              <DateRangePickerInput
                id={labelId}
                disabled={props.isDisabled}
                placeholder={placeholder}
                rangeSeparator={rangeSeparator}
                formatDateValue={formatValue}
                parseDateValue={parseValue}
              />
            )}
          </div>
          <AriaButton className="pf-date-picker__button">{suffix ?? <CalendarIcon />}</AriaButton>
        </div>
        {description && !errorMessage && (
          <FieldHint showIcon={showHintIcon}>{description}</FieldHint>
        )}
        {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
        <Popover
          aria-label="Date Range Picker Popover"
          className={cx("pf-date-picker__popover", popoverClassName)}
          placement={placement}
          triggerRef={triggerRef}
        >
          <RangeCalendar />
        </Popover>
      </AriaDateRangePicker>
    </I18nProvider>
  );
}

function DateRangePickerSegmentedInput({ rangeSeparator }: { rangeSeparator: string }) {
  return (
    <Group className="pf-date-picker__segment-group">
      <DateInput slot="start">
        {(segment) => <DateSegment className="pf-date-picker__segment" segment={segment} />}
      </DateInput>
      <span aria-hidden="true" className="pf-date-picker__separator">
        {rangeSeparator}
      </span>
      <DateInput slot="end">
        {(segment) => <DateSegment className="pf-date-picker__segment" segment={segment} />}
      </DateInput>
    </Group>
  );
}

function DateRangePickerInput({
  id,
  disabled,
  placeholder,
  rangeSeparator,
  formatDateValue,
  parseDateValue,
}: {
  id: string;
  disabled?: boolean;
  placeholder?: string;
  rangeSeparator: string;
  formatDateValue?: (date: Date) => string;
  parseDateValue?: (input: string) => Date | null;
}) {
  const state = useContext(DateRangePickerStateContext);
  const formatDate = useMemo(() => formatDateValue ?? defaultFormatDateValue, [formatDateValue]);
  const parseDate = useMemo(() => parseDateValue ?? defaultParseDateValue, [parseDateValue]);

  const formattedDate =
    state && state.value && state.value.start && state.value.end
      ? formatDate(state.value.start.toDate(getLocalTimeZone())) +
        rangeSeparator +
        formatDate(state.value.end.toDate(getLocalTimeZone()))
      : "";

  const [inputValue, setInputValue] = useState(formattedDate);
  const [oldInputValue, setOldInputValue] = useState(formattedDate);
  const [isInputFocused, setIsInputFocused] = useState(false);

  if (formattedDate !== oldInputValue && !isInputFocused) {
    setOldInputValue(formattedDate);
    setInputValue(formattedDate);
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.trim();
    setInputValue(value);
    const [startText, endText] = value.split("-");
    const startDate = parseDate(startText.trim());
    const endDate = parseDate(endText.trim());

    if (startDate && endDate && isValidDate(startDate) && isValidDate(endDate)) {
      const start = fromDate(startDate, getLocalTimeZone());
      const end = fromDate(endDate, getLocalTimeZone());
      state?.setValue({ start, end });
      state?.commitValidation();
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsInputFocused(false);
    if (state?.displayValidation.isInvalid || !e.target.value.trim()) {
      state?.setValue(null);
      setInputValue("");
    } else {
      setInputValue(formattedDate);
    }
    state?.commitValidation();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      state?.setOpen(true);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
    } else {
      state?.setOpen(false);
    }
  };

  return (
    <Input
      id={id}
      disabled={disabled}
      onFocus={() => setIsInputFocused(true)}
      aria-label="Date Range Picker Input"
      data-react-aria-top-layer
      className="pf-date-picker__input"
      placeholder={placeholder}
      value={inputValue}
      onClick={() => state?.setOpen(true)}
      onKeyDown={handleKeyDown}
      onChange={handleChange}
      onBlur={handleBlur}
    />
  );
}
