import { useContext, useRef, useState, useMemo, useId } from "react";
import {
  DatePicker as AriaDatePicker,
  Button as AriaButton,
  DateInput,
  DateSegment,
  I18nProvider,
  Popover,
  DatePickerStateContext,
  Input,
  type DateValue,
  type PopoverProps,
  type DatePickerProps as AriaDatePickerProps,
  Group,
} from "react-aria-components";
import { fromDate, getLocalTimeZone } from "@internationalized/date";
import cx from "classnames";
import { CalendarIcon } from "../../assets/icon";
import { FieldLabel, FieldHint, FieldError } from "../field/Field";
import { Calendar } from "../calendar/Calendar";
import {
  dateValueToIsoString,
  defaultFormatDateValue,
  defaultParseDateValue,
  isValidDate,
  parseAriaDateTime,
} from "../../utils/dateUtils";

export type DatePickerProps = {
  className?: string;
  /** The current value (controlled). ISO 8601 string: "2026-05-03" (date only) or "2026-05-03T06:03:00" (with time). */
  value?: string | null;
  /** The default value (uncontrolled). ISO 8601 string. */
  defaultValue?: string | null;
  /** Handler called when the value changes. Returns ISO 8601 string or null. */
  onChange?: (date: string | null) => void;
  /** The input variant to use. @default "text" */
  inputVariant?: "text" | "segmented";
  /** Label text for input and segmented variants. */
  label?: string;
  /** Description/hint text. */
  description?: string;
  /** Error message to display. */
  errorMessage?: string;
  /** Shows "Optional" label. */
  optional?: boolean;
  /** Popover placement. */
  placement?: PopoverProps["placement"];
  /** Minimum allowed date. ISO 8601 string. */
  minValue?: string;
  /** Maximum allowed date. ISO 8601 string. */
  maxValue?: string;
  /** Whether to show the info icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Whether the input is invalid. */
  isInvalid?: boolean;
  /** Placeholder text for the input. */
  placeholder?: string;
  /** Locale to use for the date picker. @default "en-US" */
  locale?: string;
  /** Prefix element to be shown inside the input. */
  prefix?: React.ReactNode;
  /** Suffix element to be shown inside the input. */
  suffix?: React.ReactNode;
  /** Custom class name for the popover. */
  popoverClassName?: string;
  /** Custom formatter for a single date value in the text input. */
  formatValue?: (date: Date) => string;
  /** Custom parser for a single date value in the text input. */
  parseValue?: (input: string) => Date | null;
} & Omit<
  AriaDatePickerProps<DateValue>,
  "value" | "defaultValue" | "onChange" | "minValue" | "maxValue"
>;

export function DatePicker({
  value,
  defaultValue,
  onChange,
  inputVariant = "text",
  label,
  description,
  errorMessage,
  optional,
  placement = "bottom",
  minValue,
  maxValue,
  showHintIcon = true,
  isInvalid,
  className,
  placeholder,
  locale = "en-US",
  prefix,
  suffix,
  popoverClassName,
  formatValue,
  parseValue,
  ...props
}: DatePickerProps) {
  const labelId = useId();
  const triggerRef = useRef<HTMLDivElement>(null);
  const isFieldInvalid = !!errorMessage || isInvalid;

  const ariaValue = useMemo(() => parseAriaDateTime(value), [value]);
  const ariaDefaultValue = useMemo(() => parseAriaDateTime(defaultValue), [defaultValue]);
  const ariaMinValue = useMemo(() => parseAriaDateTime(minValue), [minValue]);
  const ariaMaxValue = useMemo(() => parseAriaDateTime(maxValue), [maxValue]);

  const handleChange = (dateValue: DateValue | null) => {
    if (onChange) {
      onChange(dateValue ? dateValueToIsoString(dateValue) : null);
    }
  };

  return (
    <I18nProvider locale={locale}>
      <AriaDatePicker
        className={cx("pf-date-picker", className)}
        value={ariaValue}
        defaultValue={ariaDefaultValue}
        onChange={handleChange}
        minValue={ariaMinValue}
        maxValue={ariaMaxValue}
        shouldForceLeadingZeros
        isInvalid={isFieldInvalid}
        {...props}
      >
        {label && (
          <FieldLabel
            htmlFor={inputVariant === "text" ? labelId : undefined}
            elementType="label"
            optional={optional}
          >
            {label}
          </FieldLabel>
        )}
        <div className="pf-date-picker__field" ref={triggerRef}>
          {prefix}
          <div className="pf-date-picker__input-wrapper">
            {inputVariant === "segmented" ? (
              <Group>
                <DateInput>
                  {(segment) => (
                    <DateSegment className="pf-date-picker__segment" segment={segment} />
                  )}
                </DateInput>
              </Group>
            ) : (
              <DatePickerInput
                id={labelId}
                disabled={props.isDisabled}
                placeholder={placeholder}
                formatValue={formatValue}
                parseValue={parseValue}
              />
            )}
          </div>
          <AriaButton className="pf-date-picker__button">{suffix ?? <CalendarIcon />}</AriaButton>
        </div>
        {description && !errorMessage && (
          <FieldHint showIcon={showHintIcon}>{description}</FieldHint>
        )}
        {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
        <Popover
          aria-label="Date Picker Popover"
          className={cx("pf-date-picker__popover", popoverClassName)}
          placement={placement}
          triggerRef={triggerRef}
        >
          <Calendar />
        </Popover>
      </AriaDatePicker>
    </I18nProvider>
  );
}

function DatePickerInput({
  id,
  disabled,
  placeholder,
  formatValue,
  parseValue,
}: {
  id?: string;
  disabled?: boolean;
  placeholder?: string;
  formatValue?: (date: Date) => string;
  parseValue?: (input: string) => Date | null;
}) {
  const state = useContext(DatePickerStateContext);

  const formatDate = useMemo(() => formatValue ?? defaultFormatDateValue, [formatValue]);
  const parseDate = useMemo(() => parseValue ?? defaultParseDateValue, [parseValue]);

  const formattedDate =
    state && state.value ? formatDate(state.value.toDate(getLocalTimeZone())) : "";

  const [inputValue, setInputValue] = useState(formattedDate);
  const [oldInputValue, setOldInputValue] = useState(formattedDate);
  const [isInputFocused, setIsInputFocused] = useState(false);

  if (formattedDate !== oldInputValue && !isInputFocused) {
    setOldInputValue(formattedDate);
    setInputValue(formattedDate);
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.trim();
    setInputValue(value);

    const parsedDate = parseDate(value.trim());

    if (parsedDate && isValidDate(parsedDate)) {
      const date = fromDate(parsedDate, getLocalTimeZone());
      state?.setValue(date);
      state?.commitValidation();
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsInputFocused(false);
    if (state?.displayValidation.isInvalid || !e.target.value.trim()) {
      state?.setValue(null);
      setInputValue("");
    } else {
      setInputValue(formattedDate);
    }
    state?.commitValidation();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      state?.setOpen(true);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
    } else {
      state?.setOpen(false);
    }
  };

  return (
    <Input
      id={id}
      disabled={disabled}
      aria-label="Date Picker Input"
      data-react-aria-top-layer
      className="pf-date-picker__input"
      placeholder={placeholder}
      value={inputValue}
      onClick={() => state?.setOpen(true)}
      onKeyDown={handleKeyDown}
      onChange={handleChange}
      onBlur={handleBlur}
      onFocus={() => setIsInputFocused(true)}
    />
  );
}
