import { useMemo, useRef, useState } from "react";
import {
  TimeField as AriaTimeField,
  DateInput,
  DateSegment,
  Group,
  I18nProvider,
  Popover,
  Button as AriaButton,
  type PopoverProps,
  type TimeFieldProps as AriaTimeFieldProps,
} from "react-aria-components";
import { Time } from "@internationalized/date";
import cx from "classnames";
import { stringToTime } from "../../utils/dateUtils";
import { ClockIcon } from "../../assets/icon";
import { FieldLabel, FieldHint, FieldError } from "../field/Field";
import { TimePanel } from "./TimePanel";

export type TimePickerProps = {
  /** The current value (controlled). ISO 8601 time string: "06:03:00" or "06:03" (seconds optional). */
  value?: string | null;
  /** The default value (uncontrolled). ISO 8601 time string. */
  defaultValue?: string | null;
  /** Handler called when the value changes. Returns ISO 8601 time string or null. */
  onChange?: (time: string | null, rawTime: Time | null) => void;
  /** Label text for input and segmented variants. */
  label?: string;
  /** Description/hint text. */
  description?: string;
  /** Error message to display. */
  errorMessage?: string;
  /** Shows "Optional" label. */
  optional?: boolean;
  /** Popover placement. */
  placement?: PopoverProps["placement"];
  /** Minimum allowed time. ISO 8601 time string. e.g. "06:03:00" */
  minValue?: string | null;
  /** Maximum allowed time. ISO 8601 time string. e.g. "18:00:00" */
  maxValue?: string | null;
  /** Show hint icon next to the hint text. @default true */
  showHintIcon?: boolean;
  /** Show a picker to select the time. */
  showPicker?: boolean;
  /** Locale to use for the time picker. @default "en-US" */
  locale?: string;
  /** Content to display before the input. */
  prefix?: React.ReactNode;
  /** Content to display after the input. */
  suffix?: React.ReactNode;
} & Omit<AriaTimeFieldProps<Time>, "value" | "defaultValue" | "onChange" | "minValue" | "maxValue">;

export function TimePicker({
  value,
  defaultValue,
  onChange,
  label,
  description,
  errorMessage,
  optional,
  hourCycle = 12,
  placement = "bottom start",
  showHintIcon = false,
  minValue,
  maxValue,
  showPicker,
  className,
  locale = "en-US",
  suffix,
  prefix,
  ...props
}: TimePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const triggerRef = useRef<HTMLDivElement>(null);

  const ariaValue = useMemo(() => stringToTime(value), [value]);
  const ariaDefaultValue = useMemo(() => stringToTime(defaultValue), [defaultValue]);
  const ariaMinValue = useMemo(() => stringToTime(minValue), [minValue]);
  const ariaMaxValue = useMemo(() => stringToTime(maxValue), [maxValue]);

  const handleChange = (time: Time | null) => {
    if (onChange) onChange(time ? time.toString() : null, time);
  };

  return (
    <I18nProvider locale={locale}>
      <AriaTimeField
        value={ariaValue}
        defaultValue={ariaDefaultValue}
        onChange={handleChange}
        shouldForceLeadingZeros
        hourCycle={hourCycle}
        minValue={ariaMinValue}
        maxValue={ariaMaxValue}
        hideTimeZone
        className={cx("pf-time-picker", showPicker && "pf-time-picker--with-picker", className)}
        {...props}
      >
        {label && <FieldLabel optional={optional}>{label}</FieldLabel>}
        <Group ref={triggerRef} className="pf-time-picker__field">
          {prefix}
          <DateInput className="pf-time-picker__input">
            {(segment) => <DateSegment className="pf-time-picker__segment" segment={segment} />}
          </DateInput>
          <AriaButton
            isDisabled={props.isDisabled}
            className="pf-time-picker__button"
            onPress={() => setIsOpen(!isOpen)}
            aria-label="Open time picker"
          >
            {suffix ?? <ClockIcon />}
          </AriaButton>
        </Group>
        {description && !errorMessage && (
          <FieldHint showIcon={showHintIcon}>{description}</FieldHint>
        )}
        {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
        {showPicker && (
          <Popover
            aria-label="Time Picker Panel"
            isOpen={isOpen}
            onOpenChange={setIsOpen}
            triggerRef={triggerRef}
            placement={placement}
            className="pf-time-picker__popover"
          >
            <TimePanel hourCycle={hourCycle} />
          </Popover>
        )}
      </AriaTimeField>
    </I18nProvider>
  );
}
