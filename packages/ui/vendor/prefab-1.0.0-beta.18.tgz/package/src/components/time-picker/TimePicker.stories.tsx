import { useState } from "react";
import { TimePicker } from "./TimePicker";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/TimePicker",
  component: TimePicker,
  parameters: { layout: "centered" },
  args: {
    label: "Time Picker",
  },
  decorators: [
    (Story) => (
      <div style={{ minWidth: "min(120px, 70vw)", minHeight: "12rem" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: () => <TimePicker label="Time" />,
});

export const WithPicker = meta.story({
  args: {
    showPicker: true,
  },
  render: (props) => <TimePicker {...props} />,
});

export const TwentyFourHour = meta.story({
  name: "24-Hour Clock",
  args: {
    label: "Time (24h)",
    hourCycle: 24,
    showPicker: true,
  },
  render: (props) => <TimePicker {...props} />,
});

export const WithSeconds = meta.story({
  name: "With Seconds",
  args: {
    label: "Time",
    granularity: "second",
    showPicker: true,
  },
  render: (props) => <TimePicker {...props} />,
});

export const WithSeconds24h = meta.story({
  name: "With Seconds (24-Hour)",
  args: {
    label: "Time (24h)",
    hourCycle: 24,
    granularity: "second",
    showPicker: true,
  },
  render: (props) => <TimePicker {...props} />,
});

export const WithDefaultValue = meta.story({
  args: {
    defaultValue: "12:00:00",
    showPicker: true,
  },
  render: (props) => {
    return <TimePicker {...props} />;
  },
});

export const Controlled = meta.story({
  args: {
    label: "Controlled Time",
    showPicker: true,
  },
  render: function Render(props) {
    const [time, setTime] = useState<string | null>("12:00:00");
    return (
      <>
        <TimePicker {...props} value={time} onChange={setTime} />
        <output style={{ minWidth: 150, fontSize: "0.75rem", margin: "4px 0" }}>
          Selected: {time ? time : "None"}
        </output>
      </>
    );
  },
});
