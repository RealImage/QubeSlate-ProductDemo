import { getLocalTimeZone, now, Time } from "@internationalized/date";
import { useContext, useEffect, useRef, type RefObject } from "react";
import { TimeFieldStateContext } from "react-aria-components";
import cx from "classnames";

export function TimePanel({ hourCycle = 12 }: { hourCycle?: 12 | 24 }) {
  const state = useContext(TimeFieldStateContext);

  const showSeconds = state?.granularity === "second";
  const hour = state?.timeValue?.hour ?? 0;
  const minute = state?.timeValue?.minute ?? 0;
  const second = state?.timeValue?.second ?? 0;
  const is12h = hourCycle === 12;

  const updateTime = (time: Time) => {
    if (!state) return;
    const currentDate = state.value ?? now(getLocalTimeZone());

    state.setValue(
      currentDate.set({
        hour: time.hour,
        minute: time.minute,
        second: time.second,
      }),
    );
  };

  const period = hour < 12 ? "AM" : "PM";
  const displayHour = is12h ? (hour % 12 === 0 ? 12 : hour % 12) : hour;

  const hours = is12h
    ? [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    : Array.from({ length: 24 }, (_, i) => i);
  const minutes = Array.from({ length: 60 }, (_, i) => i);
  const seconds = Array.from({ length: 60 }, (_, i) => i);

  const hourColRef = useRef<HTMLDivElement>(null);
  const minColRef = useRef<HTMLDivElement>(null);
  const secColRef = useRef<HTMLDivElement>(null);

  const scrollToSelected = (
    colRef: RefObject<HTMLDivElement | null>,
    behavior: ScrollBehavior = "smooth",
  ) => {
    const col = colRef.current;
    if (!col) return;
    const selected = col.querySelector<HTMLElement>("[data-selected]");
    if (selected) {
      const colHeight = col.clientHeight;
      const itemHeight = selected.clientHeight;
      col.scrollTo({ top: selected.offsetTop - (colHeight - itemHeight) / 2, behavior });
    }
  };

  useEffect(() => {
    scrollToSelected(hourColRef, "instant");
    scrollToSelected(minColRef, "instant");
    if (showSeconds) scrollToSelected(secColRef, "instant");
  }, [showSeconds]);

  function setHour(h: number) {
    const actualHour = is12h ? (period === "PM" ? (h === 12 ? 12 : h + 12) : h === 12 ? 0 : h) : h;
    updateTime(new Time(actualHour, minute, showSeconds ? second : 0));
    requestAnimationFrame(() => scrollToSelected(hourColRef));
  }

  function setMinute(m: number) {
    updateTime(new Time(hour, m, showSeconds ? second : 0));
    requestAnimationFrame(() => scrollToSelected(minColRef));
  }

  function setSecond(s: number) {
    updateTime(new Time(hour, minute, s));
    requestAnimationFrame(() => scrollToSelected(secColRef));
  }

  function setPeriod(p: "AM" | "PM") {
    if (p === "AM" && hour >= 12) updateTime(new Time(hour - 12, minute, showSeconds ? second : 0));
    else if (p === "PM" && hour < 12)
      updateTime(new Time(hour + 12, minute, showSeconds ? second : 0));
  }

  return (
    <div className="pf-time-panel">
      <div className="pf-time-panel__column" ref={hourColRef} aria-label="Hour">
        {hours.map((h) => (
          <button
            key={h}
            className={cx(
              "pf-time-panel__item",
              h === displayHour && "pf-time-panel__item--selected",
            )}
            data-selected={h === displayHour ? "true" : undefined}
            onClick={() => setHour(h)}
          >
            {String(h).padStart(2, "0")}
          </button>
        ))}
      </div>

      <div className="pf-time-panel__column" ref={minColRef} aria-label="Minute">
        {minutes.map((m) => (
          <button
            key={m}
            data-selected={m === minute ? "true" : undefined}
            className={cx("pf-time-panel__item", m === minute && "pf-time-panel__item--selected")}
            onClick={() => setMinute(m)}
          >
            {String(m).padStart(2, "0")}
          </button>
        ))}
      </div>

      {state?.granularity === "second" && (
        <div className="pf-time-panel__column" ref={secColRef} aria-label="Second">
          {seconds.map((s) => (
            <button
              key={s}
              className={cx("pf-time-panel__item", s === second && "pf-time-panel__item--selected")}
              data-selected={s === second ? "true" : undefined}
              onClick={() => setSecond(s)}
            >
              {String(s).padStart(2, "0")}
            </button>
          ))}
        </div>
      )}

      {is12h && (
        <div className="pf-time-panel__column pf-time-panel__column--period" aria-label="Period">
          {(["AM", "PM"] as const).map((p) => (
            <button
              key={p}
              data-selected={p === period ? "true" : undefined}
              className={cx("pf-time-panel__item", p === period && "pf-time-panel__item--selected")}
              onClick={() => setPeriod(p)}
            >
              {p}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
