import { Controls, Description, Primary, Subtitle, Title } from "@storybook/addon-docs/blocks";
import { Button } from "../button/Button";
import { toast, toastPlacements, ToastRegion } from "./Toast";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Toast",
  parameters: {
    layout: "centered",
    docs: {
      page: () => (
        <>
          <Title />
          <Subtitle />
          <Description />
          <Primary />
          <Controls />
        </>
      ),
      story: { inline: false, iframeHeight: "35rem" },
    },
  },
  beforeEach: () => {
    toast.clear();
  },
  decorators: [
    (Story) => (
      <>
        <ToastRegion />
        <Story />
      </>
    ),
  ],
});

export const Default = meta.story({
  render: () => (
    <Button
      variant="default"
      onPress={() =>
        toast.add({
          title: "Files uploaded",
          message: "3 files uploaded successfully.",
          timeout: 5000,
        })
      }
    >
      Show Toast
    </Button>
  ),
});

const VARIANTS = [
  {
    label: "Default",
    variant: "primary",
    title: "Software update available",
    message: "A new version is ready to install.",
  },
  {
    label: "Positive",
    variant: "positive",
    title: "Changes saved",
    message: "Your changes have been saved successfully.",
  },
  {
    label: "Negative",
    variant: "negative",
    title: "Upload failed",
    message: "An error occurred while uploading your file.",
  },
  {
    label: "Notice",
    variant: "notice",
    title: "Action required",
    message: "Review the pending items before continuing.",
  },
] as const;

export const Variants = meta.story({
  render: () => (
    <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
      {VARIANTS.map(({ label, variant, title, message }) => (
        <Button
          key={variant}
          variant="default"
          onPress={() => toast.add({ title, message, variant })}
        >
          {label}
        </Button>
      ))}
    </div>
  ),
});

export const ContentOnly = meta.story({
  render: () => (
    <Button onPress={() => toast.add({ message: "This is a toast with a message only." })}>
      Show Content-Only Toast
    </Button>
  ),
});

export const Persistent = meta.story({
  render: () => (
    <Button
      variant="default"
      onPress={() =>
        toast.add({
          title: "Action required",
          message: "Close this toast manually using the close button",
          variant: "notice",
          timeout: 0,
        })
      }
    >
      Show Persistent Toast
    </Button>
  ),
});

export const Placement = meta.story({
  render: () => (
    <div style={{ display: "flex", gap: "0.5rem" }}>
      {toastPlacements.map((placement) => (
        <Button
          key={placement}
          variant="default"
          onPress={() =>
            toast.add({
              message: <p>This toast is placed at {placement}.</p>,
              placement,
              variant: "primary",
            })
          }
        >
          {placement}
        </Button>
      ))}
    </div>
  ),
});
