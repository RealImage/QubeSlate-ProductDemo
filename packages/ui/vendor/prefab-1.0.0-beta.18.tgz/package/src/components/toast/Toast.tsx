import { useEffect, useRef } from "react";
import {
  UNSTABLE_ToastRegion as AriaToastRegion,
  UNSTABLE_Toast as AriaToast,
  UNSTABLE_ToastQueue as AriaToastQueue,
  UNSTABLE_ToastContent as AriaToastContent,
  UNSTABLE_ToastList as AriaToastList,
  type QueuedToast,
  type ToastRegionProps,
} from "react-aria-components";
import cx from "classnames";
import { Alert, type AlertProps } from "../alert/Alert";

export const toastPlacements = ["top-left", "top-right", "bottom-left", "bottom-right"] as const;

type ToastPlacement = (typeof toastPlacements)[number];

export type ToastOptions = Pick<
  AlertProps,
  "variant" | "title" | "style" | "className" | "closable" | "icon"
> & {
  /** Main content of the toast. Can be a string or any ReactNode. */
  message: React.ReactNode;
  /** Placement of the toast in the toast region. @default "bottom-right" */
  placement?: ToastPlacement;
  /** Timeout in milliseconds for the toast to be closed. @default 3000 */
  timeout?: number;
};

const toastQueue = new AriaToastQueue<ToastOptions>();

function Toast({ toast }: { toast: QueuedToast<ToastOptions> }) {
  const placement = toast.content.placement || "bottom-right";

  return (
    <AriaToast
      className={cx("pf-toast", `pf-toast--${placement}`)}
      toast={toast}
      data-placement={placement}
    >
      <AriaToastContent className="pf-toast__content">
        <Alert
          variant={toast.content.variant}
          title={toast.content.title}
          style={toast.content.style}
          className={cx("pf-toast__item", toast.content.className)}
          closable={toast.content.closable}
          icon={toast.content.icon}
        >
          {toast.content.message}
        </Alert>
      </AriaToastContent>
    </AriaToast>
  );
}

function ToastList() {
  const toastListRef = useRef<HTMLOListElement | null>(null);

  useEffect(() => {
    const toastList = toastListRef.current;
    if (!toastList) return;

    const getToastList = () =>
      Array.from(toastList.children).map((child) => child.firstChild as HTMLElement);

    let frame = 0;

    const setToastPosition = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const elements = getToastList();
        for (const placement of toastPlacements) {
          const nodes = elements.filter((el) => el.dataset.placement === placement);
          const heights = nodes.map((el) => el.getBoundingClientRect().height);
          let y = 0;
          const direction = placement.startsWith("bottom") ? -1 : 1;
          nodes.forEach((el, index) => {
            const height = heights[index];
            el.style.setProperty("--toast-y", `${direction * y}px`);
            el.style.setProperty("--toast-index", `${index}`);
            y += height;
          });
        }
      });
    };

    const ro = new ResizeObserver(setToastPosition);
    const mo = new MutationObserver(() => {
      ro.disconnect();
      getToastList().forEach((el) => ro.observe(el));
      setToastPosition();
    });

    mo.observe(toastList, { childList: true });
    getToastList().forEach((el) => ro.observe(el));
    setToastPosition();

    return () => {
      cancelAnimationFrame(frame);
      mo.disconnect();
      ro.disconnect();
    };
  }, []);

  return (
    <AriaToastList<ToastOptions> ref={toastListRef}>
      {({ toast }) => <Toast toast={toast} />}
    </AriaToastList>
  );
}

function ToastRegion({
  className,
  style,
}: Omit<ToastRegionProps<ToastOptions>, "queue" | "children">) {
  return (
    <AriaToastRegion queue={toastQueue} className={cx("pf-toast-region", className)} style={style}>
      <ToastList />
    </AriaToastRegion>
  );
}

export type ToastManager = Pick<
  AriaToastQueue<ToastOptions>,
  "add" | "close" | "clear" | "visibleToasts"
>;

const toast: ToastManager = {
  visibleToasts: toastQueue.visibleToasts,
  close: (key) => toastQueue.close(key),
  clear: () => toastQueue.clear(),
  add: ({ timeout = 3000, ...content }, options) => {
    return toastQueue.add(content, { timeout, ...options });
  },
};

export { ToastRegion, toast };
