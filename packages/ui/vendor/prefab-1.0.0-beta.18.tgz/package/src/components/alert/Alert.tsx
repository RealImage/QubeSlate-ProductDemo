import { Button, Text, type ButtonProps } from "react-aria-components";
import cx from "classnames";
import {
  AlertFilledIcon,
  CancelIcon,
  ConfirmCircleFilledIcon,
  InfoFilledIcon,
} from "../../assets/icon";

export type AlertVariant = "primary" | "positive" | "negative" | "notice";

export type AlertProps = {
  variant?: AlertVariant;
  /** Title of the alert. */
  title?: string;
  /** Content of the alert. */
  children?: React.ReactNode;
  /** Custom icon to display before the title. Set to false to hide the icon. */
  icon?: React.ReactNode;
  /** Whether the alert is closable or not. @default true */
  closable?: boolean;
  /** Whether the alert is inline or not. @default false */
  inline?: boolean;
  /** Callback function to be called when the alert is closed. */
  onClose?: ButtonProps["onClick"];
} & React.HTMLAttributes<HTMLDivElement>;

const VARIANT_ICONS: Record<AlertVariant, React.ReactNode> = {
  primary: <ConfirmCircleFilledIcon />,
  positive: <ConfirmCircleFilledIcon />,
  negative: <AlertFilledIcon />,
  notice: <InfoFilledIcon />,
};

export function Alert({
  title,
  children,
  icon,
  variant = "primary",
  closable = true,
  onClose,
  inline,
  className,
  ...props
}: AlertProps) {
  const alertIcon = icon === undefined ? VARIANT_ICONS[variant] : icon;
  return (
    <div
      className={cx(
        "pf-alert",
        `pf-alert--${variant}`,
        inline && "pf-alert--inline",
        !!title && "pf-alert--with-title",
        className,
      )}
      {...props}
    >
      {alertIcon && <div className="pf-alert__icon">{alertIcon}</div>}
      <div className="pf-alert__content">
        {title && (
          <Text className="pf-alert__title" slot="title">
            {title}
          </Text>
        )}
        {children}
      </div>
      {closable && (
        <Button className="pf-alert__close" slot="close" aria-label="Close" onClick={onClose}>
          <CancelIcon />
        </Button>
      )}
    </div>
  );
}
