import { Alert } from "./Alert";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Alert",
  component: Alert,
  parameters: { layout: "centered" },
  args: {
    variant: "primary",
    style: { width: "391px" },
  },
});

export const Default = meta.story({
  args: {
    title: "Alert Title",
  },
  render: (props) => (
    <Alert title="Alert Title" {...props}>
      <p>This is sample Information</p>
    </Alert>
  ),
});

export const ContentOnly = meta.story({
  render: (props) => (
    <Alert {...props}>
      <p>This is sample Information</p>
    </Alert>
  ),
});
