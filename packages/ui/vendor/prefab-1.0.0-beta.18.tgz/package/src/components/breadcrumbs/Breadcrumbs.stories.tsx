import { Breadcrumbs } from "./Breadcrumbs";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Breadcrumbs",
  component: Breadcrumbs,
  parameters: { layout: "centered" },
});

export const Default = meta.story({
  render: () => (
    <Breadcrumbs>
      <Breadcrumbs.Item>
        <a>Parent Page</a>
      </Breadcrumbs.Item>
      <Breadcrumbs.Item>
        <a>Previous Page</a>
      </Breadcrumbs.Item>
      <Breadcrumbs.Item>
        <a>Previous Page</a>
      </Breadcrumbs.Item>
      <Breadcrumbs.Item>
        <a>Current Page</a>
      </Breadcrumbs.Item>
    </Breadcrumbs>
  ),
});
