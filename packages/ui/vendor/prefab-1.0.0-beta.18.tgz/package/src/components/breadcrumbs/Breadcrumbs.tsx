import {
  Breadcrumbs as AriaBreadcrumbs,
  Breadcrumb as AriaBreadcrumb,
  composeRenderProps,
  type BreadcrumbsProps as AriaBreadcrumbsProps,
  type BreadcrumbProps as AriaBreadcrumbProps,
} from "react-aria-components";
import cx from "classnames";
import { ChevronRightIcon } from "../../assets/icon";

export type BreadcrumbsProps<T extends object = object> = AriaBreadcrumbsProps<T>;
export type BreadcrumbsItemProps = AriaBreadcrumbProps;

function Breadcrumbs<T extends object = object>({ className, ...props }: BreadcrumbsProps<T>) {
  return <AriaBreadcrumbs<T> className={cx("pf-breadcrumbs", className)} {...props} />;
}

function BreadcrumbsItem({ className, children, ...props }: BreadcrumbsItemProps) {
  return (
    <AriaBreadcrumb
      className={composeRenderProps(className, (className) => cx("pf-breadcrumb", className))}
      {...props}
    >
      {(renderProps) => (
        <>
          {typeof children === "function" ? children(renderProps) : children}
          {!renderProps.isCurrent && (
            <span className="pf-breadcrumb__separator" aria-hidden="true">
              <ChevronRightIcon />
            </span>
          )}
        </>
      )}
    </AriaBreadcrumb>
  );
}

Breadcrumbs.Item = BreadcrumbsItem;

export { Breadcrumbs };
