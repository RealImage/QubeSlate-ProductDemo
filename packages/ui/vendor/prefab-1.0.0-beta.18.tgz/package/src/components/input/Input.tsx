import {
  TextField as AriaTextField,
  Input as AriaInput,
  composeRenderProps,
  type TextFieldProps as AriaTextFieldProps,
  Group,
  Button,
} from "react-aria-components";
import cx from "classnames";
import { FieldLabel, FieldHint, FieldError } from "../field/Field";

export type InputProps = AriaTextFieldProps & {
  /** Label to be displayed above the input. */
  label?: React.ReactNode;
  /** Whether the input is optional. */
  optional?: boolean;
  /** Description to be displayed below the input. */
  description?: React.ReactNode;
  /** Error message to be displayed below the input. */
  errorMessage?: React.ReactNode;
  /** Placeholder text to be displayed in the input. */
  placeholder?: string;
  /** Prefix to be displayed before the input. */
  prefix?: React.ReactNode;
  /** Suffix to be displayed after the input. */
  suffix?: React.ReactNode;
  /** Shows an info icon next to the hint and error text. @default true */
  showHintIcon?: boolean;
  /** Whether the input has an error state. @default false */
  isInvalid?: boolean;
  /** Click handler for the prefix element. */
  onPrefixClick?: () => void;
  /** Click handler for the suffix element. */
  onSuffixClick?: () => void;
};

export function Input({
  label,
  optional,
  description,
  errorMessage,
  placeholder,
  prefix,
  suffix,
  onPrefixClick,
  onSuffixClick,
  className,
  isInvalid,
  showHintIcon = true,
  ...props
}: InputProps) {
  const isFieldInvalid = isInvalid || !!errorMessage;

  return (
    <AriaTextField
      isInvalid={isFieldInvalid}
      className={composeRenderProps(className, (className, state) =>
        cx("pf-input-field", className, {
          "pf-input-field--disabled": state.isDisabled,
          "pf-input-field--invalid": state.isInvalid,
        }),
      )}
      {...props}
    >
      {label && <FieldLabel optional={optional}>{label}</FieldLabel>}
      <Group className="pf-input-field__control">
        {prefix &&
          (typeof onPrefixClick === "function" ? (
            <Button className="pf-input-field__prefix" onClick={onPrefixClick}>
              {prefix}
            </Button>
          ) : (
            <span className="pf-input-field__prefix">{prefix}</span>
          ))}
        <AriaInput className="pf-input-field__input" placeholder={placeholder} />
        {suffix &&
          (typeof onSuffixClick === "function" ? (
            <Button className="pf-input-field__suffix" onClick={onSuffixClick}>
              {suffix}
            </Button>
          ) : (
            <span className="pf-input-field__suffix">{suffix}</span>
          ))}
      </Group>
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
    </AriaTextField>
  );
}
