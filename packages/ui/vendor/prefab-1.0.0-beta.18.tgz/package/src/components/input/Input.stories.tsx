import { SearchIcon, EmailAddressIcon, LockedIcon } from "../../assets/icon";
import { Input } from "./Input";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Input",
  component: Input,
  parameters: { layout: "centered" },
  args: {
    label: "Label",
    optional: true,
    placeholder: "Placeholder",
    isDisabled: false,
  },
  decorators: [
    (Story) => (
      <div style={{ width: "min(300px, 70vw)" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => <Input {...props} />,
});

export const ErrorState = meta.story({
  args: {
    errorMessage: "This is an error message",
    isInvalid: true,
  },
  render: (props) => <Input {...props} />,
});

export const PrefixSuffixIcon = meta.story({
  render: (props) => (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <Input
        {...props}
        label="Search"
        placeholder="Search..."
        description="Type to search"
        prefix={<SearchIcon />}
      />
      <Input
        {...props}
        label="Email"
        placeholder="you@example.com"
        description="Enter your email"
        prefix={<EmailAddressIcon />}
      />
      <Input
        {...props}
        label="Password"
        placeholder="••••••••"
        type="password"
        description="At least 8 characters"
        suffix={<LockedIcon />}
      />
    </div>
  ),
});
