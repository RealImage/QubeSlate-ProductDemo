import { useMemo } from "react";
import {
  Button as AriaButton,
  Dialog as AriaDialog,
  Heading,
  Modal,
  ModalOverlay,
  type DialogProps as AriaDialogProps,
  type ModalOverlayProps,
} from "react-aria-components";
import cx from "classnames";
import { CancelIcon } from "../../assets/icon";

export type SheetProps = Omit<ModalOverlayProps, "children"> & {
  /** Which edge the sheet slides in from. @default "right" */
  side?: "right" | "left" | "top" | "bottom";
  /** Width override for left/right sheets, or height override for top/bottom sheets. */
  size?: React.CSSProperties["width"];
  /** Border radius for the sheet corners. Defaults to `0` for `attached` and `0.5rem` for `detached`. */
  borderRadius?: React.CSSProperties["borderRadius"];
  /** Whether to close the sheet when the user clicks outside. @default true */
  isDismissable?: boolean;
  /** Hide the semi-transparent backdrop overlay. @default false */
  hideOverlay?: boolean;
  children?: AriaDialogProps["children"];
};

function Sheet({
  children,
  className,
  side = "right",
  size,
  borderRadius,
  isDismissable = true,
  hideOverlay = false,
  ...props
}: SheetProps) {
  const isHorizontal = side === "left" || side === "right";

  const modalStyle = useMemo<React.CSSProperties | undefined>(() => {
    const style: React.CSSProperties & Record<string, unknown> = {};
    if (size) Object.assign(style, isHorizontal ? { width: size } : { height: size });
    if (borderRadius !== undefined) style["--pf-sheet-radius"] = borderRadius;
    return Object.keys(style).length ? style : undefined;
  }, [size, borderRadius, isHorizontal]);

  return (
    <ModalOverlay
      className={cx(
        "pf-sheet-overlay",
        `pf-sheet-overlay--${side}`,
        hideOverlay && "pf-sheet-overlay--no-backdrop",
        className,
      )}
      isDismissable={isDismissable}
      {...props}
    >
      <Modal className={cx("pf-sheet", `pf-sheet--${side}`)} style={modalStyle}>
        <AriaDialog className="pf-sheet__dialog">{children}</AriaDialog>
      </Modal>
    </ModalOverlay>
  );
}

type SheetHeaderProps = React.HTMLAttributes<HTMLDivElement> & {
  /** Hide the default close button. @default false */
  hideCloseButton?: boolean;
};

function SheetHeader({ children, className, hideCloseButton = false, ...props }: SheetHeaderProps) {
  return (
    <div className={cx("pf-sheet__header", className)} {...props}>
      <Heading slot="title" className="pf-sheet__heading">
        {children}
      </Heading>
      {!hideCloseButton && (
        <AriaButton slot="close" aria-label="Close sheet" className="pf-sheet__close">
          <CancelIcon />
        </AriaButton>
      )}
    </div>
  );
}

type SheetBodyProps = React.HTMLAttributes<HTMLDivElement>;

function SheetBody({ children, className, ...props }: SheetBodyProps) {
  return (
    <div className={cx("pf-sheet__body", className)} {...props}>
      {children}
    </div>
  );
}

type SheetFooterProps = React.HTMLAttributes<HTMLDivElement>;

function SheetFooter({ children, className, ...props }: SheetFooterProps) {
  return (
    <div className={cx("pf-sheet__footer", className)} {...props}>
      {children}
    </div>
  );
}

Sheet.Header = SheetHeader;
Sheet.Body = SheetBody;
Sheet.Footer = SheetFooter;

export { Sheet };
