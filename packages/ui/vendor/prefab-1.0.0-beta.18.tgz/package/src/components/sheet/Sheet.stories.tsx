import { useState } from "react";
import { Button } from "../button/Button";
import { Sheet } from "./Sheet";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Sheet",
  component: Sheet,
  parameters: { layout: "centered" },
});

export const Default = meta.story({
  render: function Render(props) {
    const [open, setOpen] = useState(false);
    return (
      <div style={{ padding: "2rem" }}>
        <Button variant="primary" onPress={() => setOpen(true)}>
          Open Sheet
        </Button>
        <Sheet isOpen={open} onOpenChange={setOpen} {...props}>
          <Sheet.Header>Sheet Title</Sheet.Header>
          <Sheet.Body>
            <p style={{ margin: 0 }}>
              This is the sheet body. It scrolls when the content overflows.
            </p>
          </Sheet.Body>
          <Sheet.Footer>
            <Button variant="secondary" slot="close">
              Cancel
            </Button>
            <Button variant="primary" slot="close">
              Confirm
            </Button>
          </Sheet.Footer>
        </Sheet>
      </div>
    );
  },
});

export const AllSides = meta.story({
  render: function Render(props, { argTypes }) {
    const [side, setSide] = useState<"right" | "left" | "top" | "bottom">("right");
    const [open, setOpen] = useState(false);

    function openSide(s: typeof side) {
      setSide(s);
      setOpen(true);
    }

    return (
      <div style={{ padding: "2rem", display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
        {argTypes.side?.options?.map((s) => (
          <Button key={s} onPress={() => openSide(s)}>
            Open {s}
          </Button>
        ))}
        <Sheet {...props} isOpen={open} onOpenChange={setOpen} side={side}>
          <Sheet.Header>Sliding from {side}</Sheet.Header>
          <Sheet.Body>
            <p style={{ margin: 0 }}>Sheet coming in from the {side} side.</p>
          </Sheet.Body>
          <Sheet.Footer>
            <Button variant="primary" slot="close">
              Done
            </Button>
          </Sheet.Footer>
        </Sheet>
      </div>
    );
  },
});

export const CustomSize = meta.story({
  render: function Render() {
    const [open, setOpen] = useState(false);
    return (
      <div style={{ padding: "2rem" }}>
        <Button variant="primary" onPress={() => setOpen(true)}>
          Open wide sheet
        </Button>
        <Sheet isOpen={open} onOpenChange={setOpen} side="right" size="36rem">
          <Sheet.Header>Wide Sheet</Sheet.Header>
          <Sheet.Body>
            <p style={{ margin: 0 }}>This sheet has a custom width of 36rem.</p>
          </Sheet.Body>
          <Sheet.Footer>
            <Button variant="primary" slot="close">
              Close
            </Button>
          </Sheet.Footer>
        </Sheet>
      </div>
    );
  },
});

export const NonDismissable = meta.story({
  render: function Render() {
    const [open, setOpen] = useState(false);
    return (
      <div style={{ padding: "2rem" }}>
        <Button variant="primary" onPress={() => setOpen(true)}>
          Open non-dismissable sheet
        </Button>
        <Sheet isOpen={open} onOpenChange={setOpen} isDismissable={false}>
          <Sheet.Header>Non-dismissable</Sheet.Header>
          <Sheet.Body>
            <p style={{ margin: 0 }}>
              Clicking outside will not close this sheet. Use the action buttons or press Escape to
              close it.
            </p>
          </Sheet.Body>
          <Sheet.Footer>
            <Button variant="secondary" slot="close">
              Cancel
            </Button>
            <Button variant="primary" slot="close">
              Save
            </Button>
          </Sheet.Footer>
        </Sheet>
      </div>
    );
  },
});
