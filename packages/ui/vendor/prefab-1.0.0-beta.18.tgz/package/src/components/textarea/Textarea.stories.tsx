import { Textarea } from "./Textarea";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Textarea",
  component: Textarea,
  parameters: { layout: "centered" },
  args: {
    label: "Label",
    optional: true,
    placeholder: "Placeholder",
    rows: 3,
    isDisabled: false,
  },
  decorators: [
    (Story) => (
      <div style={{ width: "min(300px, 70vw)" }}>
        <Story />
      </div>
    ),
  ],
});

export const Default = meta.story({
  render: (props) => <Textarea {...props} />,
});

export const FixedSize = meta.story({
  args: { resize: "none" },
  render: (props) => <Textarea resize="none" {...props} />,
});

export const ErrorState = meta.story({
  args: {
    errorMessage: "This is an error message",
    isInvalid: true,
  },
  render: (props) => <Textarea {...props} />,
});
