import {
  TextField as AriaTextField,
  TextArea as AriaTextArea,
  composeRenderProps,
  type TextFieldProps as AriaTextFieldProps,
} from "react-aria-components";
import cx from "classnames";
import { FieldLabel, FieldHint, FieldError } from "../field/Field";

export type TextareaProps = AriaTextFieldProps & {
  label?: React.ReactNode;
  optional?: boolean;
  description?: React.ReactNode;
  errorMessage?: React.ReactNode;
  placeholder?: string;
  /** Number of rows to display. @default 3 */
  rows?: number;
  /** Controls the resize behavior of the textarea. @default "vertical" */
  resize?: "none" | "vertical" | "horizontal" | "both";
  /** Shows an info icon next to the hint text. @default true */
  showHintIcon?: boolean;
};

export function Textarea({
  label,
  optional,
  description,
  errorMessage,
  placeholder,
  rows = 3,
  resize = "vertical",
  className,
  isInvalid,
  showHintIcon = true,
  ...props
}: TextareaProps) {
  const isFieldInvalid = isInvalid || !!errorMessage;

  return (
    <AriaTextField
      isInvalid={isFieldInvalid}
      className={composeRenderProps(className, (className, state) =>
        cx("pf-textarea-field", className, {
          "pf-textarea-field--disabled": state.isDisabled,
          "pf-textarea-field--invalid": state.isInvalid,
        }),
      )}
      {...props}
    >
      {label && <FieldLabel optional={optional}>{label}</FieldLabel>}
      <AriaTextArea
        className="pf-textarea-field__textarea"
        placeholder={placeholder}
        rows={rows}
        style={{ resize }}
      />
      {description && !errorMessage && <FieldHint showIcon={showHintIcon}>{description}</FieldHint>}
      {errorMessage && <FieldError showIcon={showHintIcon}>{errorMessage}</FieldError>}
    </AriaTextField>
  );
}
