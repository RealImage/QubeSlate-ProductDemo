import { createContext, useContext } from "react";
import {
  OverlayArrow,
  Focusable,
  Tooltip as AriaTooltip,
  TooltipTrigger as AriaTooltipTrigger,
  composeRenderProps,
  type TooltipProps as AriaTooltipProps,
  type TooltipTriggerComponentProps,
} from "react-aria-components";
import cx from "classnames";

type TooltipContextType = {
  /** The color variant of the tooltip. @default default */
  variant?: "default" | "primary";
  /** size of the tooltip. @default "md" */
  size?: "sm" | "md";
  /**
   * Whether the element should flip its orientation (e.g. top to bottom or left to right) when
   * there is insufficient room for it to render completely.
   * @default true
   */
  shouldFlip?: AriaTooltipProps["shouldFlip"];
  /** The placement of the tooltip with respect to the trigger. @default top */
  placement?: AriaTooltipProps["placement"];
  /** Whether the tooltip should have an arrow pointing to the trigger. @default false */
  arrow?: boolean;
  /** The size of the arrow in pixels. @default 8 */
  arrowSize?: number;
  /** The offset of the tooltip in pixels. @default 4 */
  offset?: number;
  /** Whether the tooltip should be animated. @default true */
  animated?: boolean;
};

export type TooltipProps = Partial<TooltipTriggerComponentProps> & TooltipContextType;

const TooltipContext = createContext<TooltipContextType>({});

function Tooltip({
  delay = 1000,
  closeDelay = 0,
  children,
  defaultOpen,
  isDisabled,
  isOpen,
  onOpenChange,
  shouldCloseOnPress,
  trigger,
  ...rest
}: TooltipProps) {
  return (
    <TooltipContext.Provider value={rest}>
      <AriaTooltipTrigger
        delay={delay}
        closeDelay={closeDelay}
        defaultOpen={defaultOpen}
        isDisabled={isDisabled}
        isOpen={isOpen}
        onOpenChange={onOpenChange}
        shouldCloseOnPress={shouldCloseOnPress}
        trigger={trigger}
      >
        {children}
      </AriaTooltipTrigger>
    </TooltipContext.Provider>
  );
}

export type TooltipTriggerProps = React.ComponentProps<typeof Focusable>;

function TooltipTrigger({ children, ...props }: TooltipTriggerProps) {
  return <Focusable {...props}>{children}</Focusable>;
}

export type TooltipContentProps = AriaTooltipProps & {
  children?: React.ReactNode;
};

const TooltipContent = ({ children, className, ...props }: TooltipContentProps) => {
  const context = useContext(TooltipContext);
  const showArrow = context.arrow;
  const arrowSize = context.arrowSize ?? 8;
  const offset = context.offset ?? (showArrow ? arrowSize / 2 : 0) + 4;
  return (
    <AriaTooltip
      offset={offset}
      shouldFlip={context.shouldFlip}
      placement={context.placement}
      className={composeRenderProps(className, (className) =>
        cx(
          "pf-tooltip",
          `pf-tooltip--${context.variant ?? "default"}`,
          `pf-tooltip--${context.size ?? "md"}`,
          { "pf-tooltip--animated": context.animated !== false },
          className,
        ),
      )}
      {...props}
    >
      {showArrow && (
        <OverlayArrow className="pf-tooltip__arrow">
          <svg width={arrowSize} height={arrowSize} viewBox="0 0 8 8">
            <path d="M0 0 L4 4 L8 0" fill="currentColor" />
          </svg>
        </OverlayArrow>
      )}
      {children}
    </AriaTooltip>
  );
};

Tooltip.Trigger = TooltipTrigger;
Tooltip.Content = TooltipContent;

export { Tooltip };
