import { Button } from "../button/Button";
import { Tooltip, type TooltipProps } from "./Tooltip";
import preview from "#storybook/preview";

const meta = preview.meta({
  title: "Components/Tooltip",
  component: Tooltip,
  parameters: { layout: "centered" },
  args: {
    variant: "default",
    arrow: true,
    shouldFlip: true,
    shouldCloseOnPress: true,
    delay: 300,
    closeDelay: 0,
  },
});

export const Default = meta.story({
  render: (props) => (
    <Tooltip {...props}>
      <Button>Hover</Button>
      <Tooltip.Content>Tooltip Content</Tooltip.Content>
    </Tooltip>
  ),
});

export const WithoutArrow = meta.story({
  args: { arrow: false },
  render: (props) => (
    <Tooltip {...props}>
      <Button>Hover</Button>
      <Tooltip.Content>Tooltip Content</Tooltip.Content>
    </Tooltip>
  ),
});

export const CustomTrigger = meta.story({
  render: (props) => (
    <Tooltip {...props}>
      <Tooltip.Trigger>
        <span role="button">Custom trigger</span>
      </Tooltip.Trigger>
      <Tooltip.Content>Tooltip Content</Tooltip.Content>
    </Tooltip>
  ),
});

export const Placements = meta.story({
  render: (props) => {
    const placementGrid: TooltipProps["placement"][][] = [
      ["top start", "top", "top end"],
      ["left top", "left", "left bottom"],
      ["right top", "right", "right bottom"],
      ["bottom start", "bottom", "bottom end"],
    ];
    return (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(5, 5rem)",
          gridTemplateRows: "repeat(5, 2rem)",
          gap: "0.5rem",
          alignItems: "center",
          justifyItems: "center",
        }}
      >
        <div
          style={{
            gridColumn: "2 / 5",
            gridRow: "2 / 5",
            width: "100%",
            height: "100%",
            border: "2px dashed #ccc",
            borderRadius: "0.5rem",
            background: "#1b1b1b10",
          }}
        />
        {placementGrid.flatMap((group, gi) =>
          group.map((placement, i) => {
            const col = gi === 1 ? 1 : gi === 2 ? 5 : i + 2;
            const row = gi === 0 ? 1 : gi === 3 ? 5 : i + 2;
            return (
              <div key={placement} style={{ gridColumn: col, gridRow: row }}>
                <Tooltip {...props} placement={placement}>
                  <Button size="small">{placement}</Button>
                  <Tooltip.Content>
                    <strong>Tooltip</strong>
                    <div style={{ fontSize: "0.75rem" }}>
                      placement=<em>&quot;{placement}&quot;</em>
                    </div>
                  </Tooltip.Content>
                </Tooltip>
              </div>
            );
          }),
        )}
      </div>
    );
  },
});
