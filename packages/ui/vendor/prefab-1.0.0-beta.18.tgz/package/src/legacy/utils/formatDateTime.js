import moment from "moment";
import getUserTimezone from "./getUserTimezone";

const formatDateTime = (dt, format = "MMM DD, YYYY HH:mm") => {
  if (!dt) return null;
  const timeZone = getUserTimezone();
  const momentDate = moment(new Date(dt)).utcOffset(timeZone.offset);
  const formatted = momentDate.format(format);
  return formatted;
};

export { formatDateTime };
