export * from "../../assets/icon";
