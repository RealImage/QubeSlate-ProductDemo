// TODO: can be reused for further bulk imports
import fs from "fs";

const iconDir = "./icons";

const camelCased = (fileName) => fileName.replace(/-(.)/g, (match, item) => item.toUpperCase());
const formatFileName = (fileName) => camelCased(fileName).replace(/(\.[^.]*$)|(\s)/g, "");
const iconImportList = [];
const iconExportList = [];
fs.readdir(iconDir, (err, files) => {
  files.forEach((file) => {
    if (file !== ".DS_Store") {
      const iconName = `${formatFileName(file)}Icon`; // To Remove Extension and add Icon as Suffix
      fs.rename(`${iconDir}/${file}`, `${iconDir}/${formatFileName(file)}.svg`, () => {
        console.log(`${file} is replaced as ${formatFileName(file)}.svg`);
      });
      iconImportList.push(
        `import { ReactComponent as ${iconName} } from "./icons/${formatFileName(file)}.svg";`,
      );
      iconExportList.push(iconName);
    }
  });
  try {
    fs.writeFileSync(
      `${__dirname}/icon.js`,
      `${iconImportList.join("\n")}\n
      export {
        ${iconExportList.join(",\n")}
      };`,
      "utf8",
      (err) => {
        if (err) console.log("Error writing file", err);
        else console.log("Successfully wrote file");
      },
    );
  } catch (err) {
    if (err) console.log("Error writing file", err);
  }
});
