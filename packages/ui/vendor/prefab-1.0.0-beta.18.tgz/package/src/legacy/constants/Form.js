const FORM_FIELD_TYPES = {
  BUTTON: "button",
  AUTO_SUGGEST: "autoSuggest",
  LABEL: "label",
  DATE: "date",
  DROP_DOWN: "dropDown",
  TAG_SEARCH: "tagSearch",
  API_SEARCH: "apiSearch",
  CHECK_BOX: "checkBox",
  DATE_RANGE_PICKER: "dateRangePicker",
};

export { FORM_FIELD_TYPES };
