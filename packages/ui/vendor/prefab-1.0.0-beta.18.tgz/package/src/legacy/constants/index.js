import { STATUS_ICON_COLORS, STATUS_ICON_TYPES } from "./StatusIcon";
import { BUTTON_TYPE } from "./BaseButton";
import { FORM_FIELD_TYPES } from "./Form";

const SIZE = {
  LARGE: "large",
  REGULAR: "regular",
  SMALL: "small",
};

const ICON_POS = {
  LEFT: "left",
  RIGHT: "right",
};

const FILTER_TAG_TYPES = {
  SEARCH: "search",
  LIST: "list",
  DATE_RANGE: "dateRange",
  MULTI_SELECT_SEARCH: "multiSelectSearch",
  RADIO_WITH_SEARCH: "radioWithSearch",
};

const SEARCH_TAG_TYPES = {
  TAG_SEARCH: "tagSearch",
  INPUT_SEARCH: "inputSearch",
  MULTI_SELECT_SEARCH: "multiSelectSearch",
};

const VIEW_PORT_SIZE_CLASS = {
  xs: "xs",
  sm: "sm",
  md: "md",
  lg: "lg",
  xl: "xl",
};

export {
  SIZE,
  ICON_POS,
  STATUS_ICON_COLORS,
  STATUS_ICON_TYPES,
  BUTTON_TYPE,
  FILTER_TAG_TYPES,
  FORM_FIELD_TYPES,
  VIEW_PORT_SIZE_CLASS,
  SEARCH_TAG_TYPES,
};
