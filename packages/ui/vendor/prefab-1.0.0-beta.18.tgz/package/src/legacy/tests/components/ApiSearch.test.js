import { render, fireEvent, waitFor } from "@testing-library/react";
import _ from "lodash";
import ApiSearch from "../../components/ApiSearch";

const mockResults = {
  data: [
    {
      type: "City",
      id: 109402,
      uuid: "d52bcdcf-19d9-4dcb-a0ea-6b4d1608b49e",
      code: null,
      name: "Madrano-Canzolino",
      alternate_name: null,
      local_language_name: null,
      translations: [],
      province: {
        id: 1361,
        uuid: "4b6e0e71-3ffb-4674-b13b-15205e56f568",
        code: "IT-32",
        name: "Trentino-Sudtirol",
        alternate_name: "Trentino-Alto Adige, Trentino-Südtirol",
        local_language_name: null,
        translations: [],
        country: {
          id: 110,
          uuid: "feaabef9-f2d8-4d21-8898-36fa7031e233",
          code: "IT",
          iso3166_2: "IT",
          iso3166_3: "ITA",
          name: "Italy",
          calling_code: "+39",
          alternate_name: null,
          local_language_name: null,
          translations: [],
        },
      },
    },
  ],
};
const mockParsed = [
  {
    id: "d52bcdcf-19d9-4dcb-a0ea-6b4d1608b49e",
    name: "Madrano-Canzolino",
    tag: "Trentino-Sudtirol · Italy",
  },
];

const fetchAction = jest.fn().mockResolvedValue(mockResults);
const parseResults = jest.fn().mockReturnValue(mockParsed);
const onSelect = jest.fn();
const view = (
  <ApiSearch
    placeholder="Select Location"
    onSelect={onSelect}
    searchIcon="right"
    parseResults={parseResults}
    fetchAction={fetchAction}
    textKey="name"
    compareKey={"uuid"}
  />
);
const debounced = jest.fn((fn) => fn);

describe("<ApiSearch/>", () => {
  beforeEach(() => {
    _.debounce = debounced;
  });

  it("renders without crashing", () => {
    const { unmount } = render(view);
    unmount();
  });

  it("renders correctly", () => {
    const { container } = render(view);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("on input change query changes and triggers fetch", async () => {
    const { container } = render(view);
    const input = container.querySelector("input");

    if (input) {
      fireEvent.change(input, { target: { name: "location", value: "Madrano-Canzolino" } });

      await waitFor(() => {
        expect(fetchAction).toHaveBeenCalled();
      });
    }
  });

  it("should update query in state if query in props changes", async () => {
    const { container, rerender } = render(view);
    const input = container.querySelector("input");

    if (input) {
      fireEvent.change(input, { target: { name: "location", value: "Madrano-Canzolino" } });

      const updatedView = (
        <ApiSearch
          placeholder="Select Location"
          onSelect={onSelect}
          searchIcon="right"
          parseResults={parseResults}
          fetchAction={fetchAction}
          textKey="name"
          compareKey={"uuid"}
          query="Paris"
        />
      );
      rerender(updatedView);
    }
  });

  it("should call customCreateNewItemRenderer if only allowCreate is passed", () => {
    const customCreateNewItemRenderer = jest.fn();
    const { container, rerender } = render(view);

    rerender(
      <ApiSearch
        placeholder="Select Location"
        onSelect={onSelect}
        searchIcon="right"
        parseResults={parseResults}
        fetchAction={fetchAction}
        textKey="name"
        compareKey={"uuid"}
        customCreateNewItemRenderer={customCreateNewItemRenderer}
        allowCreate={true}
      />,
    );

    const input = container.querySelector("input");
    if (input) {
      fireEvent.change(input, { target: { name: "location", value: "Madrano-Canzolino" } });
      expect(customCreateNewItemRenderer).toHaveBeenCalled();
    }

    const customCreateNewItemRendererNotCalled = jest.fn();
    rerender(
      <ApiSearch
        placeholder="Select Location"
        onSelect={onSelect}
        searchIcon="right"
        parseResults={parseResults}
        fetchAction={fetchAction}
        textKey="name"
        compareKey={"uuid"}
        customCreateNewItemRenderer={customCreateNewItemRendererNotCalled}
        allowCreate={false}
      />,
    );

    const inputAgain = container.querySelector("input");
    if (inputAgain) {
      fireEvent.change(inputAgain, { target: { name: "location", value: "Madrano-Canzolino" } });
      expect(customCreateNewItemRendererNotCalled).not.toHaveBeenCalled();
    }
  });
});
