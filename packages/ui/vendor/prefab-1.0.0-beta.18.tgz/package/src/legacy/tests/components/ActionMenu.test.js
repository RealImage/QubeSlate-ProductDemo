import { render } from "@testing-library/react";
import ActionMenu from "../../components/ActionMenu";

const component = (
  <ActionMenu
    iconList={[
      {
        text: "Update",
        icon: <div>Icon</div>,
        onClick: () => jest.fn(),
      },
    ]}
  />
);

describe("<ActionMenu />", () => {
  it("renders without crashing", () => {
    render(component);
  });

  it("renders correctly", () => {
    const { container, rerender } = render(component);
    expect(container.firstChild).toMatchSnapshot();

    rerender(
      <ActionMenu
        iconList={[
          {
            text: "Update",
            icon: <div>Icon</div>,
            onClick: () => jest.fn(),
          },
        ]}
        icon=""
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
