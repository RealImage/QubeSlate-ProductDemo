import { render } from "@testing-library/react";
import * as Icons from "../../../assets/icon.js";
import NavMenuAccordion from "../../../components/NavigationBar/NavMenuAccordion";

const { AudioIcon } = Icons;
const history = { location: { search: "" }, replace: jest.fn(), push: jest.fn() };
const menuList = [
  {
    name: "Screens",
    route: "/screens",
    Icon: AudioIcon,
  },
  {
    name: "Brand Verifications",
    badge: 4,
    route: "/brand-verifications",
    Icon: AudioIcon,
  },
];

describe("<NavMenuAccordion/>", () => {
  it("renders correctly", () => {
    const { container } = render(
      <NavMenuAccordion
        name="PageHeader.pendingApprovalNavHeading"
        history={history}
        isExpanded={true}
        menuList={menuList}
        location={{ pathname: "/lists" }}
        handleExpand={jest.fn()}
        validateActiveRoute={() => false}
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("should render without error", () => {
    const { container } = render(
      <NavMenuAccordion
        history={history}
        name="PageHeader.pendingApprovalNavHeading"
        isExpanded={true}
        menuList={menuList}
        location={{ pathname: "/lists" }}
        handleExpand={jest.fn()}
        validateActiveRoute={() => false}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });

  it("should not render menuList", () => {
    const { container } = render(
      <NavMenuAccordion
        history={history}
        name="PageHeader.pendingApprovalNavHeading"
        isExpanded={true}
        menuList={menuList}
        location={{ pathname: "/lists" }}
        handleExpand={jest.fn()}
        validateActiveRoute={() => false}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });
});
