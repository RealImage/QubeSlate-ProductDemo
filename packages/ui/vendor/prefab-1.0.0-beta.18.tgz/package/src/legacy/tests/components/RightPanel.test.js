import { render, screen, fireEvent } from "@testing-library/react";
import RightPanel from "../../components/RightPanel";

describe("Modal component", () => {
  const Child = () => <div>Test Component</div>;

  it("should render With children without Error", () => {
    const { container } = render(
      <RightPanel onClose={() => {}} header="RightPanelHeader.filters" isOpen={true}>
        <Child />
      </RightPanel>,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("should trigger onClose button when clicked", () => {
    const onClose = jest.fn();
    render(
      <RightPanel onClose={onClose} header="RightPanelHeader.filters" isOpen={true}>
        <Child />
      </RightPanel>,
    );
    const closeButton = screen.getByRole("button");
    fireEvent.click(closeButton);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("should mount portal on the div with id right-panel-portal", () => {
    const panelRoot = global.document.querySelector("#right-panel-portal");
    expect(panelRoot.hasChildNodes()).toBeFalsy();
    const onClose = jest.fn();
    const { unmount } = render(
      <RightPanel onClose={onClose} header="RightPanelHeader.filters" isOpen={true}>
        <Child />
      </RightPanel>,
    );
    expect(panelRoot.hasChildNodes()).toBeTruthy();
    unmount();
  });

  it("should clear the div with id right-panel-portal on unmount", () => {
    const panelRoot = global.document.querySelector("#right-panel-portal");

    const { unmount } = render(
      <RightPanel onClose={() => {}} header="RightPanelHeader.filters" isOpen={true}>
        <Child />
      </RightPanel>,
    );

    expect(panelRoot.hasChildNodes()).toBeTruthy();
    unmount();
    expect(panelRoot.hasChildNodes()).toBeFalsy();
  });
});
