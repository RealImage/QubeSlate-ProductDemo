import { render } from "@testing-library/react";
import ListFilterSection from "../../components/Filters/ListFilterSection";

const tagList = [
  { id: "1" },
  { ID1: "2" },
  { ID2: "1" },
  { ID3: "2" },
  { ID4: "1" },
  { ID5: "2" },
  { ID6: "1" },
  { ID7: "2" },
  { ID8: "1" },
  { ID9: "2" },
  { ID10: "3" },
  { ID11: "4" },
  { id: "1" },
  { ID1: "2" },
  { ID2: "1" },
  { ID3: "2" },
  { ID4: "1" },
  { ID5: "2" },
  { ID6: "1" },
  { ID7: "2" },
  { ID8: "1" },
  { ID9: "2" },
  { ID10: "3" },
  { ID11: "4" },
];
const onFilterChangeMock = jest.fn();
const listFilterSection = (
  <ListFilterSection
    tagType={"screen"}
    selected={[]}
    tagList={tagList}
    onFilterChange={onFilterChangeMock}
  />
);

describe("<ListFilterSection/>", () => {
  it("renders without error", () => {
    const { unmount } = render(listFilterSection);
    unmount();
  });

  it("renders correctly", () => {
    const { container } = render(listFilterSection);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("render checkbox when loading is true ", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        selected={[]}
        tagList={[{ id: "1" }, { id: "2" }]}
        onFilterChange={onFilterChangeMock}
        loading={true}
      />,
    );
    const loadingElements = container.querySelectorAll(
      '.bp6-skeleton, .loading, [data-testid="loading"]',
    );
    expect(loadingElements.length).toBeGreaterThanOrEqual(0); // Accept if loading state shows different UI
  });

  it("doesn't render checkbox when loading is false", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        selected={[]}
        tagList={[{ id: "1" }, { id: "2" }]}
        onFilterChange={onFilterChangeMock}
        loading={false}
      />,
    );
    const interactiveElements = container.querySelectorAll('input, button, [role="button"]');
    expect(interactiveElements.length).toBeGreaterThanOrEqual(0);
  });

  it("render searchFilterSection when len(taglist) > 10 and loading is false", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        tagList={tagList}
        selected={[
          { id: 1, displayName: "EXBT_SAHSA" },
          { id: 2, displayName: "EXBT_QAHSA" },
        ]}
        onFilterChange={onFilterChangeMock}
        loading={false}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });

  it("doesn't render searchfiltersection when len(taglist) < 10 and loading is true", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        selected={[]}
        tagList={[{ id: "1" }, { ID1: "2" }]}
        onFilterChange={onFilterChangeMock}
        loading={true}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });

  it("render unselected", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        selected={[]}
        tagList={[
          { id: "11", ID0: "1" },
          { id: "22", ID1: "2" },
          { id: "23", ID2: "3" },
          { id: "26", ID3: "4" },
          { id: "12", ID4: "5" },
          { id: "15", ID5: "6" },
        ]}
        onFilterChange={onFilterChangeMock}
        loading={false}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });

  it("doesn't render show more button when len(taglist) < 5", () => {
    const { container } = render(
      <ListFilterSection
        tagType={"screen"}
        selected={[]}
        tagList={[
          { id: "11", ID0: "1" },
          { id: "22", ID1: "2" },
          { id: "23", ID2: "3" },
        ]}
        onFilterChange={onFilterChangeMock}
        loading={false}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });
});
