import { render } from "@testing-library/react";
import TooltipButton from "../../components/TooltipButton";

const TooltipButtonSample = <TooltipButton toolTip="View" buttonText="button" />;
describe("TooltipButton", () => {
  it("renders without crashing", () => {
    render(TooltipButtonSample);
  });

  it("renders correctly", () => {
    const { container } = render(TooltipButtonSample);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("renders button with the text passed in", () => {
    const { container } = render(TooltipButtonSample);
    expect(container.firstChild).toMatchSnapshot();
  });
});
