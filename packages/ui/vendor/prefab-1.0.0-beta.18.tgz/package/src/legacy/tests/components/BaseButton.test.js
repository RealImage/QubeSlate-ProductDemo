import { render, screen, fireEvent } from "@testing-library/react";
import BaseButton from "../../components/BaseButton";

describe("BaseButton", () => {
  const ButtonProps = {
    buttonText: "Action",
    buttonSize: "large",
    buttonType: "primary",
    className: "parentclass",
  };
  const ButtonProps1 = {
    iconName: "AddIcon",
    iconPos: "right",
    buttonText: "Action",
    buttonSize: "large",
    buttonType: "primary",
  };
  it("should be defined", () => {
    expect(BaseButton).toBeDefined();
  });
  it("renders correctly", () => {
    const { container } = render(<BaseButton {...ButtonProps} />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it("renders correctly with icon", () => {
    const { container } = render(<BaseButton {...ButtonProps1} />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it('renders a primary button in size of "large" with text in it', () => {
    render(<BaseButton {...ButtonProps} />);
    const button = screen.getByRole("button");
    expect(button).toHaveClass("primary");
    expect(button).toHaveClass("large");
    expect(button).toHaveTextContent("Action");
  });
  it("renders a primary button with parent class ", () => {
    render(<BaseButton {...ButtonProps} />);
    const button = screen.getByRole("button");
    expect(button).toHaveClass("parentclass");
  });
  it("adds additional props to button that we pass ", () => {
    const props = {
      iconName: "AddIcon",
      iconPos: "right",
      buttonText: "Action",
      buttonSize: "large",
      buttonType: "primary",
      onClick: jest.fn(),
    };
    const { container } = render(<BaseButton {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it("should call mock function when button is clicked", () => {
    const mockFnc = jest.fn();
    const props = {
      iconName: "AddIcon",
      iconPos: "right",
      buttonText: "Action",
      buttonSize: "large",
      buttonType: "primary",
      onClick: mockFnc,
      isActive: false,
    };
    render(<BaseButton {...props} />);
    const button = screen.getByRole("button");
    fireEvent.click(button);
    expect(mockFnc).toHaveBeenCalledTimes(1);
  });
  it("renders a primary button with disabled attribute", () => {
    const props = {
      iconName: "AddIcon",
      iconPos: "right",
      buttonText: "Action",
      buttonSize: "large",
      buttonType: "primary",
      disabled: true,
      isActive: false,
    };
    const { container } = render(<BaseButton {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
