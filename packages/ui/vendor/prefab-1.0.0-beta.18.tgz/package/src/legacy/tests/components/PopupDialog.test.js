import { render, screen, fireEvent } from "@testing-library/react";
import PopupDialog from "../../components/PopupDialog";

const onConfirmMock = jest.fn();

const PopupSample = (
  <PopupDialog
    isOpen={true}
    title="Title"
    bodyContent="This is a Test Module"
    onClose={onConfirmMock}
    onConfirm={onConfirmMock}
  />
);

describe("Popup", () => {
  it("renders without crashing", () => {
    const { unmount } = render(PopupSample);
    unmount();
  });

  it("renders correctly", () => {
    const { container } = render(PopupSample);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("renders content in <p> when passed as string", () => {
    render(PopupSample);
    expect(screen.getByText("This is a Test Module")).toBeInTheDocument();
  });

  it("calls onConfirm action on confirm button click", () => {
    const onConfirm = jest.fn();
    const component = (
      <PopupDialog
        isOpen={true}
        title="Title"
        bodyContent="This is a Test Module"
        onClose={jest.fn()}
        onConfirm={onConfirm}
      />
    );
    render(component);
    const confirmButton = screen.getByRole("button", { name: /ok/i });
    fireEvent.click(confirmButton);
    expect(onConfirm).toHaveBeenCalled();
  });
});
