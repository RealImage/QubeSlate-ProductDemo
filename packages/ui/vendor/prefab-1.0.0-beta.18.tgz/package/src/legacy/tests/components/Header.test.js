import { render, screen } from "@testing-library/react";
import Header from "../../components/Header";

describe("Header", () => {
  it("renders without crashing", () => {
    const { unmount } = render(<Header name="test" isLoading={false} />);
    unmount();
  });

  it("Test:snapshot", () => {
    const { container, rerender } = render(<Header name="test" isLoading={false} />);
    expect(container.firstChild).toMatchSnapshot();
    rerender(<Header name="test" isLoading={false} count={3} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("Test: should not show count when count prop is not set", () => {
    const { container } = render(<Header name="test" isLoading={false} />);
    expect(container.querySelector(".headerBadge")).toBeNull();
  });

  it("Test: should not view count when isLoading is set", () => {
    const { container } = render(<Header name="test" isLoading />);
    expect(container.querySelector(".headerBadge")).toBeNull();
  });

  it("Test: should show count", () => {
    const { container } = render(<Header name="test" isLoading={false} count={4} />);
    expect(container.querySelector(".headerBadge")).toHaveTextContent("4");
  });

  it("Test: should show active count", () => {
    const { container } = render(<Header name="test" isLoading={false} activeCount={4} />);
    expect(container.querySelector(".active.badge")).toHaveTextContent("4");
  });

  it("Test: should render Right side view ", () => {
    const Test = () => <div data-testid="test-component">test</div>;
    render(<Header name="test" isLoading={false} renderRightSideComponent={() => <Test />} />);
    expect(screen.getByTestId("test-component")).toBeInTheDocument();
  });

  it("Test: should render Right side Buttons", () => {
    const { container } = render(
      <Header
        name="test"
        isLoading={false}
        buttons={[{ text: "Button.sync" }, { text: "Button.save" }]}
      />,
    );
    expect(container.querySelectorAll("button")).toHaveLength(2);
  });
});
