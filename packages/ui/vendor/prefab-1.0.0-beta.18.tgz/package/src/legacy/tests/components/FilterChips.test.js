import { render, fireEvent, screen } from "@testing-library/react";
import takeRight from "lodash/takeRight";
import FilterChips from "../../components/Filters/FilterChips";

const filters = [
  {
    id: "c6277525-3320-477b-ba27-6a436aae70fc",
    name: "TEST_CODE (Code)",
    type: "notificationCode",
    displayName: "Test",
    context: {},
  },
  {
    id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971cc",
    name: "TEST (Code)",
    type: "notificationCode",
    displayName: "Test",
    context: {},
  },
  {
    id: "c11f042c-2e4d-49c8-b369-83bfa9cabfe7",
    name: "Test 1 (Sub Category 1)",
    type: "productCategory",
    displayName: "Test 1",
    context: null,
  },
  {
    id: "ceafa120-b261-41d6-9236-2513a6fd8fa0",
    name: "Test_2 (Sub Category 2)",
    type: "productCategory",
    displayName: "Test_2",
    context: null,
  },
  {
    id: "325e71d2-5002-4921-9e44-f852bc4552fe",
    name: "test ----1 (Sub Category 1)",
    type: "productCategory",
    displayName: "Test -1",
    context: {},
  },
  {
    id: "4c9a4f78-13b9-47b1-b203-da9cef9d774b",
    name: "test (Sub Category 1)",
    type: "productCategory",
    displayName: "Sub 1",
    context: {},
  },
  {
    id: "80c62475-a9a5-4603-9931-f80287da54a1",
    name: "TEST_TEMPLATE_UPA (Code)",
    type: "notificationCode",
    displayName: "TT",
    context: {},
  },
];

const FilterChipsSample = <FilterChips onFilterChange={jest.fn()} selected={filters} />;

describe("FilterChips", () => {
  it("renders without crashing", () => {
    const { unmount } = render(FilterChipsSample);
    unmount();
  });

  it("renders correctly", () => {
    const { container, rerender } = render(FilterChipsSample);
    expect(container.firstChild).toMatchSnapshot();
    rerender(<FilterChips onFilterChange={jest.fn()} selected={filters} resultsCount={3} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("renders nothing when filters is not passed", () => {
    const { container } = render(<FilterChips selected={[]} onFilterChange={jest.fn()} />);
    expect(container.firstChild).toBeNull();
  });

  it("renders nothing when loading prop is set", () => {
    const { container } = render(
      <FilterChips loading selected={filters} onFilterChange={jest.fn()} />,
    );
    expect(container.firstChild).toBeNull();
  });

  it("shows result count when it is passed in and showResults is set", () => {
    render(
      <FilterChips
        showResultsCount
        resultsCount={2}
        onFilterChange={jest.fn()}
        selected={filters}
      />,
    );
    expect(screen.getByText("Showing 2 results for")).toBeInTheDocument();
  });

  it("shows result count when it is passed in and showResults is not set", () => {
    const { container } = render(
      <FilterChips
        showResultsCount={false}
        resultsCount={2}
        onFilterChange={jest.fn()}
        selected={filters}
      />,
    );
    expect(container.querySelector("span.resultsCount")).toBeNull();
  });

  it("removes one filter item on clicking its remove", () => {
    const onRemoveMock = jest.fn();
    const { container } = render(<FilterChips onFilterChange={onRemoveMock} selected={filters} />);
    const expected = takeRight(filters, filters.length - 1);
    const firstRemoveButton = container.querySelector("button");
    if (firstRemoveButton) {
      fireEvent.click(firstRemoveButton);
      expect(onRemoveMock).toHaveBeenCalled();
      expect(onRemoveMock).toHaveBeenCalledWith(expected);
    }
  });

  it("removes all filter items on clicking clear all", () => {
    const onRemoveMock = jest.fn();
    const { container } = render(<FilterChips onFilterChange={onRemoveMock} selected={filters} />);
    const clearAllButton = container.querySelector("span.chip.danger");
    if (clearAllButton) {
      fireEvent.click(clearAllButton);
      expect(onRemoveMock).toHaveBeenCalled();
      expect(onRemoveMock).toHaveBeenCalledWith([]);
    }
  });

  it("clear all filter button should be available when there is at least 1 chips", () => {
    const onRemoveMock = jest.fn();
    const { container } = render(
      <FilterChips onFilterChange={onRemoveMock} selected={[filters[0]]} />,
    );
    expect(container.querySelector("span.chip.danger")).toBeTruthy();
  });
});
