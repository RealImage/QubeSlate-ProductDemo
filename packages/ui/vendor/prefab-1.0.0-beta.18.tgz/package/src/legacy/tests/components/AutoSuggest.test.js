import { render, fireEvent } from "@testing-library/react";
import AutoSuggest from "../../components/AutoSuggest";
import MenuItem from "../../components/MenuItem";

const list = [
  {
    id: "1",
    name: "ELECTRONICS",
    type: "test",
  },
  {
    id: "2",
    name: "Home appliances",
    type: "test",
  },
];
const onItemSelectMock = jest.fn();
const BPSuggestSample = (
  <AutoSuggest
    items={list}
    placeholder="Pick an item"
    onItemSelect={onItemSelectMock}
    itemRenderer={(item, itemProps) => (
      <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
    )}
    inputValueRenderer={(item) => item.name}
  />
);

describe("AutoSuggest", () => {
  it("renders without crashing", () => {
    const { unmount } = render(BPSuggestSample);
    unmount();
  });

  it("renders correctly", () => {
    const { container, rerender } = render(BPSuggestSample);
    expect(container.firstChild).toMatchSnapshot();
    rerender(
      <AutoSuggest
        items={list}
        placeholder="Pick an item"
        onItemSelect={onItemSelectMock}
        itemRenderer={(item, itemProps) => (
          <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
        )}
        inputValueRenderer={(item) => item.name}
        selectedItem={list[0]}
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("calls onItemSelect, Updates Input and state", () => {
    const onItemSelect = jest.fn();
    const { container } = render(
      <AutoSuggest
        items={list}
        placeholder="Pick an item"
        onItemSelect={onItemSelect}
        itemRenderer={(item, itemProps) => (
          <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
        )}
        inputValueRenderer={(item) => item.name}
        openOnKeyDown={true}
      />,
    );

    const input = container.querySelector("input");
    fireEvent.keyDown(input);

    const firstLink = container.querySelector("a");
    if (firstLink) {
      fireEvent.click(firstLink);
      expect(onItemSelect.mock.calls.length).toBe(1);
      expect(input.value).toBe(list[0].name);
    }
  });
});
