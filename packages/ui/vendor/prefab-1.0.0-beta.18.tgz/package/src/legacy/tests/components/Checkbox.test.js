import { render, fireEvent } from "@testing-library/react";
import CheckBox from "../../components/Checkbox";

describe("<Checkbox />", () => {
  it("renders without crashing", () => {
    render(<CheckBox checked onChange={jest.fn()} />);
  });

  it("renders correctly", () => {
    const { container, rerender } = render(<CheckBox checked onChange={jest.fn()} />);
    expect(container.firstChild).toMatchSnapshot();

    rerender(<CheckBox checked={false} onChange={jest.fn()} />);
    expect(container.firstChild).toMatchSnapshot();

    rerender(<CheckBox checked={false} onChange={jest.fn()} label="Test Label" />);
    expect(container.firstChild).toMatchSnapshot();

    rerender(<CheckBox checked={false} onChange={jest.fn()} label="Test Label" loading={true} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("should render checked icon when props checked is true", () => {
    const { container } = render(<CheckBox checked onChange={jest.fn()} />);
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  it("should render unchecked icon when props checked is false", () => {
    const { container } = render(<CheckBox checked={false} onChange={jest.fn()} />);
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  it("should render inderminate icon when indeterminate is set", () => {
    const { container } = render(<CheckBox checked={false} indeterminate onChange={jest.fn()} />);
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  it("should click the icon", () => {
    const mockChange = jest.fn();
    const { container } = render(<CheckBox checked onChange={mockChange} />);

    const svg = container.querySelector("svg");
    if (svg) {
      fireEvent.click(svg);
      expect(mockChange).toHaveBeenCalled();
    }
  });
});
