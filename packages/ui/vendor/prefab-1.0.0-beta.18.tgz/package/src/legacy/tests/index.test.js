import { render } from "@testing-library/react";
import { BaseButton } from "../components";
import * as Icons from "../assets/icon.js";

// These generally serve as "Smoke Tests";
// ensuring lib is not broken and all public components are exported
describe("Index", () => {
  it("exports BaseButton component", () => {
    expect(BaseButton).toBeTruthy();
  });
  it("exports Icons object", () => {
    expect(Icons).toBeTruthy();
  });
  it("Icons should be the object and should icons", () => {
    const { AddIcon } = Icons;
    const { container } = render(<AddIcon />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it("Icons exported should have valid svg icons", () => {
    const { AddIcon } = Icons;
    const { container } = render(<AddIcon />);
    expect(container.querySelector("svg")).toBeTruthy();
  });
});
