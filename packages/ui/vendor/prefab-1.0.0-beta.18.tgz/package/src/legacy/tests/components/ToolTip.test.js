import { render } from "@testing-library/react";
import ToolTip from "../../components/ToolTip";

const ToolTipSample = <ToolTip toolTip="ToolTip Text">H ello World</ToolTip>;
describe("ToolTip", () => {
  it("renders without crashing", () => {
    render(ToolTipSample);
  });

  it("renders correctly", () => {
    const { container } = render(ToolTipSample);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("renders with the text passed in", () => {
    const { container } = render(ToolTipSample);
    expect(container.firstChild).toMatchSnapshot();
  });
});
