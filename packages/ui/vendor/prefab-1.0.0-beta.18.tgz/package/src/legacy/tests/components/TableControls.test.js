import { render } from "@testing-library/react";
import TableControls from "../../components/TableControls";

describe("<TableControls/>", () => {
  const { container } = render(
    <TableControls
      hasSearch={false}
      filters={[
        {
          context: null,
          displayName: "Child Safe",
          id: "e3f69aaf-1889-47bc-8625-f68683426c67",
          name: "Child Safe (Certification)",
          type: "certificationChildSafety",
        },
      ]}
      controls={[]}
      onFilterChange={() => {}}
      onFilterSelect={() => {}}
      tagTypes={["certificationChildSafety"]}
      selectedColumns={["test", "test1"]}
      columnFilter={false}
    />,
  );
  it("should render controls", () => {
    expect(container.firstChild).toMatchSnapshot();
  });
  it("should display rightpanel when settingIcon is clicked", () => {
    const { container } = render(
      <TableControls
        hasSearch={false}
        filters={[
          {
            context: null,
            displayName: "Child Safe",
            id: "e3f69aaf-1889-47bc-8625-f68683426c67",
            name: "Child Safe (Certification)",
            type: "certificationChildSafety",
          },
        ]}
        controls={[]}
        onFilterChange={() => {}}
        onFilterSelect={() => {}}
        tagTypes={["certificationChildSafety"]}
        selectedColumns={["test", "test1"]}
        columnFilter={true}
        isOpen={true}
      />,
    );
    expect(container.firstChild).toBeTruthy();
  });
});
