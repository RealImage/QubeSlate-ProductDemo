import { render } from "@testing-library/react";
import NavProfile from "../../../components/NavigationBar/NavProfile";

const history = { location: { search: "" }, replace: jest.fn(), push: jest.fn() };

describe("<NavProfile/>", () => {
  const props = {
    history: history,
    name: "User",
    companyName: "Qube",
    isExpanded: false,
    isMenuActive: jest.fn(),
    onToggleButtonClick: jest.fn(),
    menuList: [{ name: "PageHeader.support", route: "/support" }],
  };

  it("renders without error", () => {
    const { unmount } = render(<NavProfile {...props} />);
    unmount();
  });

  it("renders correctly with props", () => {
    const { container } = render(<NavProfile {...props} isExpanded />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("renders tree completely", () => {
    const { container } = render(<NavProfile {...props} isExpanded />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("on expand renders user name and company name", () => {
    const { container } = render(<NavProfile {...props} isExpanded name="User" />);
    expect(container.querySelectorAll("div").length).toBeGreaterThan(2);
    expect(container).toHaveTextContent("User");
    expect(container).toHaveTextContent("Qube");
  });
});
