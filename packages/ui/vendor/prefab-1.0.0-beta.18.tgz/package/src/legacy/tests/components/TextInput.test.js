import { render, screen, fireEvent } from "@testing-library/react";
import TextInput from "../../components/TextInput";

describe("TextInput", () => {
  const onChangeMock = jest.fn();
  const baseProps = {
    id: "text-input",
    onChange: onChangeMock,
    className: "someClass",
    placeholder: "Enter text",
    label: "Text Sample",
    error: false,
    errorMessage: "Inline Alert",
  };

  it("renders without crashing", () => {
    render(<TextInput {...baseProps} />);
  });

  it("renders correctly", () => {
    const { container, rerender } = render(<TextInput {...baseProps} />);
    expect(container.firstChild).toMatchSnapshot();
    rerender(<TextInput {...baseProps} error={true} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("shows inline alert on error", () => {
    render(<TextInput {...baseProps} error={true} errorMessage="Mock Message" />);
    expect(screen.getByText("Mock Message")).toBeInTheDocument();
  });

  it("calls onChange action on input change", () => {
    render(<TextInput {...baseProps} />);
    fireEvent.change(screen.getByPlaceholderText("Enter text"), { target: { value: "foo" } });
    expect(onChangeMock).toHaveBeenCalled();
  });

  it("should not allow text or special characters when `onlyNumbers` props is true", () => {
    const onInputChangeMock = jest.fn();
    render(<TextInput {...baseProps} onlyNumbers={true} onChange={onInputChangeMock} />);
    fireEvent.change(screen.getByPlaceholderText("Enter text"), {
      target: { value: "asdcvgh!^%" },
    });
    expect(onInputChangeMock).toHaveBeenCalledWith("");
  });

  it("should allow only numbers when `onlyNumbers` props is true", () => {
    const onInputChangeMock = jest.fn();
    render(<TextInput {...baseProps} onlyNumbers={true} onChange={onInputChangeMock} />);
    fireEvent.change(screen.getByPlaceholderText("Enter text"), {
      target: { value: "3242323423" },
    });
    expect(onInputChangeMock).toHaveBeenCalledTimes(1);
  });

  it("should return value as type number when `onlyNumbers` props is true", () => {
    let enteredValue = "";
    const onInputChangeMock = (value) => {
      enteredValue = value;
      return value;
    };
    render(<TextInput {...baseProps} onlyNumbers={true} onChange={onInputChangeMock} />);
    fireEvent.change(screen.getByPlaceholderText("Enter text"), {
      target: { value: "3242323423" },
    });
    expect(enteredValue).toBe(3242323423);
  });

  it("should allow only numbers in alphanumeric input when `onlyNumbers` props is true", () => {
    let enteredValue = "";
    const onInputChangeMock = (value) => {
      enteredValue += value;
      return value;
    };
    render(<TextInput {...baseProps} onlyNumbers onChange={onInputChangeMock} />);
    const chars = "a2bc32423".split("");
    chars.forEach((char) => {
      fireEvent.change(screen.getByPlaceholderText("Enter text"), { target: { value: char } });
    });
    expect(enteredValue).toBe("232423");
  });
});
