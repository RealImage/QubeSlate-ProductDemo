import { render } from "@testing-library/react";
import * as Icons from "../../../assets/icon.js";
import { NavMenuItem } from "../../../components/NavigationBar/NavMenuItem";

const { AudioIcon } = Icons;

const history = { location: { search: "" }, replace: jest.fn(), push: jest.fn() };

describe("NavMenuItem", () => {
  it("renders without error", () => {
    const { unmount } = render(
      <NavMenuItem
        history={history}
        isSelected={false}
        isExpanded={true}
        name="PageHeader.pendingApprovalNavHeading"
        Icon={AudioIcon}
        badge={40}
        handleMenu={() => {}}
        route="/user/pendingAproval"
      />,
    );
    unmount();
  });

  it("should render correctly", () => {
    const { container } = render(
      <NavMenuItem
        history={history}
        isSelected={false}
        isExpanded={true}
        name="PageHeader.pendingApprovalNavHeading"
        Icon={AudioIcon}
        badge={40}
        handleMenu={jest.fn()}
        route="/user/pendingAproval"
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
