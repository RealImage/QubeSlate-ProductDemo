import { getInitialsFromName } from "../../utils";

describe("Utils: getInitialsFromName", () => {
  it("returns Single letter", () => {
    expect(getInitialsFromName("RealImage")).toEqual("R");
  });
  it("returns 2 letter for 2 words", () => {
    expect(getInitialsFromName("Real Image")).toEqual("RI");
  });
  it("returns 2 letter for 3 words", () => {
    expect(getInitialsFromName("Real image Qube")).toEqual("RQ");
  });
  it("returns 2 letter for 4 words", () => {
    expect(getInitialsFromName("Real image Qube cinema")).toEqual("RC");
  });
  it("returns always cabs letter", () => {
    expect(getInitialsFromName("real image qube cinema")).toEqual("RC");
  });

  it("returns empty  when no value is passed", () => {
    expect(getInitialsFromName()).toEqual("");
    expect(getInitialsFromName("")).toEqual("");
    expect(getInitialsFromName(null)).toEqual("");
  });
});
