import { render, fireEvent } from "@testing-library/react";
import Selector from "../../components/Selector";

describe("Selector", () => {
  const onChangeMock = jest.fn();
  const baseProps = {
    label: "Button.select",
    list: ["1", "2", "3"],
    selectedList: [],
    placeHolder: "Button.select",
    onSelect: onChangeMock,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders without crashing", () => {
    render(<Selector {...baseProps} />);
  });

  it("renders correctly", () => {
    const { container, rerender } = render(<Selector {...baseProps} />);
    expect(container.firstChild).toMatchSnapshot();

    rerender(<Selector {...baseProps} selectedList={["1", "2"]} />);
    expect(container.firstChild).toMatchSnapshot();

    rerender(<Selector {...baseProps} selectedList={["1", "2"]} showLabelInButton={false} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("calls onSelect on item select", () => {
    const onSelectMock = jest.fn();
    const { container } = render(<Selector {...baseProps} onSelect={onSelectMock} defaultIsOpen />);

    const firstMenuItem = container.querySelector(".bp6-menu-item");
    if (firstMenuItem) {
      fireEvent.click(firstMenuItem);
      expect(onSelectMock).toHaveBeenCalled();
    }
  });

  it("allows multiple selection of items", () => {
    const onSelectMock = jest.fn();
    const { container } = render(
      <Selector {...baseProps} selectedList={["2"]} onSelect={onSelectMock} defaultIsOpen />,
    );

    const menuItems = container.querySelectorAll(".bp6-menu-item");
    if (menuItems.length > 1) {
      fireEvent.click(menuItems[1]); // Click second item
      expect(onSelectMock).toHaveBeenCalled();
      expect(onSelectMock).toHaveBeenCalledWith(["2", "1"]);
    }
  });

  it("allows single selection of items using singleSelect prop", () => {
    const onSelectMock = jest.fn();
    const { container } = render(
      <Selector
        {...baseProps}
        singleSelect
        selectedList={["2"]}
        onSelect={onSelectMock}
        defaultIsOpen
      />,
    );

    const menuItems = container.querySelectorAll(".bp6-menu-item");
    if (menuItems.length > 0) {
      fireEvent.click(menuItems[0]); // Click first item
      expect(onSelectMock).toHaveBeenCalled();
      expect(onSelectMock).toHaveBeenCalledWith(["1"]);
    }
  });

  it("unselects item when it is selected again", () => {
    const onSelectMock = jest.fn();
    const { container } = render(
      <Selector {...baseProps} selectedList={["1"]} onSelect={onSelectMock} defaultIsOpen />,
    );

    const menuItems = container.querySelectorAll(".bp6-menu-item");
    if (menuItems.length > 0) {
      fireEvent.click(menuItems[0]); // Click first item
      expect(onSelectMock).toHaveBeenCalled();
      expect(onSelectMock).toHaveBeenCalledWith([]);
    }
  });

  it("does not unselect item in singleSelect when it is selected again", () => {
    const onSelectMock = jest.fn();
    const { container } = render(
      <Selector
        {...baseProps}
        singleSelect
        selectedList={["1"]}
        onSelect={onSelectMock}
        defaultIsOpen
      />,
    );

    const menuItems = container.querySelectorAll(".bp6-menu-item");
    if (menuItems.length > 0) {
      fireEvent.click(menuItems[0]); // Click first item
      expect(onSelectMock).toHaveBeenCalled();
      expect(onSelectMock).toHaveBeenCalledWith(["1"]);
    }
  });

  it("shows inline label when showLabelInButton is disabled", () => {
    const { container } = render(
      <Selector {...baseProps} showLabelInButton={false} selectedList={["1", "2", "3"]} />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("allows passing array of objects of the form {id: id, value: value}", () => {
    const objectList = [
      { id: "1", value: "first" },
      { id: "2", value: "second" },
      { id: "3", value: "third" },
    ];
    const onSelectMock = jest.fn();

    const { container } = render(
      <Selector
        {...baseProps}
        list={objectList}
        selectedList={[]}
        onSelect={onSelectMock}
        defaultIsOpen
      />,
    );

    const menuItems = container.querySelectorAll(".bp6-menu-item");
    if (menuItems.length > 0) {
      fireEvent.click(menuItems[0]); // Click first item
      expect(onSelectMock).toHaveBeenCalled();
      expect(onSelectMock).toHaveBeenCalledWith([{ id: "1", value: "first" }]);
    }
  });

  it("shows selected icon for single selected items by default", () => {
    const { container } = render(<Selector {...baseProps} selectedList={["1"]} defaultIsOpen />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("shows selected icon for multiple selected items by default", () => {
    const { container } = render(
      <Selector {...baseProps} selectedList={["1", "2"]} defaultIsOpen />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("does not show shows selected icon for selected items when noSelectedIcon prop is set", () => {
    const { container } = render(
      <Selector {...baseProps} selectedList={["1", "2"]} noSelectedIcon defaultIsOpen />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("shows select all option when multiSelect is allowed", () => {
    const { container } = render(<Selector {...baseProps} selectedList={[]} defaultIsOpen />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("does not show select all option when singleSelect is set", () => {
    const { container } = render(
      <Selector {...baseProps} singleSelect selectedList={[]} defaultIsOpen />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("shows selectedAll icon when all items are selected", () => {
    const { container } = render(
      <Selector {...baseProps} selectedList={["1", "2", "3"]} defaultIsOpen />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("does not show selectedAll icon when partial items are selected", () => {
    const { container } = render(
      <Selector {...baseProps} selectedList={["1", "2"]} defaultIsOpen />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
