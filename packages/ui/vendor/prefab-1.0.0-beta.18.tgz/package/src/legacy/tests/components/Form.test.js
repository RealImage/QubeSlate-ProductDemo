import { render, fireEvent } from "@testing-library/react";
import MockDate from "mockdate";
import Form from "../../components/Form";
import { FORM_FIELD_TYPES } from "../../constants";

MockDate.set("2020-03-13T18:30:00.000");
const mockDate = [new Date(), new Date()];

describe("<Form/>", () => {
  it("renders a Label without error", () => {
    const { container } = render(
      <Form
        config={[
          {
            id: "name",
            type: FORM_FIELD_TYPES.LABEL,
            label: "Label",
            value: "Non-input value",
          },
        ]}
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("render Date Range Field without error", () => {
    const mockOnchange = jest.fn();
    const { container } = render(
      <Form
        config={[
          {
            id: "name",
            type: FORM_FIELD_TYPES.DATE_RANGE_PICKER,
            placeholder: "Pick a date",
            dateRange: mockDate,
            handleDateChange: mockOnchange,
          },
        ]}
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });

  it("should trigger onChange when text onchange", () => {
    const mockOnchange = jest.fn();
    const { container } = render(
      <Form
        config={[
          {
            id: "name",
            type: FORM_FIELD_TYPES.DATE_RANGE_PICKER,
            placeholder: "Pick a date",
            dateRange: mockDate,
            handleDateChange: mockOnchange,
          },
        ]}
      />,
    );

    const input = container.querySelector('input[name="firstName"]');
    if (input) {
      fireEvent.change(input, { target: { value: "test value" } });
      expect(mockOnchange).toHaveBeenCalledTimes(1);
    }
  });
});
