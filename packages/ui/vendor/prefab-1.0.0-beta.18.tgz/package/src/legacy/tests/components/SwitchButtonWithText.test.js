import { render, screen, fireEvent } from "@testing-library/react";
import ViewSwitch from "../../components/ViewSwitch";

const mockButtons = [
  {
    onClick: () => {},
    text: "Button.theatres",
  },
];
const component = <ViewSwitch label="VIEW AS" buttons={mockButtons} />;

describe("<ViewSwitch />", () => {
  it("renders without crashing", () => {
    const { unmount } = render(component);
    unmount();
  });

  it("renders correctly", () => {
    const { container } = render(component);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("check click the button", () => {
    const onClick = jest.fn();
    const mockButtonsWithClick = [
      {
        onClick: onClick,
        text: "Button.theatres",
      },
    ];
    render(<ViewSwitch label="VIEW AS" buttons={mockButtonsWithClick} />);
    const button = screen.getByRole("button");
    fireEvent.click(button);
    expect(onClick).toHaveBeenCalled();
  });
});
