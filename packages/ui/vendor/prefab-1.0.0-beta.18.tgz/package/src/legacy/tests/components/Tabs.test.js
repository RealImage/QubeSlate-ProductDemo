import { render } from "@testing-library/react";
import TabsView from "../../components/Tabs";

const view = (
  <TabsView
    animate={true}
    id="navbar"
    defaultSelectedTabId="details"
    selectedTabId="details"
    onChange={() => {}}
    tabs={[
      {
        id: "details",
        title: "Details",
        goto: "/details",
        panel: <div>Details</div>,
      },
      {
        id: "Campaigns",
        title: "Campaigns",
        goto: "/Campaigns",
        panel: <div>Campaigns</div>,
      },
    ]}
  />
);

describe("<TabsView/>", () => {
  it("Render Without Error", () => {
    const { container } = render(view);
    expect(container.firstChild).toMatchSnapshot();
  });
});
