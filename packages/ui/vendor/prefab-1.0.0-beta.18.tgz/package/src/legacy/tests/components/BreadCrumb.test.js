import { render, fireEvent } from "@testing-library/react";
import BreadCrumb from "../../components/BreadCrumb";

describe("<BreadCrumb/>", () => {
  const links = [
    { name: "test1", path: "/test1" },
    { name: "test2", path: "/test2" },
    { name: "test3", path: "/test3" },
    { name: "test4", path: "/test4" },
    { name: "test5", path: "/test5" },
    { name: "test6", path: "/test6" },
    { name: "current" },
  ];

  it("renders without error", () => {
    const { container } = render(<BreadCrumb links={links} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("handles bread crumb navigation", () => {
    const { container } = render(<BreadCrumb links={links} />);

    const collapsedElement = container.querySelector(".bp6-breadcrumbs-collapsed");
    if (collapsedElement) {
      fireEvent.click(collapsedElement);

      const menuItems = container.querySelectorAll(".bp6-menu .bp6-menu-item");
      if (menuItems.length > 2) {
        fireEvent.click(menuItems[2]);
      }
    }
  });
});
