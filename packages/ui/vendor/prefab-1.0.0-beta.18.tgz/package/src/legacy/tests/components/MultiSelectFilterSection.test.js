import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import MultiSelectFilterSection from "../../components/Filters/MultiSelectFilterSection";

jest.useFakeTimers();

const items = [
  {
    id: "32b4ca99-5622-4909-b626-510bd57cb972",
    name: "Watches",
    type: "Category",
    updatedAt: "2019-05-29T11:16:24.318123Z",
  },
  {
    id: "bae15eb7-fe77-41d6-9be3-b4bf9f7940d0",
    name: "Clothes",
    type: "Category",
    updatedAt: "2019-05-28T08:01:56.534239Z",
  },
];

const actions = {
  itemPredicate: jest.fn(),
  onItemSelect: jest.fn(),
  onQueryChange: jest.fn(),
  onFilterChange: jest.fn(),
};

const component = (
  <MultiSelectFilterSection
    label="MultiSelect"
    className="col-12"
    suggestionList={items}
    selected={[items[0]]}
    popoverProps={{ minimal: true }}
    tagInputProps={{ placeholder: "Search" }}
    selectedItems={[{ id: "1", name: "One" }]}
    {...actions}
  />
);

describe("Multiselect with Checkbox", () => {
  it("renders without crashing", () => {
    const { unmount } = render(component);
    unmount();
  });

  it("render correctly", () => {
    const { container } = render(component);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("check onQueryChange when input change", async () => {
    render(component);
    const input = screen.getByPlaceholderText("Search");
    fireEvent.change(input, { target: { value: "test" } });
    await waitFor(() => {
      expect(actions.onQueryChange).toHaveBeenCalled();
    });
  });
});
