import { render, fireEvent, screen } from "@testing-library/react";
import FilterSection from "../../components/Filters/FilterSection";

const onFilterChangeMock = jest.fn();
const onFilterClearMock = jest.fn();

const tagList = [
  { id: 1, displayName: "EXBT_SAHSA", type: "businessType" },
  { id: 2, displayName: "EXBT_QAHSA", type: "businessType" },
  { id: 3, displayName: "Media Agency", type: "businessType" },
  { id: 4, displayName: "Exhibitor", type: "businessType" },
];

const filterSection = (
  <FilterSection
    tagType={"businessType"}
    header={"Business Type"}
    selected={[]}
    filterType={"list"}
    tagList={tagList}
    onFilterChange={onFilterChangeMock}
    onFilterClear={onFilterClearMock}
  />
);
const filterSectionFill = (
  <FilterSection
    filterType={"list"}
    tagType={"businessType"}
    header={"Business Type"}
    selected={[
      { id: 1, displayName: "EXBT_SAHSA" },
      { id: 2, displayName: "EXBT_QAHSA" },
    ]}
    tagList={tagList}
    onFilterChange={onFilterChangeMock}
    onFilterClear={onFilterClearMock}
  />
);

describe("<FilterSection/>", () => {
  it("renders without error", () => {
    const { unmount } = render(filterSection);
    unmount();
  });
  it("renders correctly", () => {
    const { container, rerender } = render(filterSection);
    expect(container.firstChild).toMatchSnapshot();
    rerender(
      <FilterSection
        tagType={"businessType"}
        header={"Business Type"}
        selected={[
          { id: 1, displayName: "EXBT_SAHSA" },
          { id: 2, displayName: "EXBT_QAHSA" },
        ]}
        filterType={"list"}
        tagList={tagList}
        onFilterChange={onFilterChangeMock}
        onFilterClear={onFilterClearMock}
      />,
    );
    expect(container.firstChild).toMatchSnapshot();
  });
  it("renders header with count of selected tagType", () => {
    render(filterSectionFill);
    expect(screen.getByText("Business Type (2)")).toBeInTheDocument();
  });
  it("renders clear when len(selected) > 0 ", () => {
    render(filterSectionFill);
    expect(screen.getByText("Clear")).toBeInTheDocument();
  });
  it("doesn't render clear when len(selected) < 0", () => {
    render(filterSection);
    expect(screen.queryByText("Clear")).not.toBeInTheDocument();
  });
  it("calls onFilterChange func when click(clear)", () => {
    render(filterSectionFill);
    const clearButton = screen.getByText("Clear");
    fireEvent.click(clearButton);
    expect(onFilterClearMock).toHaveBeenCalled();
  });
  it("renders chevron down when isOpen is false ", () => {
    const { container } = render(filterSection);
    expect(container.querySelectorAll("button")).toHaveLength(1);
  });
  it("renders ListFilterSection when TAG_RENDER_TYPE is LIST", () => {
    const { container } = render(filterSection);
    // First click to expand the filter if it's collapsed
    const expandButton = container.querySelector("button");
    if (expandButton) {
      fireEvent.click(expandButton);
    }
    expect(container.firstChild).toBeTruthy();
  });
  it("renders DateRangeFilterSection when TAG_RENDER_TYPE is DATE_RANGE", () => {
    const { container } = render(
      <FilterSection
        filterType={"dateRange"}
        header={"Updated At"}
        tagType={"updatedAt"}
        selected={[]}
        tagList={tagList}
        onFilterChange={onFilterChangeMock}
        onFilterClear={onFilterClearMock}
      />,
    );
    const dateElements = container.querySelectorAll('input[type="text"], .bp6-input, .dateRange');
    expect(dateElements.length).toBeGreaterThan(0);
  });
});
