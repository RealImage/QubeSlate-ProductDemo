import { render } from "@testing-library/react";
import Alert from "../../components/Alert";

const component = (
  <Alert
    title="This content is less than 8GB and could be sent via smaller, more cost effective media (ie. USB stick/thumb drive)."
    bodyContent="If this work order will be fulfilled using alternative media, please remember to update your drive inventory accordingly. "
    showIcon={true}
    showClose={true}
    showSubText={true}
    type="warning"
    iconName="AlertRoundedIcon"
  />
);

describe("<Alert />", () => {
  it("renders without crashing", () => {
    render(component);
  });

  it("renders correctly", () => {
    const { container, rerender } = render(component);
    expect(container.firstChild).toMatchSnapshot();
    rerender(<Alert {...component.props} icon="" />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
