import { Collapse as BlueprintCollapse } from "@blueprintjs/core";

/**
 * Collapse Component
 * @param {import('@blueprintjs/core').CollapseProps} props
 */
const Collapse = (props) => {
  const { children, ...rest } = props;

  return <BlueprintCollapse {...rest}>{children}</BlueprintCollapse>;
};

export default Collapse;
