import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Suggest as BlueprintSuggest } from "@blueprintjs/select";
import { Intent } from "@blueprintjs/core";

/**
 *  * @component
 *  <AutoSuggest />
 *  @example
 *  <AutoSuggest
 *    className={STRING}
 *    popoverProps={OBJECT}
 *    inputProps={OBJECT}
 *  />
 *  Direct implementation of Blueprint Select Suggest with custom styles.
 *  Refer https://blueprintjs.com/docs/#select/suggest for props
 *  Overriding inputProps and popoverProps for custom styles.
 */

class AutoSuggest extends Component {
  static defaultProps = {
    inputProps: {
      className: "",
    },
  };

  render() {
    const { inputProps, popoverProps, error, ...rest } = this.props;
    return (
      <BlueprintSuggest
        {...rest}
        className="autoSuggestMenu"
        inputProps={{
          ...inputProps,
          className: classNames("inputField", inputProps.className, {
            withRightIcon: inputProps.rightElement,
          }),
          intent: error ? Intent.DANGER : Intent.NONE,
        }}
        popoverProps={{
          matchTargetWidth: true,
          popoverClassName: "autoSuggestPopOver",
          usePortal: false,
          minimal: true,
          ...popoverProps,
        }}
      />
    );
  }
}

AutoSuggest.propTypes = {
  /**
   * Props to spread to the query InputGroup. To control this input, use query and onQueryChange
   */
  inputProps: PropTypes.object,
  /**
   * Props to spread to Popover. Note that content cannot be changed.
   */
  popoverProps: PropTypes.object,
  /**
   * To show intent with error style.
   */
  error: PropTypes.bool,
};

export default AutoSuggest;
