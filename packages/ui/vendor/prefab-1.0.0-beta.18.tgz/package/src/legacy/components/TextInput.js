import { Component } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import { Intent, FormGroup, InputGroup, Button } from "@blueprintjs/core";
import BaseButton from "./BaseButton";

class TextInput extends Component {
  static propTypes = {
    label: PropTypes.string,
    id: PropTypes.string,
    className: PropTypes.string,
    error: PropTypes.bool,
    withLabel: PropTypes.bool,
    errorMessage: PropTypes.string,
    onChange: PropTypes.func.isRequired,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    placeholder: PropTypes.string,
    leftElement: PropTypes.any,
    rightElement: PropTypes.any,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    disabled: PropTypes.bool,
    isOptional: PropTypes.bool,
    onlyNumbers: PropTypes.bool,
    withRightIcon: PropTypes.bool,
    labelClass: PropTypes.string,
    type: PropTypes.string,
    loading: PropTypes.bool,
  };

  static defaultProps = {
    isOptional: false,
    withRightIcon: true,
    type: "text",
    onlyNumbers: false,
    withLabel: false,
    leftElement: null,
    rightElement: null,
  };

  handleInputChange = (event) => {
    const { value } = event?.target || {};
    const { onlyNumbers, onChange } = this.props;

    if (onlyNumbers) {
      const numericValue = value.replace(/[^0-9]/g, "");
      if (!/^[0-9]*$/.test(value)) event.preventDefault();
      // Adding the check to avoid NaN
      const parsedValue = numericValue ? parseInt(numericValue) : "";
      onChange(parsedValue);
    } else {
      onChange(event);
    }
  };

  renderLabel = () => {
    const { label, isOptional, labelClass } = this.props;
    return (
      <div className={classNames(labelClass, "label")}>
        {label}
        {isOptional && <span>(Optional)</span>}
      </div>
    );
  };

  renderRightElement = () => {
    if (!this.props.withRightIcon) return null;
    if (this.props.loading) return <Button icon="refresh" loading variant="minimal" />;

    if (this.props.value && this.props.value.length > 0)
      return (
        <BaseButton
          iconName="CancelIcon"
          className="rightElementClear"
          onClick={this.props.onSearchClear}
        />
      );
    return <BaseButton iconName="SearchIcon" className="rightElementSearch" />;
  };

  render() {
    const {
      id,
      withLabel,
      className,
      error,
      errorMessage,
      onFocus,
      onBlur,
      onKeyDown,
      placeholder,
      leftElement,
      withRightIcon,
      value,
      type,
      disabled,
      maxLength,
      min,
      max,
      loading,
    } = this.props;
    return (
      <FormGroup
        helperText={error && <span>{errorMessage}</span>}
        label={withLabel && this.renderLabel()}
        labelFor={withLabel && id}
        className={classNames(className, "inputLabel")}
        intent={error ? Intent.DANGER : Intent.NONE}
        inline={true}
      >
        <InputGroup
          className={classNames("inputField", { withRightIcon: withRightIcon })}
          intent={error ? Intent.DANGER : Intent.NONE}
          id={id}
          onChange={this.handleInputChange}
          onFocus={onFocus}
          onBlur={onBlur}
          onKeyDown={onKeyDown}
          leftElement={leftElement}
          rightElement={this.renderRightElement()}
          placeholder={placeholder}
          value={value || ""}
          type={type}
          disabled={disabled}
          maxLength={maxLength}
          min={min}
          max={max}
          loading={loading}
        />
      </FormGroup>
    );
  }
}

export default TextInput;
