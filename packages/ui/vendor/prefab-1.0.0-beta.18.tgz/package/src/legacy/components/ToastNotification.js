import { useRef, useImperativeHandle, forwardRef } from "react";
import { OverlayToaster, Intent } from "@blueprintjs/core";
import { AlertFilledIcon, CancelRoundedIcon, ConfirmCircleFilledIcon } from "../assets/icon";
import BaseButton from "./BaseButton";

const ToastNotification = forwardRef(({ position = "top-right", ...bpToasterProps }, ref) => {
  const toasterRef = useRef(null);

  useImperativeHandle(ref, () => ({
    showToast: ({ title, message, intent, size = "large", action, ...rest }) => {
      const intentMap = {
        primary: {
          bpIntent: Intent.PRIMARY,
          icon: <ConfirmCircleFilledIcon width="24px" height="24px" color="#084782" />,
        },
        success: {
          bpIntent: Intent.SUCCESS,
          icon: <ConfirmCircleFilledIcon width="24px" height="24px" color="#3D9657" />,
        },
        danger: {
          bpIntent: Intent.DANGER,
          icon: <AlertFilledIcon width="24px" height="24px" color="#CF1322" />,
        },
        warning: {
          bpIntent: Intent.WARNING,
          icon: <AlertFilledIcon width="24px" height="24px" color="#F0A203" />,
        },
        reject: {
          bpIntent: Intent.NONE, // optional: treat as custom
          icon: <CancelRoundedIcon width="24px" height="24px" color="#084782" />,
        },
      };

      const { bpIntent, icon } = intentMap[intent] || {
        bpIntent: Intent.NONE,
        icon: null,
      };
      const toaster = toasterRef.current;

      if (toaster) {
        toaster.show({
          message: (
            <div className="custom-toast">
              <div className="toast-left-bar" />
              <div className="toast-content">
                <div className="toast-header">
                  {icon && <span className="toast-icon">{icon}</span>}
                  <span className="toast-title">{title}</span>
                </div>
                {size === "large" && message && <div className="toast-message">{message}</div>}
                {size === "large" && action && (
                  <div className="toast-actions">
                    <BaseButton
                      buttonType="primary"
                      buttonSize="small"
                      className="toast-action-button"
                      buttonText={action.label}
                      onClick={() => {
                        if (action.onClick) {
                          action.onClick();
                        }
                        if (action.dismissOnClick !== false) {
                          toaster.clear();
                        }
                      }}
                    />
                  </div>
                )}
              </div>
            </div>
          ),
          intent: bpIntent,
          timeout: 600000000,
          className: `toast-container toast-${size} toast-${intent}`,
          ...rest,
        });
      }
    },
  }));

  return <OverlayToaster ref={toasterRef} position={position} {...bpToasterProps} />;
});

ToastNotification.displayName = "ToastNotification";

export default ToastNotification;
