import { Component } from "react";
import PropTypes from "prop-types";
import { Dialog, Classes } from "@blueprintjs/core";

import classNames from "classnames";
import { InfoFilledIcon } from "../assets/icon.js";
import { BUTTON_TYPE, SIZE } from "../constants";
import BaseButton from "./BaseButton";

class PopupDialog extends Component {
  render() {
    const {
      isOpen,
      icon,
      showIcon,
      title,
      bodyContent,
      onClose,
      onConfirm,
      cancelButtonText,
      confirmButtonText,
      className,
      children,
      hideFooter,
      confirmButtonProps,
      cancelButtonProps,
      mode = "dialog",
      portalClassName,
      ...props
    } = this.props;
    return (
      <Dialog
        isOpen={isOpen}
        icon={showIcon && icon}
        onClose={onClose}
        title={title}
        portalClassName={classNames(
          portalClassName,
          { "popup-sheet-mode": mode === "sheet" },
          { "popup-auto-mode": mode === "auto" },
        )}
        className={classNames("popup", className)}
        {...props}
      >
        <div className={Classes.DIALOG_BODY}>{bodyContent || children}</div>
        {!hideFooter && (
          <div className={Classes.DIALOG_FOOTER}>
            <div className={Classes.DIALOG_FOOTER_ACTIONS}>
              {cancelButtonText && (
                <BaseButton
                  onClick={onClose}
                  buttonText={cancelButtonText}
                  buttonType={BUTTON_TYPE.PRIMARY}
                  buttonSize={SIZE.SMALL}
                  {...cancelButtonProps}
                />
              )}
              {confirmButtonText && (
                <BaseButton
                  onClick={onConfirm}
                  buttonText={confirmButtonText}
                  buttonSize={SIZE.SMALL}
                  {...confirmButtonProps}
                />
              )}
            </div>
          </div>
        )}
      </Dialog>
    );
  }
}

PopupDialog.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  icon: PropTypes.oneOfType([PropTypes.string, PropTypes.element]),
  title: PropTypes.node,
  bodyContent: PropTypes.node.isRequired,
  onClose: PropTypes.func.isRequired,
  onConfirm: PropTypes.func,
  cancelButtonText: PropTypes.string,
  confirmButtonText: PropTypes.string,
  className: PropTypes.string,
  children: PropTypes.node,
  hideFooter: PropTypes.bool,
  cancelButtonProps: PropTypes.object,
  confirmButtonProps: PropTypes.object,
};

PopupDialog.defaultProps = {
  isOpen: false,
  icon: <InfoFilledIcon />,
  showIcon: true,
  cancelButtonText: "Cancel",
  confirmButtonText: "Ok",
  cancelButtonProps: {},
  confirmButtonProps: {},
};

export default PopupDialog;
