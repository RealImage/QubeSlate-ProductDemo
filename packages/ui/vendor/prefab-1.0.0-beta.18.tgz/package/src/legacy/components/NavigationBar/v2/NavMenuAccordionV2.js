import { useRef, useEffect, useState } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import NavMenuItemV2 from "./NavMenuItemV2";

function NavMenuAccordionV2({
  menu,
  isExpanded,
  validateActiveRoute,
  classNames: classNamesProp = {},
  onHeaderClickWhenCollapsed = null,
  isOpen = false,
  onToggle = null,
  history,
  onItemClick,
  isMobile,
}) {
  const childrenRefs = useRef([]);
  const [dotTop, setDotTop] = useState(null);

  const handleHeaderClick = () => {
    if (!isExpanded && onHeaderClickWhenCollapsed) {
      onHeaderClickWhenCollapsed();
    } else if (isExpanded) {
      onToggle();
    }
  };

  const selectedIndex = menu.menuList.findIndex((child) =>
    validateActiveRoute(Array.isArray(child.route) ? child.route : [child.route]),
  );

  useEffect(() => {
    if (selectedIndex !== -1 && childrenRefs.current[selectedIndex]) {
      const child = childrenRefs.current[selectedIndex];
      // Get the offsetTop relative to the parent container
      setDotTop(child.offsetTop + child.offsetHeight / 2 - 3); // 3 = dot radius
    } else {
      setDotTop(null);
    }
  }, [selectedIndex, isOpen, isExpanded, menu.menuList.length]);

  const isChildActive = selectedIndex !== -1;

  return (
    <div
      className={classNames(
        "navMenuAccordion_v2",
        { "navMenuAccordion_v2--open": isOpen && isExpanded },
        classNamesProp.navMenuAccordion,
      )}
    >
      <div onClick={handleHeaderClick} className="navMenuAccordion_v2__dropdown">
        <NavMenuItemV2
          name={menu.name}
          Icon={menu.Icon}
          isSelected={isChildActive}
          isExpanded={isExpanded}
          isAccordion
          isAccordionOpen={isOpen && isExpanded}
          history={history}
          onItemClick={onItemClick}
          classNames={classNamesProp}
          menuId={menu.accordionId}
        />
      </div>
      <div className="navMenuAccordion_v2__children">
        {menu.menuList.map((child, index) => (
          <NavMenuItemV2
            key={index}
            ref={(e) => (childrenRefs.current[index] = e)}
            {...child}
            isSelected={validateActiveRoute(
              Array.isArray(child.route) ? child.route : [child.route],
            )}
            route={Array.isArray(child.route) ? child.route[0] : child.route}
            isExpanded={isExpanded}
            history={history}
            onItemClick={onItemClick}
            isMobile={isMobile}
            classNames={classNamesProp}
            menuId={child.menuId}
          />
        ))}
        {dotTop !== null && (
          <div className="navMenuAccordion_v2__dot-indicator" style={{ top: dotTop }} />
        )}
      </div>
    </div>
  );
}

NavMenuAccordionV2.propTypes = {
  menu: PropTypes.object.isRequired,
  isExpanded: PropTypes.bool.isRequired,
  validateActiveRoute: PropTypes.func.isRequired,
  classNames: PropTypes.shape({
    navMenuAccordion: PropTypes.string,
  }),
  onHeaderClickWhenCollapsed: PropTypes.func,
  isOpen: PropTypes.bool,
  onToggle: PropTypes.func,
};

export default NavMenuAccordionV2;
