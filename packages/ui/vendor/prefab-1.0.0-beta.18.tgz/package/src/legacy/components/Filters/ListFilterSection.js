import { Component } from "react";
import PropTypes from "prop-types";
import Checkbox from "../Checkbox";
import SearchFilterSection from "./SearchFilterSection";

class ListFilterSection extends Component {
  state = {
    tagList: [],
    loading: true,
    showMore: false,
  };

  static propTypes = {
    tagType: PropTypes.oneOfType([PropTypes.string, PropTypes.arrayOf(PropTypes.string)])
      .isRequired,
    selected: PropTypes.array,
    onFilterChange: PropTypes.func.isRequired,
  };

  static defaultProps = {
    selected: [],
  };

  componentDidMount() {
    const { tagList } = this.props;
    this.setState({
      tagList: tagList,
      loading: false,
    });
  }

  componentDidUpdate(prevProps) {
    const { tagList } = this.props;
    if (tagList !== prevProps.tagList) {
      this.setState({
        tagList: tagList,
      });
    }
  }

  onFilterChange = (filter) => {
    this.props.onFilterChange(filter);
  };

  render() {
    const { selected, tagType, showMoreText = "Show More" } = this.props;
    const { tagList, loading, showMore } = this.state;
    if (loading) {
      return (
        <div>
          <Checkbox loading onChange={() => {}} checked={false} />
          <Checkbox loading onChange={() => {}} checked={false} />
        </div>
      );
    }
    // Fallback to Search UI if the list grows larger
    if (tagList.length > 20) return <SearchFilterSection {...this.props} />;
    let list,
      showMoreButton = null;
    if (showMore) list = tagList;
    else list = tagList.slice(0, 5);
    if (tagList.length > 5 && !showMore)
      showMoreButton = (
        <div className="showMore" onClick={() => this.setState({ showMore: true })}>
          {showMoreText}
        </div>
      );
    const selectedIds = selected.map((s) => s.id);
    return (
      <div>
        {list.map((tag, index) => (
          <Checkbox
            key={index}
            checked={selectedIds.includes(tag.id)}
            label={tag.displayName}
            onChange={() => this.onFilterChange({ type: tagType, ...tag })}
          />
        ))}
        {showMoreButton}
      </div>
    );
  }
}

export default ListFilterSection;
