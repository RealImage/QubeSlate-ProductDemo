/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import { Intent, Menu, FormGroup, PopoverNext, popoverPropsToNextProps } from "@blueprintjs/core";
import { DateInput } from "@blueprintjs/datetime";
import isNumber from "lodash/isNumber";
import isArray from "lodash/isArray";
import classNames from "classnames";
import PropTypes from "prop-types";
import { FORM_FIELD_TYPES, SIZE, BUTTON_TYPE } from "../constants";
import { ConfirmIcon } from "../assets/icon";
import TagSearch from "./Filters/TagSearch";
import AutoSuggest from "./AutoSuggest";
import ApiSearch from "./ApiSearch";
import Checkbox from "./Checkbox";
import MenuItem from "./MenuItem";
import DateRangePicker from "./DateRangePicker";
import Card from "./Card";
import BaseButton from "./BaseButton";

class Form extends Component {
  static propTypes = {
    config: PropTypes.array.isRequired,
  };

  renderTitle = (title) => <div className={"title"}>{title}</div>;

  renderError = (error, errorMessage) =>
    error && <div className="errorMessage">{errorMessage}</div>;

  renderAutoSuggest = (props, i) => {
    const { title, errorMessage, ...rest } = props;
    return (
      <div key={i}>
        {this.renderTitle(title)}
        <AutoSuggest key={i} {...rest} />
        {this.renderError(props.error, errorMessage)}
      </div>
    );
  };

  renderLabel = (props, i) => {
    const { value, label, title, onClick = null } = props;

    return (
      <div className="col-12" key={i} onClick={onClick}>
        <div className="title">{label || title}</div>
        <label className="label">{value}</label>
      </div>
    );
  };

  renderClearIcon = (props) => {
    if (!props.showClearIcon) return null;

    return (
      <BaseButton
        className={"clearSelection"}
        iconName="CancelRoundedIcon"
        buttonSize={SIZE.REGULAR}
        buttonType={BUTTON_TYPE.SECONDARY}
        onClick={props.onClear}
      />
    );
  };

  renderDate = (props, i) => {
    const {
      error,
      title,
      errorMessage,
      value,
      onChange,
      timePrecision,
      minDate,
      maxDate,
      disabled,
      defaultValue = new Date(),
      initialMonth = null,
      placeholder = "DD/MM/YYYY",
    } = props;
    return (
      <div key={i}>
        {this.renderTitle(title)}
        <DateInput
          className={classNames("inputField", { error: error })}
          defaultValue={defaultValue}
          initialMonth={initialMonth}
          disabled={disabled}
          dateFnsFormat="dd/MM/yyyy"
          onChange={onChange}
          popoverProps={{ usePortal: false }}
          placeholder={placeholder}
          value={value}
          timePrecision={timePrecision}
          minDate={minDate || new Date("1986-01-01")}
          maxDate={maxDate || new Date("2053-01-01")}
          rightElement={this.renderClearIcon(props)}
        />
        {this.renderError(error, errorMessage)}
      </div>
    );
  };

  renderMenu = (options, textKey, compareKey, value, onChange) => {
    return (
      <Menu>
        {options.map((item, index) => (
          <MenuItem
            key={index}
            text={item[textKey]}
            icon={value === item[compareKey] ? <ConfirmIcon /> : ""}
            onClick={() => onChange(item)}
          />
        ))}
      </Menu>
    );
  };

  renderDropDown = (props, i) => {
    const {
      title,
      error,
      errorMessage,
      value,
      displayText,
      textKey,
      compareKey,
      onChange,
      options,
    } = props;
    return (
      <div key={i}>
        <FormGroup
          label={title}
          helperText={error && <span>{errorMessage}</span>}
          intent={error ? Intent.DANGER : Intent.PRIMARY}
        >
          <PopoverNext
            {...popoverPropsToNextProps({
              usePortal: false,
              content: this.renderMenu(options, textKey, compareKey, value, onChange),
            })}
          >
            <BaseButton iconName="ChevronDownIcon" buttonText={displayText} />
          </PopoverNext>
        </FormGroup>
      </div>
    );
  };

  renderTagSearch = (props, i) => {
    const { title, label, errorMessage, createNewLink, ...rest } = props;
    return (
      <div key={i}>
        <div className="title">{label || title}</div>
        <TagSearch {...rest} />
        {this.renderError(props.error, errorMessage)}
      </div>
    );
  };

  renderApiSearch = (props, i) => {
    const { title, label, errorMessage, createNewLink, ...rest } = props;
    return (
      <div key={i}>
        <div className="title">{label || title}</div>
        <ApiSearch {...rest} />
        {this.renderError(props.error, errorMessage)}
      </div>
    );
  };

  renderCheckBox = (props, i) => {
    const { title, checked, onChange, label, errorMessage, ...rest } = props;
    return (
      <div key={i}>
        {this.renderTitle(title)}
        <Checkbox checked={checked} onChange={onChange} label={label} {...rest} />
        {this.renderError(props.error, errorMessage)}
      </div>
    );
  };

  renderDateRangePicker = (props, i) => {
    const { title, errorMessage, containerClassName, className, ...rest } = props;
    return (
      <div key={i} className={className}>
        {this.renderTitle(title)}
        <DateRangePicker {...rest} error={props.error} />
        {this.renderError(props.error, errorMessage)}
      </div>
    );
  };

  renderField = (c, i) => {
    const { type, is, ...fieldProps } = c;
    if (c.isLabel) return this.renderLabel(fieldProps, i);

    switch (type) {
      case FORM_FIELD_TYPES.BUTTON:
        return <BaseButton key={i} {...fieldProps} />;
      case FORM_FIELD_TYPES.AUTO_SUGGEST:
        return this.renderAutoSuggest(fieldProps, i);
      case FORM_FIELD_TYPES.LABEL:
        return this.renderLabel(fieldProps, i);
      case FORM_FIELD_TYPES.DATE:
        return this.renderDate(fieldProps, i);
      case FORM_FIELD_TYPES.DROP_DOWN:
        return this.renderDropDown(fieldProps, i);
      case FORM_FIELD_TYPES.TAG_SEARCH:
        return this.renderTagSearch(fieldProps, i);
      case FORM_FIELD_TYPES.API_SEARCH:
        return this.renderApiSearch(fieldProps, i);
      case FORM_FIELD_TYPES.CHECK_BOX:
        return this.renderCheckBox(fieldProps, i);
      case FORM_FIELD_TYPES.DATE_RANGE_PICKER:
        return this.renderDateRangePicker(fieldProps, i);
      default:
        return null;
    }
  };

  getCardSize = (size) => {
    if (isNumber(size)) {
      return {
        lg: size,
        md: size,
        sm: size,
        xs: size,
      };
    }

    return size;
  };

  renderCardContainer = (card, index) => {
    if (card.isHidden) return null;
    const { isFormGroup } = this.props;
    const cardSize = this.getCardSize(card.size || 12);
    const { containerClassName, ...rest } = card;
    return (
      <Card
        key={index}
        className={classNames(containerClassName, {
          formGroup: isFormGroup ?? true,
        })}
        {...cardSize}
      >
        {this.renderField(rest, index)}
      </Card>
    );
  };

  render() {
    const { config, childContainerClassName } = this.props;
    if (!config || config.length === 0) return null;

    return config.map((card, index) => {
      if (isArray(card)) {
        return (
          <div
            key={index}
            className={classNames(
              "col col-12 flex flex-wrap",
              "childContainer",
              childContainerClassName,
            )}
          >
            {card.map((item, cIndex) => this.renderCardContainer(item, cIndex))}
          </div>
        );
      } else {
        return this.renderCardContainer(card, index);
      }
    });
  }
}

export default Form;
