import { Component } from "react";
import PropTypes from "prop-types";
import debounce from "lodash/debounce";
import classNames from "classnames";
import { Button } from "@blueprintjs/core";
import { SearchIcon, AddIcon } from "../assets/icon.js";
import AutoSuggest from "./AutoSuggest";
import MenuItem from "./MenuItem";
import BaseButton from "./BaseButton";

/**
 * Component for Text Search that supports API call to get search results.
 *
 * @component
 * @example
 * <ApiSearch
 *    onSelect={FUNCTION},
 *    query={STRING},
 *    showSubText={BOOLEAN},
 *    parseResults={[{
 *      id: COMPARE_KEY,
 *      name: TEXT_KEY,
 *      tag: SUBTEXT_KEY,
 *    }]},
 *    fetchAction={FUNCTION}
 * />
 *
 * This expects func. parseResults to return array of objects it format as below
 *  {
 *    id: COMPARE_KEY,
 *    name: TEXT_KEY,
 *    tag: SUBTEXT_KEY,
 *    ...other properties
 *  }
 *
 */
class ApiSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchResults: [],
      loading: false,
      query: props.query || "",
      selectedItem: props.selectedItem || null,
    };
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.query !== this.props.query) {
      this.setState({
        query: this.props.query,
      });
    }
    if (prevProps.selectedItem !== this.props.selectedItem) {
      this.setState({
        selectedItem: this.props.selectedItem,
      });
    }
  };

  /**
   * @name search
   * @description Updates states with search results
   * fetchAction props should return a Promise
   * @param {string} value
   */
  search = async (value) => {
    try {
      const { data } = await this.props.fetchAction(value);
      const parsed = this.props.parseResults(data);
      this.setState({
        searchResults: parsed,
        loading: false,
      });
    } catch (error) {
      this.setState({ searchResults: [], loading: false });
    }
  };

  debouncedSearch = debounce(this.search, 600);

  onSearchClear = (event) => {
    event.preventDefault();
    this.setState({ query: "" });
    if (this.props.onSearchClear) this.props.onSearchClear();
  };

  /**
   * @name onChange
   * @description Controls input and updates the state with query, searchResults
   * @param {string} value
   * @example onChange("search");
   */
  onChange = (value) => {
    if (value === null || value === undefined || value.length === 0) {
      this.setState({
        query: "",
        searchResults: [],
        loading: false,
      });
      if (this.props.clearSelectOnReset) this.props.onSelect(null);
    } else {
      if (value !== this.state.query)
        this.setState({ query: value, loading: true }, () => this.debouncedSearch(value));
    }
  };

  /**
   * @name onSelect
   * @description Callback invoked when an item from the list is selected
   * Updates state with query and selectedItem
   * @param {object} item
   * @example
   * const item = {
   *    id: COMPARE_KEY,
   *    name: TEXT_KEY,
   *    tag: SUBTEXT_KEY,
   *    ...other properties
   *  }
   * onSelect(item);
   */
  onSelect = (item) => {
    if (!item || !item.id) return;
    this.props.onSelect(item);
    const { resetOnSelect } = this.props;
    this.setState({
      query: resetOnSelect ? "" : item.name,
      selectedItem: resetOnSelect ? null : item,
    });
  };

  /**
   * @name createNewItemFromQuery
   * @description If provided, allows new items to be created using the current query string
   * @param {string} query
   * @example
   * createNewItemFromQuery("Search");
   *
   * @param {string} query
   */
  createNewItemFromQuery = (query) => ({
    id: query,
    name: query,
    type: "-",
  });

  renderMenuItemWithSubText = (text, subText) => (
    <>
      <div className="api_text">{text}</div>
      <div className="api_subText">{subText}</div>
    </>
  );

  renderMenuItemWithSecondaryText = (data) => (
    <div className="withSecondaryText">
      <div className="api_text">{data.name}</div>
      <div className="api_secondaryText">{data.item?.code}</div>
    </div>
  );

  createNewItemRenderer = (query, active, handleClick) => {
    return (
      <MenuItem
        icon={<AddIcon />}
        className={`menuItem create-new-item`}
        text={`Create "${query}"`}
        active={active}
        onClick={handleClick}
        shouldDismissPopover={false}
      />
    );
  };

  render() {
    const { searchResults, loading, selectedItem, query } = this.state;
    const {
      placeholder,
      searchIconPos,
      showSubText,
      allowCreate = false,
      customCreateNewItemRenderer,
      disabled,
      error,
      onFocus,
      onBlur,
      className,
      noResultsText,
    } = this.props;
    const iconProps = {};
    if (searchIconPos === "left") iconProps.leftIcon = <SearchIcon className="searchIconPos" />;
    else if (searchIconPos === "right") {
      if (query.length)
        iconProps.rightElement = (
          <BaseButton
            iconName="CancelIcon"
            className="cursor rightElementClear"
            onClick={this.onSearchClear}
          />
        );
      else
        iconProps.rightElement = (
          <BaseButton iconName="SearchIcon" className="rightElementSearch" />
        );
    }
    if (loading) iconProps.rightElement = <Button icon="refresh" loading variant="minimal" />;

    const maybeCreateNewItemFromQuery = allowCreate ? this.createNewItemFromQuery : undefined;
    const maybeCreateNewItemRenderer =
      allowCreate && customCreateNewItemRenderer
        ? customCreateNewItemRenderer
        : allowCreate
          ? this.createNewItemRenderer
          : null;
    return (
      <AutoSuggest
        items={searchResults}
        query={query}
        selectedItem={selectedItem}
        inputProps={{
          ...iconProps,
          placeholder,
          disabled,
          onFocus,
          onBlur,
          className,
        }}
        onItemSelect={this.onSelect}
        itemRenderer={(item, itemProps) => (
          <MenuItem
            onClick={itemProps.handleClick}
            className={classNames("menuItem", {
              menuItemSelected: selectedItem?.id === item.id,
              menuItemActive: itemProps.modifiers.active,
              menuItemDisabled: itemProps.modifiers.disabled,
            })}
            key={item.id}
            text={
              showSubText
                ? this.renderMenuItemWithSubText(item.name, item.tag)
                : this.renderMenuItemWithSecondaryText(item)
            }
          />
        )}
        inputValueRenderer={(item) => (query ? item.name : "")}
        itemsEqual="id"
        noResults={
          !loading && query.length > 0 && searchResults.length === 0 ? (
            <MenuItem disabled={true} text={noResultsText} className="menuItem" />
          ) : undefined
        }
        onQueryChange={this.onChange}
        createNewItemFromQuery={maybeCreateNewItemFromQuery}
        createNewItemRenderer={maybeCreateNewItemRenderer}
        error={error}
      />
    );
  }
}

ApiSearch.propTypes = {
  /**
   * (item, event) => void
   * Callback invoked when an item from the list is selected, typically by clicking or pressing enter key.
   */
  onSelect: PropTypes.func.isRequired,
  /**
   * (data) => void
   * Callback to parse result which varies between different API function.
   */
  parseResults: PropTypes.func.isRequired,
  /**
   * API function to fetch data
   */
  fetchAction: PropTypes.func.isRequired,
  /**
   * Input placeholder
   */
  placeholder: PropTypes.string,
  /**
   * Position of Search Icon
   */
  searchIconPos: PropTypes.oneOf(["left", "right", "none"]),
  /**
   * Shows sub-text in Menu Items and parsedResults should have subText key
   */
  showSubText: PropTypes.bool,
  /**
   * Resets search query on select
   */
  resetOnSelect: PropTypes.bool,
  /**
   * Controls disabled state
   */
  disabled: PropTypes.bool,
  /**
   * Controls clear action on Menu Item select
   */
  clearSelectOnReset: PropTypes.bool,
  /**
   * Pre-filled Selected item during edit
   */
  selectedItem: PropTypes.object,
  /**
   * Text to display when no results found
   */
  noResultsText: PropTypes.string,
};

ApiSearch.defaultProps = {
  placeholder: "Search",
  searchIconPos: "right",
  showSubText: false,
  resetOnSelect: false,
  disabled: false,
  clearSelectOnReset: false,
  selectedItem: {},
  noResultsText: "No results found",
};

export default ApiSearch;
