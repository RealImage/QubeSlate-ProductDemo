import { useCallback } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { FormGroup, PopoverNext, Position, popoverPropsToNextProps } from "@blueprintjs/core";
import { ICON_POS, BUTTON_TYPE } from "../constants";
import { CheckboxIcon, CheckboxSelectedIcon } from "../assets/icon";
import BaseButton from "./BaseButton";
import TextInput from "./TextInput";

const MultiLevelSelector = ({
  filterCategories,
  selectedFilters = {},
  onFilterChange,
  onResetAll,
  onClearSelected,
  placeHolder,
  disabled = false,
  usePortal = false,
  className,
  showActionButtons = true,
  selectedCategory,
  searchQuery = "",
  filteredResults = [],
  isSearching = false,
  onCategorySelect,
  onSearchQueryChange,
  onOptionToggle,
}) => {
  const handleCategorySelect = useCallback(
    (categoryId) => {
      onCategorySelect(categoryId);
      onSearchQueryChange("");
    },
    [onCategorySelect, onSearchQueryChange],
  );

  const handleSearchQueryChange = useCallback(
    (query) => onSearchQueryChange?.(query),
    [onSearchQueryChange],
  );

  const handleOptionToggle = useCallback(
    (categoryId, option) => {
      if (onOptionToggle) return onOptionToggle(categoryId, option);

      const categoryFilters = selectedFilters[categoryId] || [];
      const exists = categoryFilters.some((f) => f.id === option.id);
      const newCategoryFilters = exists
        ? categoryFilters.filter((f) => f.id !== option.id)
        : [...categoryFilters, option];

      onFilterChange(categoryId, newCategoryFilters);
    },
    [selectedFilters, onFilterChange, onOptionToggle],
  );

  const handleResetAll = useCallback(() => {
    if (onResetAll) {
      onResetAll();
    } else {
      onFilterChange({});
    }
  }, [onResetAll, onFilterChange]);

  const handleClearSelected = useCallback(() => {
    if (onClearSelected) return onClearSelected(selectedCategory);
    if (selectedCategory) {
      onFilterChange({
        ...selectedFilters,
        [selectedCategory]: [],
      });
    }
  }, [onClearSelected, selectedCategory, selectedFilters, onFilterChange]);

  const getTotalSelectedCount = useCallback(() => {
    return Object.values(selectedFilters).reduce(
      (t, arr) => t + (Array.isArray(arr) ? arr.length : 0),
      0,
    );
  }, [selectedFilters]);

  const getCategorySelectedCount = (id) => (selectedFilters[id] || []).length;

  const getCurrentCategory = useCallback(
    () => filterCategories.find((cat) => cat.id === selectedCategory),
    [filterCategories, selectedCategory],
  );

  const isCurrentCategorySearchEnabled = () => !!getCurrentCategory()?.enableSearch;

  const getCurrentCategoryOptions = useCallback(() => {
    const category = getCurrentCategory();
    if (!category) return [];

    if (category.enableSearch && filteredResults.length > 0) return filteredResults;

    return category.options || [];
  }, [getCurrentCategory, filteredResults]);

  const isOptionSelected = (option) =>
    (selectedFilters[selectedCategory] || []).some((f) => f.id === option.id);

  const getSelectedText = () => {
    const total = getTotalSelectedCount();
    return total === 0 ? (
      placeHolder
    ) : (
      <>
        <span>Filters</span>
        <span className="filter-count">{total}</span>
      </>
    );
  };

  const renderFilterMenu = () => {
    const currentOptions = getCurrentCategoryOptions();

    return (
      <div className={classNames("multi-level-selector-menu")}>
        {/* Categories */}
        <div className="filter-categories">
          <div>
            {filterCategories.map((cat) => {
              const count = getCategorySelectedCount(cat.id);
              const isActive = selectedCategory === cat.id;
              return (
                <div
                  key={cat.id}
                  className={classNames("filter-category", { selected: isActive })}
                  onClick={() => handleCategorySelect(cat.id)}
                >
                  <span>{cat.label}</span>
                  {count > 0 && <span className="category-count-badge">{count}</span>}
                </div>
              );
            })}
          </div>
          {getTotalSelectedCount() > 0 && (
            <div className="filter-categories-reset-all-button">
              <BaseButton
                buttonText="Reset Filters"
                buttonType="secondary"
                onClick={handleResetAll}
              />
            </div>
          )}
        </div>

        <div className="filter-options-separator" />

        {/* Options */}
        <div className="filter-options">
          {isCurrentCategorySearchEnabled() && (
            <div className="filter-search-container">
              <TextInput
                placeholder={getCurrentCategory()?.searchPlaceholder || "Search..."}
                value={searchQuery}
                onChange={(e) => handleSearchQueryChange(e.target.value)}
                onSearchClear={() => handleSearchQueryChange("")}
                className="filter-search-input"
                loading={isSearching}
              />
            </div>
          )}
          <div className="filter-options-content">
            {currentOptions.length > 0
              ? currentOptions.map((option) => (
                  <div
                    key={option.id}
                    className="filter-option-item"
                    onClick={() => handleOptionToggle(selectedCategory, option)}
                  >
                    <div
                      className={classNames("filter-option", {
                        selected: isOptionSelected(option),
                        onlylabel: !option.address,
                      })}
                    >
                      <div className="filter-option-icon">
                        {isOptionSelected(option) ? <CheckboxSelectedIcon /> : <CheckboxIcon />}
                      </div>
                      <div className="filter-option-content">
                        <div className="filter-option-label">{option.label}</div>
                        {option.address && (
                          <div className="filter-option-address">{option.address}</div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              : isCurrentCategorySearchEnabled() &&
                searchQuery.trim() &&
                !isSearching && (
                  <div className="no-search-results">
                    <span>No results found for &quot;{searchQuery}&quot;</span>
                  </div>
                )}
          </div>

          {showActionButtons && getCategorySelectedCount(selectedCategory) > 0 && (
            <div className="filter-actions">
              <BaseButton
                buttonText="Clear Selected"
                buttonType="secondary"
                onClick={handleClearSelected}
              />
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <FormGroup
      className={classNames("multi-level-selector-container", className)}
      disabled={disabled}
      style={{ position: "relative" }}
    >
      <PopoverNext
        {...popoverPropsToNextProps({
          popoverClassName: "multi-level-selector-popover",
          usePortal,
          disabled,
          position: Position.BOTTOM_LEFT,
          minimal: true,
          content: renderFilterMenu(),
          modifiers: {
            offset: { enabled: true, options: { offset: [0, 0] } },
            preventOverflow: { enabled: false },
            flip: { enabled: false },
            computeStyle: {
              enabled: true,
              options: { gpuAcceleration: false },
            },
          },
        })}
      >
        <BaseButton
          iconName="ChevronDownIcon"
          iconPos={ICON_POS.RIGHT}
          buttonText={getSelectedText()}
          count={getTotalSelectedCount()}
          buttonType={BUTTON_TYPE.DEFAULT}
          disabled={disabled}
          className={classNames("multi-level-selector-button", {
            filterCount: getTotalSelectedCount() > 0,
          })}
        />
      </PopoverNext>
    </FormGroup>
  );
};

MultiLevelSelector.propTypes = {
  filterCategories: PropTypes.array.isRequired,
  selectedFilters: PropTypes.object,
  onFilterChange: PropTypes.func.isRequired,
  onResetAll: PropTypes.func,
  onClearSelected: PropTypes.func,
  placeHolder: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  usePortal: PropTypes.bool,
  defaultIsOpen: PropTypes.bool,
  className: PropTypes.string,
  showActionButtons: PropTypes.bool,
  onSearch: PropTypes.func,
  selectedCategory: PropTypes.string,
  searchQuery: PropTypes.string,
  filteredResults: PropTypes.array,
  isSearching: PropTypes.bool,
  onCategorySelect: PropTypes.func,
  onSearchQueryChange: PropTypes.func,
  onOptionToggle: PropTypes.func,
};

export default MultiLevelSelector;
