import classNames from "classnames";
import { ChevronLeftIcon, ChevronRightIcon } from "../assets/icon";

const LEFT_PAGE = "LEFT";
const RIGHT_PAGE = "RIGHT";

const findPageToJump = (page, currentPage, neighbours) => {
  if (page === LEFT_PAGE) return currentPage - neighbours * 2 - 1;
  else if (page === RIGHT_PAGE) return currentPage + neighbours * 2 + 1;
  else return page;
};

const createRange = (from, to, step = 1) => {
  let i = from;
  const range = [];
  while (i <= to) {
    range.push(i);
    i += step;
  }
  return range;
};

const generatePageNumbers = ({ totalRecords, pageSize, pageNeighbours, currentPage }) => {
  const totalPages = Math.ceil(totalRecords / pageSize);
  const totalNumbers = pageNeighbours * 2 + 3;
  const totalBlocks = totalNumbers + 2;

  if (totalPages > totalBlocks) {
    let pages = [];
    const leftBound = currentPage - pageNeighbours;
    const rightBound = currentPage + pageNeighbours;
    const beforeLastPage = totalPages - 1;
    const startPage = leftBound > 2 ? leftBound : 2;
    const endPage = rightBound < beforeLastPage ? rightBound : beforeLastPage;
    pages = createRange(startPage, endPage);

    const pagesCount = pages.length;
    const singleSpillOffset = totalNumbers - pagesCount - 1;
    const leftSpill = startPage > 2;
    const rightSpill = endPage < beforeLastPage;
    const leftSpillPage = LEFT_PAGE;
    const rightSpillPage = RIGHT_PAGE;

    if (leftSpill && !rightSpill) {
      const extraPages = createRange(startPage - singleSpillOffset, startPage - 1);
      pages = [leftSpillPage, ...extraPages, ...pages];
    } else if (!leftSpill && rightSpill) {
      const extraPages = createRange(endPage + 1, endPage + singleSpillOffset);
      pages = [...pages, ...extraPages, rightSpillPage];
    } else if (leftSpill && rightSpill) {
      pages = [leftSpillPage, ...pages, rightSpillPage];
    }

    return [1, ...pages, totalPages];
  }

  return createRange(1, totalPages);
};

export default function TablePagination({
  pageNeighbours = 1,
  pageSize = 10,
  jumpOnMore = false,
  simplePagination = false,
  hasMoreData = false,
  currentPage,
  totalRecords,
  onPageChange,
}) {
  const gotoPage = (page) => {
    const noOfPages = Math.ceil(totalRecords / pageSize);
    const currentPage = Math.max(0, Math.min(page, noOfPages));
    onPageChange(simplePagination ? page : currentPage);
  };

  const renderPages = () => {
    if (simplePagination) {
      return [
        <li
          key="simplePagination"
          onClick={() => null}
          className={classNames("wb-pagination-item simple-item", {
            "wb-pagination-active": simplePagination,
          })}
        >
          <span className="wb-pagination-link">{currentPage}</span>
        </li>,
      ];
    }
    return generatePageNumbers({ totalRecords, pageSize, pageNeighbours, currentPage }).map(
      (page, index) => {
        const handleJump = () => gotoPage(findPageToJump(page, currentPage, pageNeighbours));

        if (page === LEFT_PAGE || page === RIGHT_PAGE)
          return (
            <li
              key={index}
              onClick={jumpOnMore ? handleJump : undefined}
              className={classNames("wb-pagination-item", {
                "wb-pagination-no-jump": !jumpOnMore,
              })}
            >
              <span>...</span>
            </li>
          );

        return (
          <li
            onClick={handleJump}
            key={index}
            className={classNames("wb-pagination-item", {
              "wb-pagination-active": currentPage === page,
            })}
          >
            <span className="wb-pagination-link">{simplePagination ? currentPage : page}</span>
          </li>
        );
      },
    );
  };

  const handlePageNext = () => {
    const totalPages = Math.ceil(totalRecords / pageSize) || 0;
    const enableRight = !simplePagination ? currentPage < totalPages : hasMoreData;

    if (!enableRight) return null;

    gotoPage(currentPage + 1);
  };

  const handlePagePrevious = () => {
    const enableLeft = currentPage > 1;

    if (!enableLeft) return null;

    gotoPage(currentPage - 1);
  };

  const totalPages = Math.ceil(totalRecords / pageSize);

  if (!totalRecords && !simplePagination) return null;
  if (totalPages <= 0 && !simplePagination) return null;

  const enableLeft = currentPage > 1;
  const enableRight = !simplePagination ? currentPage < totalPages : hasMoreData;
  return (
    <div className="wb-pagination-container">
      <ul className="wb-pagination-list">
        <li
          key="left"
          onClick={handlePagePrevious}
          data-e2e-id="left"
          className={classNames("wb-pagination-item", "wb-pagination-nextPrevControl", {
            "wb-pagination-disabled": !enableLeft,
          })}
        >
          <ChevronLeftIcon className="wb-pagination-icon" />
        </li>
        {renderPages()}
        <li
          key="right"
          data-e2e-id="right"
          onClick={handlePageNext}
          className={classNames("wb-pagination-item", "wb-pagination-nextPrevControl", {
            "wb-pagination-disabled": !enableRight,
          })}
        >
          <ChevronRightIcon className="wb-pagination-icon" />
        </li>
      </ul>
    </div>
  );
}
