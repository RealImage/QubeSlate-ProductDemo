import { useCallback } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import MultiSelectInput from "../MultiSelectInput";
import InputRadio from "../InputRadio";
import Tag from "../Tag";
import Checkbox from "../Checkbox";

const RadioWithSearchFilterSection = ({
  containerClassName = "",
  selected = [],
  onFilterChange,
  radioOptions = [],
  selectedRadioValue = "",
  onRadioChange = () => {},
  selectedLabelPrefix = "",
  ...rest
}) => {
  const getSelectedLabel = useCallback(() => {
    if (selectedLabelPrefix) {
      return `${selectedLabelPrefix} - ${selected.length}`;
    }
    const activeOption = radioOptions.find((opt) => opt.value === selectedRadioValue);
    const label = activeOption ? activeOption.label : "";
    if (label.toLowerCase() === "include") {
      return `Including Countries - ${selected.length}`;
    } else if (label.toLowerCase() === "exclude") {
      return `Excluding Countries - ${selected.length}`;
    }
    return `${label} - ${selected.length}`;
  }, [selectedLabelPrefix, selected, radioOptions, selectedRadioValue]);

  const renderItemWithCheckbox = useCallback(
    (item, itemProps) => {
      const selectedIds = selected.map((s) => s.id);
      const isSelected = selectedIds.includes(item.id);

      return (
        <div
          key={item.id}
          className={classNames("radioWithSearch__menuItem", {
            selected: isSelected,
            active: itemProps.modifiers.active,
          })}
          onClick={itemProps.handleClick}
        >
          <Checkbox checked={isSelected} label={item.displayName || item.name} />
        </div>
      );
    },
    [selected],
  );

  return (
    <div className={classNames("radioWithSearch", containerClassName)}>
      {radioOptions && radioOptions.length > 0 && (
        <div className="radioWithSearch__radioGroup">
          {radioOptions.map((option) => (
            <InputRadio
              key={option.value}
              label={option.label}
              radioProps={{
                name: option.name || "radioFilter",
                value: option.value,
                checked: selectedRadioValue === option.value,
                onChange: () => onRadioChange(option.value),
              }}
            />
          ))}
        </div>
      )}
      <MultiSelectInput
        selectedItems={selected}
        onMenuItemSelect={onFilterChange}
        itemRenderer={renderItemWithCheckbox}
        resetOnSelect={false}
        {...rest}
      />
      {selected.length > 0 && (
        <div className="radioWithSearch__selectedSection">
          <div className="radioWithSearch__selectedHeader">
            <span className="radioWithSearch__selectedLabel">{getSelectedLabel()}</span>
            {/* <span className="radioWithSearch__clearAll" onClick={onFilterClear}>
              {clearAllText}
            </span> */}
          </div>
          <div className="radioWithSearch__tags">
            {selected.map((tag) => (
              <Tag
                key={tag.id}
                color="secondary"
                size="lg"
                closeIcon
                onClose={() => onFilterChange(tag)}
              >
                {tag.displayName}
              </Tag>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

RadioWithSearchFilterSection.propTypes = {
  containerClassName: PropTypes.string,
  selected: PropTypes.array,
  onFilterChange: PropTypes.func.isRequired,
  radioOptions: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
      name: PropTypes.string,
    }),
  ),
  selectedRadioValue: PropTypes.string,
  onRadioChange: PropTypes.func,
  selectedLabelPrefix: PropTypes.string,
};

export default RadioWithSearchFilterSection;
