import { PureComponent } from "react";
import omit from "lodash/omit";
import classNames from "classnames";
import PropTypes from "prop-types";
import { Menu, PopoverNext, Position, popoverPropsToNextProps } from "@blueprintjs/core";
import TooltipButton from "./TooltipButton";
import MenuItem from "./MenuItem";

/**
 * Component for Icon Menu with its dropdown.
 *
 * @component
 * @example
 * const iconList = [
 *    {
 *      id: "info",
 *      toolTip: "Info",
 *      iconName: "InfoFilledIcon",
 *      onClick: "function"
 *    },
 *    {
 *      id: "more",
 *      toolTip: "More",
 *      iconName: "MoreVerticalIcon",
 *      onClick: function,
 *      dropdown: [
 *         {
 *          text: "Pause",
 *          onClick: @function,
 *          hideMenuItem: false,
 *          iconName: "PauseIcon"
 *         },
 *         {
 *          customContent: <div><strong>Advanced</strong> <em>Option</em></div>,
 *          onClick: @function,
 *          hideMenuItem: false
 *         }
 *      ]
 *    },
 * ]
 *
 * return (
 *   <ActionMenu iconList={iconList} />
 * )
 *
 */

class ActionMenu extends PureComponent {
  renderMenuItem = (item, key) => {
    const { customContent, ...rest } = item;
    const props = omit(rest, ["hideMenuItem"]);

    if (customContent) {
      return (
        <div key={key} className={classNames("bp3-menu-item dropdownMenuItem")} {...props}>
          {customContent}
        </div>
      );
    }

    return <MenuItem key={key} className="dropdownMenuItem" {...props} />;
  };

  renderActionMenu = () => {
    const { iconList, popOverProps, minimal } = this.props;

    return iconList.map(({ dropdown, ...rest }, index) => {
      const toolTipPosition = index === iconList.length - 1 ? Position.TOP_RIGHT : Position.TOP;

      if (dropdown && dropdown.length > 0) {
        return (
          <div className={classNames("actionMenuPopoverContainer", { minimal })} key={index}>
            <PopoverNext
              {...popoverPropsToNextProps({
                portalClassName: classNames("actionMenuPortal", { minimal }),
                className: "actionMenuPopoverList",
                content: (
                  <Menu className="dropdownMenu">
                    {dropdown
                      .filter((menu) => !menu.hideMenuItem)
                      .map((item, key) => this.renderMenuItem(item, key))}
                  </Menu>
                ),
                ...popOverProps,
                minimal: true,
                position: Position.BOTTOM_RIGHT,
              })}
            >
              <TooltipButton toolTipPosition={toolTipPosition} {...rest} />
            </PopoverNext>
          </div>
        );
      }

      return (
        <TooltipButton
          key={index}
          /**
           * Adjust Tooltip position if it is the last icon in the cell
           */
          toolTipPosition={toolTipPosition}
          {...rest}
        />
      );
    });
  };

  render() {
    return (
      <div
        className={classNames("flex flex-auto justify-center actionMenuWrapper")}
        onClick={(e) => e.stopPropagation()}
      >
        {this.renderActionMenu()}
      </div>
    );
  }
}

ActionMenu.propTypes = {
  /**
   *  Array of Icons having support with dropdown
   */
  iconList: PropTypes.arrayOf(
    PropTypes.shape({
      /**
       *  Text to be displayed in Tooltip Popover
       */
      toolTip: PropTypes.string,
      onClick: PropTypes.func,
      className: PropTypes.string,
      /**
       *  Icons available in prefab repository can be used
       */
      iconName: PropTypes.string,
      /**
       *  Each Action icon can have a dropdown
       *  Menu Item Mimics the Blueprint Menu Item
       */
      dropdown: PropTypes.arrayOf(
        PropTypes.shape({
          text: PropTypes.string,
          /**
           *  Optional custom React content to render instead of text
           *  When provided, takes precedence over text prop
           */
          customContent: PropTypes.node,
          onClick: PropTypes.func,
          className: PropTypes.string,
          /**
           *  helps in hiding the Menu Item
           *  Menu Item Mimics the Blueprint Menu Item
           */
          hideMenuItem: PropTypes.bool,
          iconName: PropTypes.string,
        }),
      ),
    }),
  ).isRequired,
};

export default ActionMenu;
