import { useState, useEffect, useRef, useCallback } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import FooterV2 from "./v2/FooterV2";
import NavMenuItemV2 from "./v2/NavMenuItemV2";
import NavMenuAccordionV2 from "./v2/NavMenuAccordionV2";

/**
 * @typedef {Object} FooterProps
 * @property {boolean} [withUserInitial] // Whether to show user initials in profile.
 * @property {boolean} [withSupportMenu] // Whether to show the support menu.
 * @property {string} [companyName] // Company name to display in footer/profile.
 * @property {string} [userName] // User name to display in footer/profile.
 * @property {string} [supportButtonText] // Text for the support button.
 * @property {string} [infoButtonText] // Text for the info button.
 * @property {Array<Object>} [infoLinks] // List of info/help links to display in footer.
 * @property {Array<Object>} [footerMenuList] // List of menu items for 3dot menu.
 * @property {Object} [footerInfoPopupOffset] // Offset for the info popup position.
 * @property {string} [footerInfoPopupOffset.whenCollapsedXY] // Offset when collapsed (e.g. "-36, 2").
 * @property {string} [footerInfoPopupOffset.whenOpenXY] // Offset when expanded (e.g. "20, 2").
 */

/**
 * @typedef {Object} Logo
 * @property {React.ReactElement} [logoExpanded] - Logo to display when expanded.
 * @property {React.ReactElement} [logoSmall] - Logo to display when collapsed.
 */

/**
 * NavigationBarV2 component for rendering a navigation sidebar with menu items, accordions, and footer.
 *
 * @component
 * @param {Object} props
 * @param {FooterProps} [props.footerProps] - Footer properties including user info, support menu, and info links.
 * @param {Logo} props.logo - Logo properties for expanded and collapsed states.
 * @param {Object} props.location - Current location object (pathname, search, match).
 * @param {string} props.homeRoute - Route to navigate to on logo click.
 * @param {boolean} props.isExpanded - Whether the sidebar is expanded.
 * @param {boolean} props.isHovered - Whether the sidebar is hovered.
 * @param {Function} props.handlePinned - Callback for pin/unpin action.
 * @param {Function} props.handleExpand - Callback for expand/collapse action.
 * @param {boolean} props.hasNoAccess - If true, renders minimal nav for no access.
 * @param {Object} [props.classNames] - Custom class names for styling.
 * @param {Array} [props.menuItemList] - List of menu items and accordions.
 * @param {Object} [props.history] - History object for navigation.
 * @param {Function} [props.onSupportMenuClick] - Callback for support/help button.
 * @param {Object} [props.styles] - Inline styles for container.
 * @param {Function} [props.onCollapsedItemClick] - Callback for collapsed item click.
 * @param {boolean} [props.isMobile] - Whether in mobile view.
 * @returns {React.ReactElement}
 *
 */
function NavigationBarV2(props) {
  const {
    location,
    logo: { logoExpanded = null, logoSmall = null },
    homeRoute,
    isExpanded,
    isHovered,
    handlePinned,
    handleExpand,
    hasNoAccess = false,
    classNames: classNamesProp = {},
    menuItemList,
    history,
    styles,
    onCollapsedItemClick = null,
    onSupportMenuClick,
    isMobile,
    footerProps,
  } = props;

  const [openAccordion, setOpenAccordion] = useState(null);
  const activeAccordionRef = useRef(null);
  const [manuallyToggleActiveAccordion, setManuallyToggleActiveAccordion] = useState(null);

  const isMenuActive = useCallback(
    (paths) => {
      if (!Array.isArray(paths) || !location?.pathname) return false;

      const currentPath = location.pathname.replace(/\/+$/, "");
      const currentSegments = currentPath.split("/").filter(Boolean);

      return paths.some((path) => {
        if (!path) return false;

        const normalizedPath = path.replace(/\/+$/, "");
        if (normalizedPath === currentPath) return true;

        const pathSegments = normalizedPath.split("/").filter(Boolean);

        const isPrefixMatch = pathSegments.every((segment, index) => {
          return segment === currentSegments[index];
        });

        return isPrefixMatch;
      });
    },
    [location],
  );

  // Find the index of accordion that has an active submenu
  const getActiveAccordionIndex = useCallback(() => {
    if (!menuItemList) return -1;

    return (
      menuItemList.findIndex((menuItem) => {
        const isAccordion = menuItem?.type === "navMenuAccordion";
        const hasSubMenu = Array.isArray(menuItem.menuList);
        if (!isAccordion || !hasSubMenu) return false;

        // Check if any submenu item's route is active
        return menuItem.menuList.some((subItem) => {
          const routes = Array.isArray(subItem.route) ? subItem.route : [subItem.route];

          return isMenuActive(routes);
        });
      }) ?? -1 // no active accordion
    );
  }, [menuItemList, isMenuActive]);

  useEffect(() => {
    if (!isExpanded || isHovered) return; // navbar not pinned or is hovered

    const activeAccordionIndex = getActiveAccordionIndex();
    if (activeAccordionIndex !== -1) {
      activeAccordionRef.current = activeAccordionIndex;

      if (isExpanded && activeAccordionIndex !== openAccordion) {
        setOpenAccordion(activeAccordionIndex);
      }

      // Reset manually closed status when navigation changes to a new active accordion
      if (manuallyToggleActiveAccordion === activeAccordionIndex) {
        setManuallyToggleActiveAccordion(null);
      }
    } else {
      activeAccordionRef.current = null;
    }
    // eslint-disable-next-line
  }, [location.pathname, isExpanded, isHovered]);

  // Reset states
  useEffect(() => {
    if (!isExpanded && !isHovered) {
      const timeout = setTimeout(() => {
        setOpenAccordion(null);
      }, 250); // transition duration
      return () => clearTimeout(timeout);
    }
  }, [isExpanded, isHovered]);

  const handleAccordionToggle = (key) => {
    const isActiveAccordion = key === activeAccordionRef.current;

    // 1. Handle fully collapsed sidebar
    if (!isHovered && !isExpanded) {
      handleExpand(true);
      setOpenAccordion(key);
      return;
    }

    // 2. Hovered mode, open accordion when clicked
    if (isHovered) {
      setOpenAccordion((prev) => (prev === key ? null : key));
      return;
    }

    // 3. Expanded mode
    if (isActiveAccordion) {
      setManuallyToggleActiveAccordion((prev) => (prev === key ? null : key));
      return;
    }

    setOpenAccordion((prevOpen) => (prevOpen === key ? null : key));
  };

  const isAccordionOpen = (key) => {
    if (!isExpanded) return key === openAccordion;

    const isActive = key === activeAccordionRef.current;
    const isManuallyClosed = manuallyToggleActiveAccordion === key;

    if (isActive) return !isManuallyClosed;

    return key === openAccordion;
  };

  const handleLogoEvent = () => {
    handleExpand(false);
    history.push(homeRoute);
  };

  if (hasNoAccess) {
    const { navHeader = null, navContainer = null } = classNamesProp;
    return (
      <div
        className={classNames("flex flex-column clearfix relative", "navContainer", navContainer)}
        style={{ height: "100vh" }}
      >
        <div className={classNames("flex", "navHeader", navHeader)}>
          <div>{logoSmall}</div>
        </div>
      </div>
    );
  }

  // Navigation Bar
  const {
    navMenuWrapper = null,
    navHeader = null,
    expandedNavContainer = null,
    navContainer = null,
  } = classNamesProp;
  const isExpandedNav = isExpanded || isHovered;

  return (
    <div
      className={classNames(
        "flex flex-column clearfix relative",
        "navigationBarContainer_v2",
        navContainer,
        {
          expandedNavContainer: isExpandedNav,
          [expandedNavContainer]: isExpandedNav,
        },
      )}
      style={{ height: "100vh", ...styles }}
    >
      <div
        onClick={() => handleExpand(false)}
        className={classNames("flex", "navHeader", navHeader)}
      >
        <div onClick={handleLogoEvent}>{isExpandedNav ? logoExpanded : logoSmall}</div>
      </div>
      <div className={classNames("flex", "navigationBarWrapper", navMenuWrapper)}>
        {menuItemList?.map((menuItem, key) => {
          if (menuItem?.type === "navMenuAccordion") {
            return (
              <NavMenuAccordionV2
                key={key}
                menu={menuItem}
                isExpanded={isExpandedNav}
                validateActiveRoute={isMenuActive}
                classNames={classNamesProp}
                onHeaderClickWhenCollapsed={() => {
                  if (onCollapsedItemClick) onCollapsedItemClick();
                  handleAccordionToggle(key);
                }}
                isOpen={isAccordionOpen(key)}
                onToggle={() => handleAccordionToggle(key)}
                history={history}
                onItemClick={onCollapsedItemClick}
                isMobile={isMobile}
              />
            );
          }
          return (
            <NavMenuItemV2
              key={key}
              Icon={menuItem.Icon}
              name={menuItem.name}
              route={Array.isArray(menuItem.route) ? menuItem.route[0] : menuItem.route}
              isSelected={isMenuActive(
                Array.isArray(menuItem.route) ? menuItem.route : [menuItem.route],
              )}
              isExpanded={isExpandedNav}
              openNewTab={menuItem.openNewTab}
              menuId={menuItem.menuId}
              classNames={classNamesProp}
              onItemClick={() => {
                if (onCollapsedItemClick) onCollapsedItemClick();
              }}
              history={history}
              isMobile={isMobile}
              resetAccordion={() => setOpenAccordion(null)}
            />
          );
        })}
      </div>
      <FooterV2
        isExpanded={isExpandedNav}
        onSupportMenuClick={onSupportMenuClick}
        isPinned={isExpanded}
        onToggleButtonClick={() => handlePinned(!isExpanded)}
        onCollapsedItemClick={onCollapsedItemClick}
        history={history}
        classNames={classNamesProp}
        isMenuActive={isMenuActive}
        handlePinned={handlePinned}
        isMobile={isMobile}
        footerProps={footerProps}
      />
    </div>
  );
}

NavigationBarV2.propTypes = {
  location: PropTypes.object.isRequired,
  logo: PropTypes.shape({
    logoExpanded: PropTypes.element.isRequired,
    logoSmall: PropTypes.element.isRequired,
  }).isRequired,
  homeRoute: PropTypes.string.isRequired,
  isExpanded: PropTypes.bool.isRequired,
  isHovered: PropTypes.bool.isRequired,
  handlePinned: PropTypes.func.isRequired,
  handleExpand: PropTypes.func.isRequired,
  hasNoAccess: PropTypes.bool.isRequired,
  classNames: PropTypes.shape({
    navContainer: PropTypes.string,
    navHeader: PropTypes.string,
    expandedNavContainer: PropTypes.string,
    navMenuWrapper: PropTypes.string,
  }),
  onCollapsedItemClick: PropTypes.func,
  footerProps: PropTypes.shape({
    companyName: PropTypes.string,
    userName: PropTypes.string,
    infoLinks: PropTypes.arrayOf(PropTypes.object),
    footerMenuList: PropTypes.arrayOf(PropTypes.object),
    withUserInitial: PropTypes.bool,
    withSupportMenu: PropTypes.bool,
    supportButtonText: PropTypes.string,
    infoButtonText: PropTypes.string,
    footerInfoPopupOffset: PropTypes.shape({
      whenCollapsedXY: PropTypes.string,
      whenOpenXY: PropTypes.string,
    }),
  }),
};

export default NavigationBarV2;
