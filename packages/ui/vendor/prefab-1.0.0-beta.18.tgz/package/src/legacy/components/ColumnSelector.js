import { Component } from "react";
import PropTypes from "prop-types";
import findIndex from "lodash/findIndex";
import RightPanel from "./RightPanel";
import Checkbox from "./Checkbox";

const placeholder = document.createElement("div");
placeholder.className = "columnselector_placeholder";

/**
 * Component to customize the Table columns and rearrange the positions
 * Drag and Drop is used for re-arranging columns
 *
 * @class ColumnSelector
 *
 * @example
 * <ColumnSelector
 *    selectedColumns={ARRAY}
 *    reorderedColumns={ARRAY}
 *    isOpen={BOOLEAN}
 *    columns={ARRAY}
 *    onClose={FUNCTION}
 *    cancelEdit={FUNCTION}
 *    onHandleApply={FUNCTION}
 *    onItemSelect={FUNCTION}
 *    onColumnFilterSelect={FUNCTION}
 * />
 *
 */

class ColumnSelector extends Component {
  state = {
    selectedColumnList: this.props.selectedColumns ? this.props.selectedColumns.slice() : [],
    list:
      this.props.reorderedColumns.length > 0
        ? this.props.reorderedColumns.map((c) => this.props.columns.find((col) => col === c))
        : this.props.columns
          ? this.props.columns.slice()
          : [],
  };

  findSelectedIndex = (list, item) => {
    if (list.length === 0) return -1;
    if (item.id) return findIndex(list, item);
    return list.indexOf(item);
  };

  onItemSelect(item) {
    const { selectedColumnList } = this.state;
    const selected = selectedColumnList;
    const selectedIndex = this.findSelectedIndex(selected, item);
    if (selectedIndex > -1) {
      selected.splice(selectedIndex, 1);
    } else {
      selected.push(item);
    }
    this.setState({ selectedColumnList: selected });
  }

  cancelEdit = () => {
    const { cancelEdit, selectedColumns } = this.props;
    cancelEdit();
    this.setState({ selectedColumnList: [...selectedColumns] });
  };

  onHandleApply = () => {
    const { onColumnFilterSelect, onHandleApply } = this.props;
    const { list, selectedColumnList } = this.state;
    onHandleApply();
    onColumnFilterSelect(
      list.filter((c) => selectedColumnList.includes(c.Header)).map((c) => c.Header),
      list.map((c) => c.Header),
    );
  };

  dragStart = (e) => {
    this.dragged = e.currentTarget;
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", this.dragged);
  };

  dragEnd = () => {
    this.dragged.style.display = "block";
    this.dragged.parentNode.removeChild(placeholder);
    const data = this.state.list;
    const from = Number(this.dragged.dataset.id);
    const to = Number(this.over.dataset.id);
    const element = data[from];
    data.splice(from, 1);
    data.splice(to, 0, element);
    this.setState({ list: data });
  };

  dragOver = (e) => {
    e.preventDefault();
    this.dragged.style.display = "block";
    this.dragged.setAttribute("style", "display: none !important");
    if (e.target.className === "columnselector_checkbox") {
      this.over = e.target;
      e.target.parentNode.insertBefore(placeholder, e.target);
    } else if (e.target.className === "columnselector_hideText") {
      this.over = e.target;
      e.target.parentNode.insertBefore(placeholder, e.target);
    }
  };

  render() {
    return (
      <RightPanel
        isOpen={this.props.isOpen}
        onClose={this.cancelEdit}
        header={this.props.header}
        showFooter
        isEdit
        primaryButtonProps={{
          buttonText: this.props.applyText,
          onClick: this.onHandleApply,
        }}
        secondaryButtonProps={{ buttonText: this.props.cancelText, onClick: this.cancelEdit }}
        showClearAll={typeof this.props.resetConfig === "object"}
        clearAllText={this.props.resetConfig?.text}
        onClickClearAll={this.props.resetConfig?.resetHandler}
      >
        <div onDragEnter={(e) => e.preventDefault()} onDragOver={this.dragOver}>
          {this.state.list
            .filter((c) => c.Header)
            .map((c) => c.Header)
            .map((item, i) => (
              <div
                data-id={i}
                key={i}
                className="columnselector_checkbox"
                draggable="true"
                onDragStart={this.dragStart}
                onDragEnd={this.dragEnd}
              >
                <Checkbox
                  data-id={i}
                  key={i}
                  label={item}
                  checked={this.state.selectedColumnList.includes(item) ? true : false}
                  onChange={() => this.onItemSelect(item)}
                  checkBoxRight={true}
                  DragDropIcon={true}
                />
              </div>
            ))}
          <div className={"columnselector_hideText"} data-id={this.state.list.length}>
            end
          </div>
        </div>
      </RightPanel>
    );
  }
}

ColumnSelector.propTypes = {
  /**
   * Controls the right pane open and close
   */
  isOpen: PropTypes.bool,
  /**
   * Header text for the right pane
   */
  header: PropTypes.string,
  /**
   * Text for the Apply button
   */
  applyText: PropTypes.string,
  /**
   * Text for the Cancel button
   */
  cancelText: PropTypes.string,
  /**
   * Array of table columns that are selected by default or as a props
   */
  selectedColumns: PropTypes.array,
  /**
   * Array of table columns that are reordered
   */
  reorderedColumns: PropTypes.array,
  /**
   * Array of total table columns that are available in the table
   */
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      Header: PropTypes.string,
      accessor: PropTypes.string,
    }),
  ),
  /**
   * Event handler invoked when to cancels the column changes.
   */
  cancelEdit: PropTypes.func,
  /**
   * Event handler invoked when selects or de-select the columns.
   * (selectedColumns, reorderedColumns) => any
   * The callback will have
   * @params {selectedColumns}
   * @params {reorderedColumns}
   */
  onColumnFilterSelect: PropTypes.func,
  /**
   * Event handler invoked to control the right pane state.
   */
  onHandleApply: PropTypes.func,
};

ColumnSelector.defaultProps = {
  header: "Edit Column",
  applyText: "Apply Changes",
  cancelText: "Cancel",
};

export default ColumnSelector;
