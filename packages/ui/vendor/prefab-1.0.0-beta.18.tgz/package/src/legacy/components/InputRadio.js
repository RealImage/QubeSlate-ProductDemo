/**
 *
 * @param {Object} props
 * @param {ReactNode} props.label - Label for the radio input
 * @param {ReactNode} props.children - Children to be passed as label, preferred over props.label
 * @param {HTMLInputElement} props.radioProps - Props for the radio input
 * @param {HTMLLabelElement} props.labelProps - Props for the label container
 * @param {HTMLSpanElement} props.spanProps - Props for the label container element
 * @returns
 */

const InputRadio = ({
  label,
  labelProps: { className: labelClass, ...restLabelProps } = {},
  radioProps,
  spanProps,
  children,
}) => {
  return (
    <label
      {...restLabelProps}
      className={`prefab-input-radio${labelClass ? ` ${labelClass}` : ""}`}
      htmlFor={undefined}
    >
      <span className="input">
        <input {...radioProps} type="radio" />
      </span>
      {(children || label) && (
        <span
          {...spanProps}
          onFocus={(e) => {
            if (spanProps?.onFocus) spanProps.onfocus(e);
            const inputRadio = e.currentTarget?.previousElementSibling?.firstElementChild || null;
            if (inputRadio) {
              inputRadio.click();
            }
            return true;
          }}
        >
          {children || label}
        </span>
      )}
    </label>
  );
};

export default InputRadio;
