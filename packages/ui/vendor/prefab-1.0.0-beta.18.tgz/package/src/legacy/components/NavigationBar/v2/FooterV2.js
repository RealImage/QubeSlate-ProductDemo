import { useState } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { PopoverNext, Menu, popoverPropsToNextProps } from "@blueprintjs/core";
import MenuItem from "../../MenuItem";
import ToolTip from "../../ToolTip";
import {
  SupportOutlineIcon,
  InfoOutlineIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from "../../../assets/icon";
import NavProfileV2 from "./NavProfileV2";

function FooterV2({
  isExpanded = false,
  isPinned = false,
  onToggleButtonClick = () => {},
  onSupportMenuClick = () => {},
  onCollapsedItemClick = null,
  classNames: classNamesProp = {},
  history = {},
  isMenuActive,
  handlePinned,
  footerProps: {
    withUserInitial = false,
    withSupportMenu = true,
    companyName = "",
    userName = "",
    supportButtonText = "Help",
    infoButtonText = "Info",
    infoLinks = [],
    footerMenuList = [],
    footerInfoPopupOffset = {},
  } = {},
}) {
  const [activePopover, setActivePopover] = useState(null); // 'info', 'ellipsis', null

  const {
    popMenuItemIcon = null,
    container = null,
    helpAction = null,
    infoAction = null,
    infoMenuContainer = null,
  } = classNamesProp;

  const { whenCollapsedXY = "-36, 2", whenOpenXY = "20, 2" } = footerInfoPopupOffset;

  // Info popover menu
  const infoMenu = (
    <Menu className={classNames("menu", "infoMenuContainer", infoMenuContainer)}>
      {infoLinks.map(({ Icon = null, ...link }, i) => (
        <a key={i} href={link.path} target="_blank" rel="noopener noreferrer">
          <MenuItem
            {...link}
            icon={Icon && <Icon className={classNames("menuItemIcon", popMenuItemIcon)} />}
            text={link.name}
            tagName="div"
            isIconRight={link.isIconRight ?? false}
            shouldDismissPopover={true}
          />
        </a>
      ))}
    </Menu>
  );

  const infoButton = (
    <ToolTip
      toolTip={infoButtonText}
      disabled={isExpanded}
      usePortal={true}
      toolTipPosition="right"
      popoverClassName="nav-tooltip-popover"
      minimal={true}
      modifiers={{
        offset: {
          enabled: true,
          offset: "0, 10",
        },
      }}
    >
      <button
        className={classNames(
          "footer_v2__action",
          "footer_v2__action--info",
          { "footer_v2__action--active": activePopover === "info" },
          infoAction,
        )}
        // onClick={!isExpanded ? onCollapsedItemClick : undefined}
        type="button"
      >
        <InfoOutlineIcon />
        {isExpanded && <span>{infoButtonText}</span>}
      </button>
    </ToolTip>
  );

  return (
    <div className={classNames("footer_v2 footer-v2-layout", container)}>
      <div className="footer_v2__top-section footer-v2-top-actions">
        {withSupportMenu && (
          <ToolTip
            toolTip={supportButtonText}
            disabled={isExpanded}
            usePortal={true}
            placement="right"
            popoverClassName="nav-tooltip-popover"
            minimal={true}
            modifiers={{
              offset: {
                enabled: true,
                offset: "0, 10",
              },
            }}
          >
            <button
              className={classNames("footer_v2__action", helpAction)}
              onClick={onSupportMenuClick}
              type="button"
            >
              <SupportOutlineIcon />
              {isExpanded && <span>{supportButtonText}</span>}
            </button>
          </ToolTip>
        )}
        {infoLinks.length > 0 && (
          <PopoverNext
            {...popoverPropsToNextProps({
              portalClassName: "popOver footerInfoPortalContainerV2",
              usePortal: true,
              content: infoLinks && infoMenu,
              position: !isExpanded ? "right" : "top",
              minimal: true,
              isOpen: activePopover === "info",
              onClose: () => setActivePopover(null),
              onInteraction: (state) => setActivePopover(state ? "info" : null),
              modifiers: {
                offset: {
                  enabled: true,
                  offset: !isExpanded ? whenCollapsedXY : whenOpenXY,
                },
              },
            })}
          >
            {infoButton}
          </PopoverNext>
        )}
      </div>
      <div className="navigationBar_v2__collapse-wrapper">
        <ToolTip
          key={isExpanded ? "Collapse" : "Expand"}
          toolTip={isExpanded ? "Collapse" : "Expand"}
          usePortal={true}
          placement="right"
          popoverClassName="nav-tooltip-popover chevron-collapse"
          minimal={true}
          modifiers={{
            offset: {
              enabled: true,
              offset: "0, 10",
            },
          }}
        >
          <button
            className="navigationBar_v2__collapse-button"
            onClick={() => handlePinned(!isExpanded)}
          >
            {isExpanded ? <ChevronLeftIcon /> : <ChevronRightIcon />}
          </button>
        </ToolTip>
      </div>
      <div className="footer_v2__divider" />
      <div className="footer_v2__account-section footer-v2-bottom-section">
        <NavProfileV2
          name={userName}
          companyName={companyName}
          isMenuActive={isMenuActive || (() => false)}
          withUserInitial={withUserInitial}
          isExpanded={isExpanded}
          menuList={footerMenuList}
          classNames={classNamesProp}
          onToggleButtonClick={onToggleButtonClick}
          isPinned={isPinned}
          history={history}
          onCollapsedItemClick={onCollapsedItemClick}
        />
      </div>
    </div>
  );
}

FooterV2.propTypes = {
  onCollapsedItemClick: PropTypes.func,
  userName: PropTypes.string,
  companyName: PropTypes.string,
  isExpanded: PropTypes.bool,
  isPinned: PropTypes.bool,
  onToggleButtonClick: PropTypes.func,
  onSupportMenuClick: PropTypes.func,
  infoLinks: PropTypes.arrayOf(PropTypes.object),
  infoButtonText: PropTypes.string,
  supportButtonText: PropTypes.string,
  withSupportMenu: PropTypes.bool,
  withUserInitial: PropTypes.bool,
  classNames: PropTypes.object,
  footerMenuList: PropTypes.arrayOf(PropTypes.object),
  history: PropTypes.object,
  footerInfoPopupOffset: PropTypes.shape({
    whenCollapsedXY: PropTypes.string,
    whenOpenXY: PropTypes.string,
  }),
};

export default FooterV2;
