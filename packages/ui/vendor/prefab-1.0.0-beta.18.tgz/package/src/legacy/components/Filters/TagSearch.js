import { Component } from "react";
import PropTypes from "prop-types";
import flattenDeep from "lodash/flattenDeep";
import compact from "lodash/compact";
import ApiSearch from "../ApiSearch";

class TagSearch extends Component {
  render() {
    const {
      placeholder,
      showSubText,
      resetOnSelect,
      searchIcon,
      onSelect,
      tagTypes,
      searchTags,
      ...restProps
    } = this.props;

    return (
      <ApiSearch
        placeholder={placeholder}
        onSelect={onSelect}
        fetchAction={(value) => searchTags(value, compact(flattenDeep([tagTypes])))}
        parseResults={(data) =>
          data.slice(0, 15).map((item) => ({
            ...item,
          }))
        }
        showSubText={showSubText}
        searchIcon={searchIcon}
        resetOnSelect={resetOnSelect}
        {...restProps}
      />
    );
  }
}

TagSearch.propTypes = {
  tagTypes: PropTypes.oneOfType([PropTypes.string, PropTypes.array]).isRequired,
  placeholder: PropTypes.string,
  onSelect: PropTypes.func.isRequired,
  searchIcon: PropTypes.oneOf(["left", "right", "none"]),
  showSubText: PropTypes.bool,
  resetOnSelect: PropTypes.bool,
};

TagSearch.defaultProps = {
  placeholder: "Search",
  searchIcon: "right",
  showSubText: true,
  resetOnSelect: true,
};

export default TagSearch;
