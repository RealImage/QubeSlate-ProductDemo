import PropTypes from "prop-types";
import classNames from "classnames";
import { Tooltip, Position } from "@blueprintjs/core";
import {
  StatusIcon as StatusIconSVG,
  MoviesIcon,
  DurationIcon,
  LogsIcon,
  CalendarIcon,
  AlertFilledIcon,
  ConfirmCircleIcon,
  ConfirmCircleFilledIcon,
  CirclePartiallyFilledV2Icon,
} from "../assets/icon.js";
import { STATUS_ICON_COLORS, STATUS_ICON_TYPES } from "../constants";

const getColorClassName = (color) => {
  switch (color) {
    case STATUS_ICON_COLORS.GREEN:
      return "green";
    case STATUS_ICON_COLORS.LIGHT_BLUE:
      return "lightBlue";
    case STATUS_ICON_COLORS.GREY:
      return "grey";
    case STATUS_ICON_COLORS.YELLOW:
      return "yellow";
    case STATUS_ICON_COLORS.RED:
      return "red";
    case STATUS_ICON_COLORS.PURPLE:
      return "purple";
    case STATUS_ICON_COLORS.LIGHT_GREY:
      return "lightGrey";
    case STATUS_ICON_COLORS.LIGHT_GREEN:
      return "lightGreen";
    case STATUS_ICON_COLORS.BLUE:
      return "blue";
    default:
      return "primary";
  }
};

const getStatusIconSVG = (type) => {
  switch (type) {
    case STATUS_ICON_TYPES.CIRCLE:
      return <StatusIconSVG />;
    case STATUS_ICON_TYPES.MOVIES:
      return <MoviesIcon />;
    case STATUS_ICON_TYPES.DURATION:
      return <DurationIcon />;
    case STATUS_ICON_TYPES.LOGS:
      return <LogsIcon />;
    case STATUS_ICON_TYPES.CALENDAR:
      return <CalendarIcon />;
    case STATUS_ICON_TYPES.ALERT:
      return <AlertFilledIcon />;
    case STATUS_ICON_TYPES.CONFIRM_CIRCLE:
      return <ConfirmCircleIcon />;
    case STATUS_ICON_TYPES.CONFIRM_CIRCLE_FILLED:
      return <ConfirmCircleFilledIcon />;
    case STATUS_ICON_TYPES.CIRCLE_PARTIALLY_FILLED_ICON:
      return <CirclePartiallyFilledV2Icon />;
    default:
      return;
  }
};

const StatusIcon = ({
  color = "",
  type = STATUS_ICON_TYPES.CIRCLE,
  showToolTip = false,
  toolTip = "",
  toolTipPosition = Position.TOP,
  toolTipClass = "",
}) => {
  const isHexColor = color && typeof color === "string" && color.startsWith("#");
  const colorClass = isHexColor ? "" : getColorClassName(color);
  const iconStyle = isHexColor ? { color } : {};
  const svgElement = getStatusIconSVG(type);

  if (!showToolTip)
    return (
      <div className={`statusIconContainer icon ${colorClass} iconContainer`} style={iconStyle}>
        {svgElement}
      </div>
    );
  return (
    <Tooltip
      className={classNames(toolTipClass)}
      position={toolTipPosition}
      content={<span>{toolTip}</span>}
      usePortal={false}
    >
      <div className={`statusIconContainer icon ${colorClass}`} style={iconStyle}>
        {svgElement}
      </div>
    </Tooltip>
  );
};

StatusIcon.propTypes = {
  color: PropTypes.oneOfType([
    PropTypes.oneOf([...Object.values(STATUS_ICON_COLORS), ""]),
    PropTypes.string,
  ]),
  type: PropTypes.oneOf(Object.values(STATUS_ICON_TYPES)),
  showToolTip: PropTypes.bool,
  toolTip: PropTypes.string,
};

export default StatusIcon;
