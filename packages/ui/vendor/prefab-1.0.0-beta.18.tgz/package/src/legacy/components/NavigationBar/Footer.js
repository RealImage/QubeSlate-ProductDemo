import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { PopoverNext, Position, Menu, popoverPropsToNextProps } from "@blueprintjs/core";
import * as Icons from "../../assets/icon.js";
import MenuItem from "../MenuItem";
import NavProfile from "./NavProfile";

const { InfoFilledIcon, SupportIcon } = Icons;

/**
 * Component for Navigation bar to have profile menu, help and info actions.
 *
 * @component <Footer />
 *
 * @example
 *
 * return (
 *   <Footer 
 *      name={String}
        companyName={String}
        isMenuActive={Boolean}
        isExpanded={Boolean}
        isPinned={Boolean}
        menuList={Array}
        infoLinks={Array}
        onToggleButtonClick={Function}
      />
 * )
 *
 */

class Footer extends Component {
  renderMenu = () => {
    const { infoMenuContainer = null, popMenuItemIcon = null } = this.props.classNames;
    return (
      <Menu className={classNames("menu", "infoMenuContainer", infoMenuContainer)}>
        {this.props.infoLinks.map(({ Icon = null, ...link }, i) => (
          <a
            key={i}
            className="footerMenuLink"
            target="_blank"
            rel="noopener noreferrer"
            href={link.path}
          >
            <MenuItem
              {...link}
              icon={Icon && <Icon className={classNames("menuItemIcon", popMenuItemIcon)} />}
              text={<div className="popupMenuText">{link.name}</div>}
              tagName="div"
              isIconRight={link.isIconRight ?? false}
              shouldDismissPopover={true}
            />
          </a>
        ))}
      </Menu>
    );
  };

  render() {
    const {
      history,
      onToggleButtonClick,
      name,
      companyName,
      isExpanded,
      isPinned,
      onSupportMenuClick,
      infoLinks,
      infoButtonText,
      isMenuActive,
      menuList,
      withSupportMenu,
      supportButtonText,
      withUserInitial,
    } = this.props;

    const {
      container = null,
      profileContainer = null,
      actionWrapper = null,
      expandedActionWrapper = null,
      helpAction = null,
      infoAction = null,
    } = this.props.classNames;

    return (
      <div className={classNames("cursor navBarFooterContainer", container)}>
        <div className={classNames("cursor profile", profileContainer)}>
          <div className="flex align-center col-12 clearfix">
            <NavProfile
              name={name}
              companyName={companyName}
              isMenuActive={isMenuActive}
              withUserInitial={withUserInitial}
              isExpanded={isExpanded}
              menuList={menuList}
              classNames={this.props.classNames}
              onToggleButtonClick={onToggleButtonClick}
              isPinned={isPinned}
              history={history}
            />
          </div>
        </div>
        <div
          className={classNames(
            "footerActions",
            actionWrapper,
            isExpanded && "expandedFooterActions",
            isExpanded && expandedActionWrapper,
          )}
        >
          {withSupportMenu && (
            <div
              className={classNames("footerSupportMenu", helpAction)}
              onClick={onSupportMenuClick}
            >
              <SupportIcon />
              <span>{supportButtonText}</span>
            </div>
          )}
          {isExpanded && infoLinks.length > 0 && (
            <PopoverNext
              {...popoverPropsToNextProps({
                portalClassName: "popOver footerInfoPortalContainer",
                usePortal: true,
                onClose: () =>
                  this.setState({
                    isOpen: false,
                  }),
                content: infoLinks && this.renderMenu(),
                position: Position.TOP_RIGHT,
                minimal: true,
              })}
            >
              <div className={classNames("footerInfo", infoAction)}>
                <InfoFilledIcon />
                <span>{infoButtonText}</span>
              </div>
            </PopoverNext>
          )}
        </div>
      </div>
    );
  }
}

Footer.propTypes = {
  /**
   *  Boolean props to make footer aware of Navbar is expanded
   */
  isExpanded: PropTypes.bool.isRequired,
  /**
   *  Function to handle the event of pin and unpin
   */
  onToggleButtonClick: PropTypes.func.isRequired,
  /**
   *  Function to handle the event for support menu
   */
  onSupportMenuClick: PropTypes.func.isRequired,
  /**
   *  props to pass the user name
   */
  name: PropTypes.string.isRequired,
  /**
   *  props to pass the company name
   */
  companyName: PropTypes.string.isRequired,
  /**
   *  Boolean props to expand the nav bar
   */
  isPinned: PropTypes.bool.isRequired,
  /**
   *  Boolean props decide upon the visibility of support menu
   */
  withSupportMenu: PropTypes.bool,
  /**
   *  Array of objects to be shown on profile click
   */
  menuList: PropTypes.array,
  /**
   *  Array of objects that will be shown on hovering or clicking info button
   */
  infoLinks: PropTypes.array,
  /**
   *  List of classnames to add customization to component tree
   */
  classNames: PropTypes.shape({
    container: PropTypes.string,
    profileContainer: PropTypes.string,
    actionWrapper: PropTypes.string,
    expandedActionWrapper: PropTypes.string,
    helpAction: PropTypes.string,
    infoAction: PropTypes.string,
    infoMenuContainer: PropTypes.string,
    popMenuItemIcon: PropTypes.string,
  }),
};

Footer.defaultProps = {
  menuList: [],
  infoLinks: [],
  withSupportMenu: true,
  classNames: {},
  supportButtonText: "Help",
  infoButtonText: "Info",
};

export default Footer;
