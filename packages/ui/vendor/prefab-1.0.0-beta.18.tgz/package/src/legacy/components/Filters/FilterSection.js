import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import { FILTER_TAG_TYPES, BUTTON_TYPE, SIZE } from "../../constants";
import BaseButton from "../BaseButton";
import SearchFilterSection from "./SearchFilterSection";
import ListFilterSection from "./ListFilterSection";
import DateRangeFilterSection from "./DateRangeFilterSection";
import MultiSelectFilterSection from "./MultiSelectFilterSection";
import RadioWithSearchFilterSection from "./RadioWithSearchFilterSection";

class FilterSection extends Component {
  state = {
    isOpen: true,
  };

  toggle = () => this.setState({ isOpen: !this.state.isOpen });

  renderTagSelector = () => {
    const { filterType } = this.props;
    switch (filterType) {
      case FILTER_TAG_TYPES.LIST:
        return <ListFilterSection {...this.props} />;
      case FILTER_TAG_TYPES.DATE_RANGE:
        return <DateRangeFilterSection {...this.props} />;
      case FILTER_TAG_TYPES.MULTI_SELECT_SEARCH:
        return <MultiSelectFilterSection {...this.props} />;
      case FILTER_TAG_TYPES.RADIO_WITH_SEARCH:
        return <RadioWithSearchFilterSection {...this.props} />;
      case FILTER_TAG_TYPES.SEARCH:
      default:
        return <SearchFilterSection {...this.props} />;
    }
  };

  render() {
    let { header } = this.props;
    const { selected, onFilterClear, clearText = "Clear" } = this.props;
    const { isOpen } = this.state;

    const iconProps = {
      onClick: this.toggle,
      buttonSize: SIZE.REGULAR,
      iconSize: 24,
      buttonType: BUTTON_TYPE.SECONDARY,
      className: "expandButton",
    };

    if (selected.length > 0) header += ` (${selected.length})`;

    return (
      <div className={classNames("filerSectionContainer", "bordered")}>
        <div className="filterSectionLabel">
          <span className="heading">{header}</span>
          <span className="flex-auto" />
          {selected.length > 0 ? (
            <span className="clear" onClick={onFilterClear}>
              {clearText}
            </span>
          ) : null}
          <BaseButton iconName={isOpen ? "ChevronUpIcon" : "ChevronDownIcon"} {...iconProps} />
        </div>
        {isOpen && <div className="filterSectionSelector">{this.renderTagSelector()}</div>}
      </div>
    );
  }
}

FilterSection.propTypes = {
  filterType: PropTypes.string.isRequired,
  selected: PropTypes.array,
  onFilterChange: PropTypes.func.isRequired,
  onFilterClear: PropTypes.func.isRequired,
  clearText: PropTypes.string,
};

FilterSection.defaultProps = {
  selected: [],
};

export default FilterSection;
