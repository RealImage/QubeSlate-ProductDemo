import { useState } from "react";
import { ConfirmIcon, CopyIcon } from "../assets/icon";

/**
 *
 * @param {Object} props
 * @param {ReactNode | String} props.visibleValue - Value to be displayed. Only string type wil be used for title or copying, if valueToCopy is not provided
 * @param {ReactNode} props.valueToCopy - Value to be copied to clipboard, if not provided visibleValue will be copied
 * @param {Boolean} props.iconOnLeft - Icon position to be left or right, default is false
 * @param {ReactNode} props.children - Children to be displayed, will be preferred over visibleValue for display purpose only. Cannot be used to copy to clipboard.
 * @param {String} props.title - Title to be displayed on hover, if not provided visibleValue will be used
 * @param {String} props.className - Additional class to be added to the component
 * @returns
 */
const CopyToClipboard = ({
  visibleValue,
  valueToCopy,
  iconOnLeft = false,
  children,
  title,
  className,
}) => {
  const [dataCopied, setDataCopied] = useState(false);
  const copy = async () => {
    setDataCopied(true);
    await navigator.clipboard.writeText(valueToCopy || visibleValue);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setDataCopied(false);
  };

  return (
    <div className={"prefab-copy-to-clipboard".concat(className ? ` ${className}` : "")}>
      <button
        data-copied={dataCopied}
        title={typeof visibleValue === "string" ? visibleValue : title}
        onClick={copy}
        data-left_icon={iconOnLeft}
      >
        <div className="visible-value">{children || visibleValue}</div>{" "}
        <div className="icon">
          <ConfirmIcon className="tick-icon" />
          <CopyIcon className="copy-icon" />
        </div>
      </button>
    </div>
  );
};

export default CopyToClipboard;
