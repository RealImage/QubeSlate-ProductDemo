import PropTypes from "prop-types";
import classNames from "classnames";
import { CancelRoundedIcon } from "../assets/icon";

const colors = {
  default: "pf-tag-default",
  muted: "pf-tag-muted",
  positive: "pf-tag-positive",
  notice: "pf-tag-notice",
  negative: "pf-tag-negative",
  primary: "pf-tag-primary",
  secondary: "pf-tag-secondary",
  warning: "pf-tag-warning",
  constructive: "pf-tag-constructive",
  destructive: "pf-tag-destructive",
  violet: "pf-tag-violet",
  orange: "pf-tag-orange",
  invert: "pf-tag-invert",
};

const sizes = {
  sm: "pf-tag-sm",
  md: "pf-tag-md",
  lg: "pf-tag-lg",
};

/**
 * Tag Component
 *
 * @param {Object} props
 * @param {keyof typeof colors} props.color
 * @param {keyof typeof sizes} props.size
 * @param {React.ReactNode} props.prefixIcon
 * @param {boolean | React.ReactNode} props.closeIcon
 * @param {() => void} props.onClose
 * @param {string} props.className
 * @param {React.ReactNode} props.children
 *
 */
function Tag(props) {
  const {
    color = "default",
    size = "md",
    prefixIcon,
    closeIcon,
    className,
    onClose,
    children,
    ...rest
  } = props;

  return (
    <div className={classNames("pf-tag", colors[color], sizes[size], className)} {...rest}>
      {prefixIcon && <span className="pf-tag-prefix">{prefixIcon}</span>}
      <span className="pf-tag-text">{children}</span>
      {closeIcon && (
        <span onClick={onClose} className="pf-tag-close" role="button" tabIndex="0">
          {closeIcon && typeof closeIcon === "boolean" ? (
            <CancelRoundedIcon className="pf-tag-close-icon" />
          ) : (
            closeIcon
          )}
        </span>
      )}
    </div>
  );
}

Tag.propTypes = {
  color: PropTypes.string,
  size: PropTypes.string,
  onClose: PropTypes.func,
  className: PropTypes.string,
  closeIcon: PropTypes.oneOfType([PropTypes.bool, PropTypes.node]),
  prefixIcon: PropTypes.node,
  children: PropTypes.node,
};

export default Tag;
