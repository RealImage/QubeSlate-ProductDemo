import { Component } from "react";
import classNames from "classnames";
import { Tooltip, Position } from "@blueprintjs/core";
import PropTypes from "prop-types";

class ToolTip extends Component {
  static propTypes = {
    toolTip: PropTypes.oneOfType([PropTypes.node, PropTypes.element]),
    toolTipPosition: PropTypes.string,
    toolTipClass: PropTypes.string,
    usePortal: PropTypes.bool, // add usePortal prop
  };
  static defaultProps = {
    toolTipPosition: Position.TOP,
    toolTipClass: "",
    usePortal: false, // default to false for compatibility
  };
  render() {
    const { toolTip, toolTipPosition, toolTipClass, usePortal, ...restProps } = this.props;
    return (
      <Tooltip
        className={classNames("toolTipContainer", toolTipClass)}
        position={toolTipPosition}
        content={toolTip && toolTip}
        usePortal={usePortal}
        {...restProps}
      >
        {this.props.children}
      </Tooltip>
    );
  }
}

export default ToolTip;
