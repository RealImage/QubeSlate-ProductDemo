import { Component } from "react";
import PropTypes from "prop-types";
import { Tag } from "@blueprintjs/core";
import differenceBy from "lodash/differenceBy";
import classNames from "classnames";

class FilterChips extends Component {
  onRemove = (filters) => {
    const newSelected = differenceBy(this.props.selected, filters, "id");
    this.props.onFilterChange(newSelected);
  };

  renderFilters = () => {
    const { selected } = this.props;
    return selected.map((filter) => {
      if (filter.nonRemovable) {
        return (
          <Tag key={filter.id} className={classNames("primary", "chip")} minimal>
            {filter.type}: {filter.displayName}
          </Tag>
        );
      } else {
        return (
          <Tag
            key={filter.id}
            className={classNames("primary", "chip")}
            minimal
            onRemove={() => this.onRemove([filter])}
          >
            {filter.type}: {filter.displayName}
          </Tag>
        );
      }
    });
  };

  renderResultsCount = () => {
    const { showResultsCount, resultsCount, resultCountText } = this.props;
    if (!showResultsCount) return null;
    if (resultCountText) return <span className="resultsCount">{resultCountText}</span>;
    let r;
    if (resultsCount === 0) r = "No results for";
    else if (resultsCount === 1) r = `Showing ${resultsCount} result for`;
    else r = `Showing ${resultsCount} results for`;
    return <span className="resultsCount">{r}</span>;
  };

  render() {
    const { selected, loading, clearText } = this.props;
    if (!selected || selected.length === 0 || loading) {
      return null;
    }
    return (
      <div className="filterChips">
        {this.renderResultsCount()}
        {this.renderFilters()}
        {selected.filter((filterTag) => !filterTag.nonRemovable).length ? (
          <Tag
            key="CLEAR-ALL"
            minimal
            className={classNames("danger", "chip")}
            interactive
            onClick={() => this.onRemove(selected)}
          >
            {clearText}
          </Tag>
        ) : null}
      </div>
    );
  }
}

FilterChips.propTypes = {
  showResultsCount: PropTypes.bool,
  resultsCount: PropTypes.number,
  resultCountText: PropTypes.string,
  selected: PropTypes.array.isRequired,
  clearText: PropTypes.string.isRequired,
  onFilterChange: PropTypes.func.isRequired,
  loading: PropTypes.bool,
};

FilterChips.defaultProps = {
  showResultsCount: false,
  loading: false,
  clearText: "Clear All",
};

export default FilterChips;
