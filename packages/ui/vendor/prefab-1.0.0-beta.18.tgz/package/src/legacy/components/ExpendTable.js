import { PureComponent } from "react";
import classNames from "classnames";
import intersection from "lodash/intersection";
import xor from "lodash/xor";
import map from "lodash/map";
import difference from "lodash/difference";
import orderBy from "lodash/orderBy";
import isEmpty from "lodash/isEmpty";
import PropTypes from "prop-types";
import {
  CheckboxIcon,
  CheckboxIntermediateIcon,
  CheckboxSelectedIcon,
  ChevronDownIcon,
  ChevronRightIcon,
} from "../assets/icon";
import Table from "./Table";

const checkExpand = (currentRow, expandedList) => {
  const { expandTableIdentifier } = currentRow;
  if (!expandTableIdentifier) return true;
  return expandedList.includes(expandTableIdentifier);
};

const splitParentChildValues = (data = [], keyField, childKeyField, childIdentificationKey) => {
  const parent = [];
  let child = [];
  data.forEach((d) => {
    const parentInfo = d[keyField];
    if (parentInfo) parent.push(parentInfo);
    const childValues = (d[childIdentificationKey] || []).map((child) => child[childKeyField]);
    child = [...child, ...childValues].filter(Boolean);
  });
  return { parent, child };
};

const checkExpandTableIndeterminateSelect = ({
  data,
  selection,
  keyField,
  childKeyField,
  childIdentificationKey,
}) => {
  const { parentSelection, childSelection } = selection;
  const { parent, child } = splitParentChildValues(
    data,
    keyField,
    childKeyField,
    childIdentificationKey,
  );
  const filteredParent = intersection(parentSelection, parent);
  const filteredChild = intersection(childSelection, child);
  const inParent = filteredParent.length > 0;
  const inChild = filteredChild.length > 0;
  const checkAllSelected =
    [...filteredParent, ...filteredChild].length === [...parent, ...child].length;

  return (inParent || inChild) && !checkAllSelected;
};

const checkExpandTableParentIndeterminateSelect = ({
  row,
  selection,
  data,
  keyField,
  childKeyField,
  childIdentificationKey,
}) => {
  const parent = data.find((data) => data[keyField] === row[keyField]);
  if (!row.expandTableIdentifier && parent) {
    const children = parent[childIdentificationKey] || [];
    const childIds = children.map((child) => child[childKeyField]);
    const { childSelection } = selection;
    const currentChildSelection = childSelection.filter((child) => childIds.includes(child));
    const currentSelection = intersection(currentChildSelection, childIds);
    const foundInSelection = currentSelection.length > 0;
    const checkAllChildSelected = children.length !== currentSelection.length;
    return foundInSelection && checkAllChildSelected;
  }
  return false;
};

const checkExpandTableSelectAll = ({
  data,
  selection,
  keyField,
  childKeyField,
  childIdentificationKey,
}) => {
  const { parentSelection, childSelection } = selection;
  const { parent, child } = splitParentChildValues(
    data,
    keyField,
    childKeyField,
    childIdentificationKey,
  );
  const parentLength = parent.length;
  const childLength = child.length;
  const filterInParentLength = intersection(parent, parentSelection).length;
  const filterInChildLength = intersection(child, childSelection).length;
  const inParent = filterInParentLength === parentLength && parentLength !== 0;
  const inChild = filterInChildLength === childLength && childLength !== 0;
  return inParent || inChild;
};

const combineParentAndChild = (tableData, childIdentifier, expandedList, keyField) => {
  let row = [];
  tableData.forEach((data) => {
    const { [childIdentifier]: children, ...rest } = data;
    const child = (children || [])
      .map((childData, i) => ({
        ...childData,
        isFirstRow: i === 0,
        expandTableIdentifier: rest[keyField],
      }))
      .filter((childData) => expandedList.includes(childData.expandTableIdentifier));
    row = [...row, { ...data }, ...child];
  });
  row = row.filter(Boolean);
  return row;
};

const expandTableIsSelected = ({ key, selection, keyField, data }) => {
  const selected = false;
  const { parentSelection, childSelection } = selection;
  const isParent = data.some((d) => d[keyField] === key);
  if (isParent) {
    const keyInParent = parentSelection.includes(key);
    if (keyInParent && isParent) return true;
    return selected;
  }
  const keyInChild = childSelection.includes(key);
  if (keyInChild && !isParent) return true;
  return selected;
};

const expandTableShouldHideSelectCheck = (row = {}, showChildSelect, shouldHideSelect) => {
  if (shouldHideSelect && shouldHideSelect({ row })) return true;
  if (row && !showChildSelect && row.expandTableIdentifier) return true;
  return false;
};

const expandTableToggleAllSelection = ({
  data,
  keyField,
  selection,
  childKeyField,
  childIdentificationKey,
  onSelect,
}) => {
  let newParentSelection = [];
  let newChildSelection = [];
  const { parentSelection, childSelection } = selection;
  const selectedValues = [].concat(...Object.values(selection));
  const { parent, child } = splitParentChildValues(
    data,
    keyField,
    childKeyField,
    childIdentificationKey,
  );
  const currentSelection = [...parent, ...child];
  const filterData = currentSelection.filter((selected) => selectedValues.includes(selected));
  const selectAll = filterData.length === currentSelection.length;

  if (!selectAll) {
    newParentSelection = [...new Set(parentSelection.concat(parent))].filter(Boolean);
    newChildSelection = [...new Set(childSelection.concat(child))].filter(Boolean);
  } else {
    newParentSelection = difference(parentSelection, parent);
    newChildSelection = difference(childSelection, child);
  }
  return onSelect({ parentSelection: newParentSelection, childSelection: newChildSelection });
};

const getParentAndChildIndexAndInfo = (
  data = [],
  keyField,
  childKeyField,
  childIdentificationKey,
  value,
) => {
  const { parent, child } = splitParentChildValues(
    data,
    keyField,
    childKeyField,
    childIdentificationKey,
  );
  const parentIndex = parent.indexOf(value);
  const childIndex = child.indexOf(value);
  const childInfo = child[childIndex];
  const parentInfo = parent[parentIndex];
  return { parentIndex, childIndex, parentInfo, childInfo };
};

const expandTableToggleSelection = ({
  key,
  data,
  selection,
  keyField,
  childKeyField,
  childIdentificationKey,
  onSelect,
}) => {
  if (key) key = key.replace("select-", "");
  let parentSelection = [...selection.parentSelection];
  let childSelection = [...selection.childSelection];
  const { parentIndex, childIndex, childInfo } = getParentAndChildIndexAndInfo(
    data,
    keyField,
    childKeyField,
    childIdentificationKey,
    key,
  );
  if (parentIndex >= 0) {
    parentSelection = [...new Set(xor(selection.parentSelection, [key]))];
    const currentChild = map(data[parentIndex][childIdentificationKey], childKeyField);

    childSelection = parentSelection.includes(key)
      ? [...childSelection, ...currentChild]
      : difference(childSelection, currentChild);
  }
  if (childIndex >= 0) {
    childSelection = [...new Set(xor(selection.childSelection, [key]))];
    const foundParent = data.find((da) =>
      da[childIdentificationKey].map((child) => child[childKeyField]).includes(childInfo),
    );
    const currentChildArray = foundParent[childIdentificationKey].map(
      (child) => child[childKeyField],
    );
    const checkEverythingIncludes = currentChildArray.every((child) =>
      childSelection.includes(child),
    );
    parentSelection = !checkEverythingIncludes
      ? parentSelection.filter((parent) => parent !== foundParent[keyField])
      : [...parentSelection, foundParent[keyField]];
  }
  parentSelection = parentSelection.filter(Boolean);
  childSelection = childSelection.filter(Boolean);
  return onSelect({ parentSelection, childSelection });
};

const modifyAccessor = (column, _original) => {
  const { accessor, childAccessor, parentAccessor } = column;
  const accessorIsString = typeof accessor === "string";
  const parentAccessorIsString = typeof parentAccessor === "string";
  const childAccessorIsString = typeof childAccessor === "string";
  if (_original.expandTableIdentifier && childAccessor)
    return childAccessorIsString ? _original[childAccessor] : childAccessor(_original);
  if (!_original.expandTableIdentifier && parentAccessor)
    return parentAccessorIsString ? _original[parentAccessor] : parentAccessor(_original);
  if (accessor) return accessorIsString ? _original[accessor] : accessor(_original);

  return null;
};

const modifyComponentCell = (columns) =>
  columns.map((column) => {
    const columnInfo = column;
    if (!column.Cell) {
      const Cell = (props) => {
        const {
          row: { _original },
        } = props;
        // eslint-disable-next-line no-prototype-builtins
        if (_original.expandTableIdentifier && column.hasOwnProperty("childCell"))
          return column.childCell(props);
        // eslint-disable-next-line no-prototype-builtins
        if (!_original.expandTableIdentifier && column.hasOwnProperty("parentCell"))
          return column.parentCell(props);
        const accessor = modifyAccessor(column, _original);
        if (accessor === undefined) {
          console.warn(`The accessor returns undefined in row ${column.id || column.accessor}`);
          return null;
        }
        return accessor;
      };
      columnInfo.Cell = Cell;
    }
    const cellClassName = (state, rowInfo) => {
      if (!rowInfo) return {};
      const {
        row: { _original },
      } = rowInfo;
      if (!_original.expandTableIdentifier) return {};
      // eslint-disable-next-line no-prototype-builtins
      if (columnInfo.hasOwnProperty("childCell") && _original.expandTableIdentifier)
        return { className: "custom-child-cell" };
      return { className: "wb-cell wb-cell-expand-cell" };
    };
    columnInfo.getProps = cellClassName;
    return columnInfo;
  });

const sortData = (data, sortArray, columns, childIdentificationKey) => {
  if (sortArray.length !== 0) {
    const accessors = [];
    const childAccessors = [];
    const accessorsSortMethod = [];
    sortArray.forEach((sortInfo) => {
      const { id, desc } = sortInfo;
      const { accessor, childAccessor } = columns.find(
        (column) => column.id === id || column.accessor === id,
      );
      const sortMethod = desc ? "desc" : "asc";
      accessors.push(accessor);
      childAccessors.push(childAccessor || accessor);
      accessorsSortMethod.push(sortMethod);
    });

    const sortedParent = orderBy(data, accessors, accessorsSortMethod);
    const combineSort = sortedParent.map((parent) => {
      const childArray = parent[childIdentificationKey] || [];
      return {
        ...parent,
        [childIdentificationKey]: orderBy(childArray, childAccessors, accessorsSortMethod),
      };
    });
    return combineSort;
  }
  return data;
};

const TableCheckbox = (props) => {
  const mergedProps = { showChildSelect: true, shouldHideSelect: () => false, ...props };
  if (mergedProps.shouldHideSelect(mergedProps)) return null;

  const onClick = (e) => {
    const { shiftKey } = e;
    e.stopPropagation();
    mergedProps.onClick(mergedProps.id, shiftKey, mergedProps.row);
  };

  let icon = <CheckboxIcon onClick={(e) => onClick(e)} />;

  if (mergedProps.checked) {
    icon = <CheckboxSelectedIcon onClick={(e) => onClick(e)} />;
  } else if (mergedProps.indeterminate) {
    icon = <CheckboxIntermediateIcon onClick={(e) => onClick(e)} />;
  }
  return <div className="wb-checkbox">{icon}</div>;
};

class ExpandCell extends PureComponent {
  static propTypes = {
    row: PropTypes.object.isRequired,
    childIdentificationKey: PropTypes.string,
    expandedList: PropTypes.array.isRequired,
    handleExpandClick: PropTypes.func.isRequired,
    expandChildComponent: PropTypes.func.isRequired,
  };
  static defaultProps = {
    childIdentificationKey: "",
  };
  render() {
    const { row, expandedList, handleExpandClick, expandChildComponent, childIdentificationKey } =
      this.props;
    const isExpanded = expandedList.includes(row.id);
    const disabled = !row.expandTableIdentifier && isEmpty(row[childIdentificationKey]);
    const containerClass = classNames(
      "wb-cell-expand-cell-container",
      { disabled },
      {
        active: isExpanded,
      },
    );

    if (row.expandTableIdentifier) {
      return <div className={containerClass}>{expandChildComponent(row)}</div>;
    }

    return (
      <div className={containerClass} onClick={(e) => !disabled && handleExpandClick(e)}>
        {isExpanded ? <ChevronDownIcon /> : <ChevronRightIcon />}
      </div>
    );
  }
}

class ExpandTable extends PureComponent {
  static propTypes = {
    keyField: PropTypes.string,
    className: PropTypes.string,
    striped: PropTypes.bool,
    childKeyField: PropTypes.string,
    columns: PropTypes.array,
    style: PropTypes.object,
    selectable: PropTypes.bool,
    showChildSelect: PropTypes.bool,
    selection: PropTypes.object,
    shouldHideSelect: PropTypes.func.isRequired,
    childIdentificationKey: PropTypes.string,
    data: PropTypes.array,
    expandChildComponent: PropTypes.func,
    manual: PropTypes.bool,
    showColumnSeparator: PropTypes.bool,
  };

  static defaultProps = {
    keyField: "id",
    className: "",
    striped: false,
    childKeyField: "id",
    columns: [],
    shouldHideSelect: () => false,
    selection: { parentSelection: [], childSelection: [] },
    selectable: false,
    showChildSelect: true,
    childIdentificationKey: "",
    data: [],
    style: {},
    expandChildComponent: () => <div />,
    manual: true,
    showColumnSeparator: false,
  };

  state = {
    expandedList: [],
    sort: [],
  };

  handleExpandClick(event, value) {
    event.stopPropagation();
    const { expandedList } = this.state;
    const newList = xor(expandedList, [value]);
    this.setState({ expandedList: newList });
  }

  handleSort = (sortInputs) => {
    this.setState({ expandedList: [], sort: sortInputs });
  };

  render() {
    const {
      columns,
      childIdentificationKey,
      data,
      striped,
      className,
      style,
      expandChildComponent,
      keyField,
      selection,
      onSelect,
      showChildSelect,
      manual,
      sorted,
      onSortedChange,
      childKeyField,
      selectable,
      shouldHideSelect,
      showColumnSeparator,
    } = this.props;
    const { expandedList, sort } = this.state;
    const expandCellTemplate = {
      Header: "",
      sortable: false,
      resizable: false,
      hideIfOnlyColumn: true,
      className: classNames(
        "wb-cell-expand-icon",
        { "wb-cell": !showColumnSeparator },
        { "wb-cell-border": showColumnSeparator },
      ),
      headerClassName: classNames(
        "wb-cell-expand-icon",
        { "wb-header": !showColumnSeparator },
        { "wb-header-border": showColumnSeparator },
      ),
      Cell: ({ row }) => (
        <ExpandCell
          childIdentificationKey={childIdentificationKey}
          expandChildComponent={expandChildComponent}
          handleExpandClick={(e) => this.handleExpandClick(e, row._original.id)}
          row={row._original}
          expandedList={expandedList}
        />
      ),
    };
    const tableStyle = { maxHeight: `${window.screen.height - 200}px`, ...style };
    const tableClass = classNames(className, { "-striped": striped });
    const modifyColumnDefinition = modifyComponentCell(columns);
    const sortedArray = sortData([...data], sort, modifyColumnDefinition, childIdentificationKey);
    const modifiedData = combineParentAndChild(
      sortedArray,
      childIdentificationKey,
      expandedList,
      keyField,
    );

    const tableProps = {
      getTrProps: (state, rowInfo) => {
        const { original } = rowInfo;
        const isExpanded = checkExpand(original, expandedList);
        const display = isExpanded ? "flex" : "none";
        return { style: { display } };
      },
      freezeWhenExpanded: true,
      defaultPageSize: modifiedData.length,
      ...this.props,
      columns: [expandCellTemplate, ...modifyColumnDefinition],
      data: modifiedData,
      style: tableStyle,
      className: tableClass,
      sorted: manual ? sorted : this.state.sort,
      onSortedChange: manual ? onSortedChange : this.handleSort,
      sortedData: modifiedData.map((data) => ({ _original: data, ...data })),
      expandedList: this.state.expandedList,
    };

    const commonArgs = {
      data,
      selection,
      keyField,
      childKeyField,
      childIdentificationKey,
      onSelect,
    };
    const expandableIndeterminate = (row) =>
      checkExpandTableParentIndeterminateSelect({ ...commonArgs, row });
    const selectAll = checkExpandTableSelectAll({
      ...commonArgs,
    });
    const indeterminate = checkExpandTableIndeterminateSelect({
      ...commonArgs,
    });
    const isSelected = (key) =>
      expandTableIsSelected({
        ...commonArgs,
        key,
      });
    const checkboxComponent = (props) => (
      <TableCheckbox
        {...props}
        shouldHideSelect={({ row }) =>
          expandTableShouldHideSelectCheck(row, showChildSelect, shouldHideSelect)
        }
      />
    );
    const toggleSelection = (key) =>
      expandTableToggleSelection({
        ...commonArgs,
        key,
      });
    const toggleAll = () => expandTableToggleAllSelection(commonArgs);

    const selectTableProps = {
      expandableIndeterminate,
      indeterminate,
      selectAll,
      isSelected,
      checkboxComponent,
      toggleSelection,
      showChildSelect,
      toggleAll,
    };

    const props = selectable ? { ...tableProps, ...selectTableProps } : tableProps;

    return (
      <Table
        {...props}
        selection={selection.parentSelection}
        showColumnSeparator={showColumnSeparator}
      />
    );
  }
}

export default ExpandTable;
