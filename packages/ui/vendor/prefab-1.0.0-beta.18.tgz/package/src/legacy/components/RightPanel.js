import React from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import classNames from "classnames";
import compact from "lodash/compact";
import flatten from "lodash/flatten";
import { BUTTON_TYPE } from "../constants/BaseButton";
import BaseButton from "./BaseButton";

const portalRoot = document.getElementById("right-panel-portal");

const RightPaneLoading = ({ count = 4 }) => {
  return (
    <>
      {Array(count)
        .fill({})
        .map((c, i) => (
          <div className="mb2" key={i}>
            <div
              className={classNames("col-12 mb1", "skeletonLoader")}
              style={{ fontSize: "1rem", width: "65%" }}
            >
              &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            </div>
            <div className={classNames("col-12", "skeletonLoader")} style={{ fontSize: "1.5rem" }}>
              &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            </div>
          </div>
        ))}
    </>
  );
};

class RightPanel extends React.Component {
  constructor(props) {
    super(props);
    this.portalNode = document.createElement("div");
    this.escFunction = this.escFunction.bind(this);
  }

  componentDidMount() {
    portalRoot.appendChild(this.portalNode);
    document.addEventListener("keydown", this.escFunction, false);
  }

  componentWillUnmount() {
    portalRoot.removeChild(this.portalNode);
    document.removeEventListener("keydown", this.escFunction, false);
  }

  escFunction(event) {
    if (event.keyCode === 27) {
      this.props.onClose();
    }
  }

  renderPrimaryButtons(buttonProps) {
    const buttons = flatten(compact([buttonProps]));
    return buttons.map(
      ({ buttonType = BUTTON_TYPE.PRIMARY, isHidden, loading, ...primaryButtonProp }, index) => {
        if (isHidden) return null;
        return (
          <BaseButton
            key={index}
            className={classNames("flex", "buttonSpacing", { skeletonLoader: loading })}
            buttonType={buttonType}
            onClick={primaryButtonProp.onClick}
            buttonText={primaryButtonProp.buttonText}
            disabled={primaryButtonProp.disabled}
          />
        );
      },
    );
  }

  renderFooter() {
    const { isLoading, primaryButtonProps, secondaryButtonProps, footer } = this.props;
    return (
      <div
        className={classNames(`flex flex-auto`, {
          skeletonLoader: isLoading,
        })}
      >
        {!isLoading && this.renderPrimaryButtons(primaryButtonProps)}
        {secondaryButtonProps && !isLoading && (
          <BaseButton
            className={classNames("flex", { skeletonLoader: secondaryButtonProps.loading })}
            onClick={secondaryButtonProps.onClick}
            buttonType={BUTTON_TYPE.SECONDARY}
            buttonText={secondaryButtonProps.buttonText}
            disabled={secondaryButtonProps.disabled}
          />
        )}
        {!isLoading && footer}
      </div>
    );
  }

  renderPanelView() {
    const {
      isOpen,
      children,
      onClose,
      header,
      showFooter,
      isLoading,
      hideOverlay,
      className,
      showClearAll,
      clearAllText,
      onClickClearAll,
      containerStyle,
      backIconPresent,
      containerClassName,
    } = this.props;
    if (isOpen) {
      return (
        <div className={classNames("rightPanelWrapper", containerClassName)}>
          {!hideOverlay && <div className="rightPanelOverlay" onClick={onClose}></div>}
          <div className={"rightPanelContainer"} style={containerStyle}>
            <div
              className={classNames("panelHeader", {
                "justify-none": backIconPresent,
              })}
            >
              {backIconPresent && (
                <BaseButton
                  iconName="ChevronLeftIcon"
                  buttonType={BUTTON_TYPE.SECONDARY}
                  onClick={onClose}
                  className="backIcon"
                />
              )}

              {header && (
                <div
                  className={classNames("flex text-ellipsize", {
                    skeletonLoader: isLoading,
                  })}
                  title={header}
                >
                  {header}
                  {showClearAll && (
                    <span className="clear" onClick={onClickClearAll}>
                      {typeof clearAllText === "string" ? clearAllText : "Clear All"}
                    </span>
                  )}
                </div>
              )}

              {!backIconPresent && (
                <BaseButton
                  iconName="CancelIcon"
                  buttonType={BUTTON_TYPE.SECONDARY}
                  onClick={onClose}
                />
              )}
            </div>
            <div
              className={classNames(className, "panelChildWrapper", {
                childWrapperWithFooter: showFooter,
              })}
            >
              {isLoading ? <RightPaneLoading /> : children}
            </div>
            {showFooter && <div className="panelFooter">{this.renderFooter()}</div>}
          </div>
        </div>
      );
    }
    return null;
  }

  render() {
    return ReactDOM.createPortal(this.renderPanelView(), this.portalNode);
  }
}

RightPanel.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  showFooter: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  header: PropTypes.string.isRequired,
  footer: PropTypes.node,
  isLoading: PropTypes.bool,
  hideOverlay: PropTypes.bool,
  showClearAll: PropTypes.bool,
  clearAllText: PropTypes.string,
  onClickClearAll: PropTypes.func,
};

RightPanel.defaultProps = {
  isOpen: false,
  showFooter: false,
  isLoading: false,
  hideOverlay: false,
  showClearAll: false,
};

export default RightPanel;
