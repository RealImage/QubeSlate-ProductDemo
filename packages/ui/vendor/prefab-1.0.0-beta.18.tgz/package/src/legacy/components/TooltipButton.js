/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import classNames from "classnames";
import { Tooltip, Position } from "@blueprintjs/core";
import PropTypes from "prop-types";

import { BUTTON_TYPE } from "../constants";
import BaseButton from "./BaseButton";

class TooltipButton extends Component {
  static propTypes = {
    toolTip: PropTypes.oneOfType([PropTypes.node, PropTypes.element]),
    toolTipPosition: PropTypes.string,
    toolTipClass: PropTypes.string,
  };
  static defaultProps = {
    toolTipPosition: Position.TOP,
    toolTipClass: "",
  };
  renderButton = () => {
    const { toolTip, toolTipPosition, toolTipClass, text, ...rest } = this.props;

    return <BaseButton buttonText={text} buttonType={BUTTON_TYPE.SECONDARY} {...rest} />;
  };
  render() {
    const { toolTip, toolTipPosition, toolTipClass } = this.props;
    return (
      <Tooltip
        className={classNames("toolTipContainer", toolTipClass)}
        position={toolTipPosition}
        content={toolTip && toolTip}
        usePortal={false}
      >
        {this.renderButton()}
      </Tooltip>
    );
  }
}

export default TooltipButton;
