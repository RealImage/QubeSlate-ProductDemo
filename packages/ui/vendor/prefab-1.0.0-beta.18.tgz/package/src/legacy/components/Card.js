import PropTypes from "prop-types";
import ClassNames from "classnames";
import map from "lodash/map";
import isInteger from "lodash/isInteger";
import join from "lodash/join";
import keys from "lodash/keys";
import { VIEW_PORT_SIZE_CLASS } from "../constants";

/**
 * @name getCardClassName
 * @description Updates ClassName for container element with column sizes
 * @param {Object} props
 * @returns {String}
 */
const getCardClassName = (props) => {
  const cardClassName = [];
  map(keys(VIEW_PORT_SIZE_CLASS), (currentPort) => {
    const currentPortValue = props[currentPort];
    if (isInteger(currentPortValue)) {
      cardClassName.push(`col-${currentPort}-${currentPortValue}`);
    } else {
      cardClassName.push(`col ${currentPortValue}`);
    }
  });

  return join(cardClassName, " ");
};

/**
 * Functional Component that acts as container for Form elements.
 *
 * @component
 * <Card />
 * @example
 * <Card
 *    xl={STRING},
 *    lg={STRING},
 *    md={STRING},
 *    sm={STRING},
 *    xs={STRING}
 *    className={STRING}
 * />
 *
 */

const Card = ({ className, children, xs = 12, sm = 12, md = 6, lg = 4, xl = 3, ...restProps }) => {
  const cardClassName = ClassNames(
    className,
    getCardClassName({ xs, sm, md, lg, xl, ...restProps }),
  );
  return <div className={cardClassName}>{children}</div>;
};

Card.propTypes = {
  /**
   * Extra small devices (portrait phones, less than 576px)
   */
  xs: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Small devices (landscape phones, less than 768px)
   */
  sm: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Medium devices (tablets, less than 992px)
   */
  md: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Large devices (desktops, less than 1200px)
   */
  lg: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * Extra large devices (large desktops)
   */
  xl: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  /**
   * ClassName to add classes to container
   */
  className: PropTypes.string,
};

export default Card;
