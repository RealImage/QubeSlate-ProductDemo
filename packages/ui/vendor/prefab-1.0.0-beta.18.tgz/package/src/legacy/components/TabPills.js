import { Component } from "react";
import PropTypes from "prop-types";
import { Tag } from "@blueprintjs/core";
import classNames from "classnames";

class TabPills extends Component {
  render() {
    const { tabs, selectedTabId, onChange } = this.props;
    return (
      <div className="tabPillsContainer">
        {tabs.map((tab) => (
          <Tag
            key={tab.id}
            minimal={tab.id !== selectedTabId}
            size="large"
            interactive
            className={classNames("tab", { active: tab.id === selectedTabId })}
            onClick={() => onChange(tab.id)}
          >
            {tab.title}
          </Tag>
        ))}
      </div>
    );
  }
}

TabPills.propTypes = {
  tabs: PropTypes.array.isRequired,
  selectedTabId: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};

export default TabPills;
