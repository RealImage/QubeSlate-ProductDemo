/* eslint-disable @typescript-eslint/no-unused-vars */
import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  PopoverNext,
  Position,
  Menu,
  Intent,
  PopoverInteractionKind,
  popoverPropsToNextProps,
} from "@blueprintjs/core";
import MenuItem from "../../MenuItem";
import { getInitialsFromName } from "../../../utils";
import { MoreHorizontalIcon } from "../../../assets/icon";

function NavProfileV2({
  name,
  companyName,
  isExpanded,
  usePortal = true,
  popOverPosition = Position.TOP_RIGHT,
  menuList = [],
  withUserInitial = false,
  classNames: classNamesProp = {},
  history = {},
  isMenuActive,
  onCollapsedItemClick,
}) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!isExpanded) {
      setIsOpen(false);
    }
  }, [isExpanded]);

  const handleMenuClick = (url, openNewTab = false) => {
    if (openNewTab) {
      window.open(url, "_blank");
    } else if (history) {
      history.push(url);
    }
  };

  const renderMenu = () => {
    const hideMenuClassName = !isExpanded && "hide";
    return (
      <Menu className={classNames("menu", "profileMenuContainer", hideMenuClassName)}>
        {menuList.map(({ Icon, ...menu }, i) => (
          <div onClick={() => handleMenuClick(menu.route, menu?.openNewTab)} key={i}>
            <MenuItem
              active={isMenuActive([menu.route])}
              menuItemClass={classNames(isMenuActive([menu.route]) && "activeMenu")}
              icon={Icon && <Icon className="popMenuItemIcon" />}
              text={<div className="popupMenuText">{menu.name}</div>}
              tagName="div"
              shouldDismissPopover={menu.shouldDismissPopover ?? true}
              {...menu}
            />
          </div>
        ))}
      </Menu>
    );
  };

  const {
    container = null,
    profileContainer = null,
    portalClassName = null,
    userName: userNameClass = null,
    companyName: companyNameClass = null,
    iconContainer = null,
    profileWrapper = null,
    userInitial = null,
  } = classNamesProp;

  return (
    <div
      className={classNames("flex no-select col-12 navProfileContainer", container)}
      onClick={() => setIsOpen(!isOpen)}
    >
      <>
        {isExpanded && (
          <div className={classNames("profileWrapper", profileWrapper)}>
            <div className={classNames("profileContainer", profileContainer)}>
              <div className={classNames("flex flex-column", "content")}>
                <div
                  className={classNames("col-11 h4 semi text-ellipsize", "userName", userNameClass)}
                >
                  {name}
                </div>
                <div
                  className={classNames(
                    "col-11 h5 text-ellipsize",
                    "companyName",
                    companyNameClass,
                  )}
                >
                  {companyName}
                </div>
              </div>
              <div className={classNames("chevron", iconContainer)}>
                <PopoverNext
                  {...popoverPropsToNextProps({
                    portalClassName: classNames("popOver navProfilePopover v2", portalClassName),
                    usePortal,
                    onClose: () => setIsOpen(false),
                    interactionKind: PopoverInteractionKind.CLICK,
                    content: menuList && renderMenu(),
                    position: Position.TOP_RIGHT,
                    minimal: true,
                    modifiers: {
                      offset: {
                        enabled: true,
                        offset: "120, 0",
                      },
                    },
                  })}
                >
                  <MoreHorizontalIcon intent={Intent.PRIMARY} />
                </PopoverNext>
              </div>
            </div>
          </div>
        )}
        {!isExpanded && (
          <div
            className={classNames("userInitial", userInitial)}
            onClick={!isExpanded ? onCollapsedItemClick : undefined}
          >
            <span>{withUserInitial ? getInitialsFromName(name) : name}</span>
          </div>
        )}
      </>
    </div>
  );
}

NavProfileV2.propTypes = {
  name: PropTypes.string.isRequired,
  companyName: PropTypes.string.isRequired,
  isMenuActive: PropTypes.func.isRequired,
  onToggleButtonClick: PropTypes.func.isRequired,
  isExpanded: PropTypes.bool.isRequired,
  usePortal: PropTypes.bool,
  withUserInitial: PropTypes.bool,
  popOverPosition: PropTypes.oneOf([...Object.values(Position)]),
  iconPosition: PropTypes.oneOf(["left", "right"]),
  classNames: PropTypes.shape({
    container: PropTypes.string,
    profileContainer: PropTypes.string,
    portalClassName: PropTypes.string,
    userName: PropTypes.string,
    companyName: PropTypes.string,
    iconContainer: PropTypes.string,
  }),
  menuList: PropTypes.array,
  history: PropTypes.object,
};

export default NavProfileV2;
