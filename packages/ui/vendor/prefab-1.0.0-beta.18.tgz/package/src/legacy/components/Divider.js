import { createElement } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

const Divider = ({ className, tagName = "div", ...otherProps }) => {
  return createElement(tagName, {
    ...otherProps,
    className: classNames("divider", className),
  });
};
export default Divider;

Divider.propTypes = {
  tagName: PropTypes.string,
};
