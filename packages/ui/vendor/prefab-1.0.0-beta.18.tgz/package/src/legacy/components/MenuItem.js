/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import classNames from "classnames";
import { MenuItem as BluePrintMenuItem } from "@blueprintjs/core";

class MenuItem extends Component {
  render() {
    const {
      icon: Icon,
      scope,
      userData,
      popoverProps,
      isIconRight = true,
      menuItemClass,
      ...rest
    } = this.props;
    return (
      <BluePrintMenuItem
        className={classNames("menuItem", menuItemClass)}
        labelClassName={"icon"}
        labelElement={isIconRight && Icon && Icon}
        icon={!isIconRight && Icon && Icon}
        popoverProps={{
          usePortal: false,
          minimal: true,
          ...popoverProps,
        }}
        {...rest}
      />
    );
  }
}

export default MenuItem;
