import { forwardRef } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ChevronDownIcon } from "../../../assets/icon";
import ToolTip from "../../../components/ToolTip";

const NavMenuItemV2 = forwardRef(
  (
    {
      name,
      route,
      Icon = null,
      isSelected = false,
      isExpanded = false,
      openNewTab = false,
      menuId = "",
      classNames: classNamesProp = {},
      isAccordion = false,
      isAccordionOpen = false,
      onItemClick = null,
      history = null,
      isMobile = false,
      resetAccordion,
    },
    ref,
  ) => {
    const { navMenuItem: navMenuItemClassName } = classNamesProp;

    const handleClick = (e) => {
      if (onItemClick) {
        if (isAccordion && !isExpanded && !isMobile) {
          e.preventDefault();
          onItemClick();
          return;
        } else if (isMobile && isExpanded) {
          onItemClick();
        }
        if (!isAccordion && resetAccordion) {
          resetAccordion();
        }
      }

      // Navigation (external or open in new tab)
      if (openNewTab) {
        window.open(route, "_blank");
      } else if (history) {
        history.push(route);
      }
    };

    return (
      <ToolTip
        toolTip={name}
        disabled={isExpanded}
        toolTipPosition="right"
        popoverClassName="nav-tooltip-popover navmenu-item-tooltip"
        minimal={true}
        usePortal={!isExpanded}
        modifiers={{
          offset: {
            enabled: true,
            offset: "-4, 10",
          },
        }}
      >
        <button
          ref={ref}
          data-menuid={menuId}
          onClick={handleClick}
          className={classNames(
            "navMenuItem_v2",
            {
              "navMenuItem_v2--selected": isSelected,
              "navMenuItem_v2--expanded": isExpanded,
              "menu--accordion": isAccordion,
              "menu--item": !isAccordion,
            },
            navMenuItemClassName,
          )}
          type="button"
          id={menuId}
        >
          {Icon && <Icon className="navMenuItem_v2__icon" />}
          <span className="navMenuItem_v2__name">{name}</span>
          {isAccordion && (
            <ChevronDownIcon
              className={classNames("navMenuItem_v2__chevron", {
                "navMenuItem_v2__chevron--open": isAccordionOpen,
              })}
            />
          )}
        </button>
      </ToolTip>
    );
  },
);

NavMenuItemV2.propTypes = {
  name: PropTypes.string.isRequired,
  route: PropTypes.string,
  Icon: PropTypes.func,
  isSelected: PropTypes.bool,
  isExpanded: PropTypes.bool,
  openNewTab: PropTypes.bool,
  menuId: PropTypes.string,
  classNames: PropTypes.shape({
    navMenuItem: PropTypes.string,
  }),
  isAccordion: PropTypes.bool,
  isAccordionOpen: PropTypes.bool,
  onItemClick: PropTypes.func,
  history: PropTypes.object,
  isMobile: PropTypes.bool,
};

NavMenuItemV2.displayName = "NavMenuItemV2";

export default NavMenuItemV2;
