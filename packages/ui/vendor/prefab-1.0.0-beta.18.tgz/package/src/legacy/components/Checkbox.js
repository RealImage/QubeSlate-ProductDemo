import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import { CheckboxIcon, CheckboxSelectedIcon, AdjustIcon } from "../assets/icon";

/**
 * A checkbox allows the user to toggle between checked, unchecked, and (rarely) indeterminate states.
 * This component does not supports HTML input props.
 *
 * @component
 *
 * ```<Checkbox />```
 *
 * @example
 *
 * `<Checkbox
 *    checked={BOOLEAN},
 *    onChange={FUNCTION},
 *    label={STRING},
 *    disabled={BOOLEAN},
 *    iconProps={OBJECT}
 *    className={STRING}
 * />`
 *
 */
class Checkbox extends Component {
  render() {
    const {
      iconProps,
      onChange,
      checked,
      indeterminate,
      label,
      loading,
      disabled,
      className,
      DragDropIcon,
    } = this.props;
    let icon = <CheckboxIcon {...iconProps} />;
    if (checked) {
      icon = <CheckboxSelectedIcon {...iconProps} />;
    } else if (indeterminate) {
      icon = <CheckboxIcon {...iconProps} />;
    }
    return (
      <div
        className={classNames(className, "col-12", "checkbox", {
          notAllowed: disabled,
        })}
      >
        <div
          className={classNames("flex", {
            skeletonLoader: loading,
            checkbox_container: !loading,
            disabled: disabled,
          })}
          onClick={onChange}
        >
          {DragDropIcon && <AdjustIcon className="adjustIcon" />}
          <div className="checkbox">{icon}</div>
          {label && <div className="checkboxlabel">{label}</div>}
        </div>
      </div>
    );
  }
}

Checkbox.propTypes = {
  /**
   * Controls the checked state of Checkbox.
   */
  checked: PropTypes.bool.isRequired,
  /**
   * Whether the checkbox is indeterminate, or "partially checked"
   * The checkbox will appear with a primary border color to indicate that the value is not exactly true or false.
   */
  indeterminate: PropTypes.bool,
  /**
   * Controls the loading state of Checkbox.
   */
  loading: PropTypes.bool,
  /**
   * Event handler invoked when click is done.
   */
  onChange: PropTypes.func.isRequired,
  /**
   * Supports only string
   */
  label: PropTypes.string,
  /**
   * Disables the events and makes checkbox non-interactive
   */
  disabled: PropTypes.bool,
};

Checkbox.defaultProps = {
  loading: false,
  disabled: false,
  label: "",
};

export default Checkbox;
