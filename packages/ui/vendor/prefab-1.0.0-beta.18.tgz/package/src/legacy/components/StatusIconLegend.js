import { Component, Fragment } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import groupBy from "lodash/groupBy";
import values from "lodash/values";
import inRange from "lodash/inRange";
import StatusIcon from "./StatusIcon";
import Divider from "./Divider";

class StatusIconLegend extends Component {
  handleFilterSelect = ({ tagType, name, id }) => {
    if (this.props.onFilterSelect) {
      this.props.onFilterSelect({
        id,
        displayName: name,
        type: tagType,
      });
    }
  };

  renderStatus = (status, index) => {
    return (
      <div
        className={classNames("statusIconLegend", {
          cursorPointer: this.props.onFilterSelect,
        })}
        key={index}
        onClick={() => this.handleFilterSelect(status)}
      >
        <StatusIcon color={status.color} type={status.type} />
        <span className="statusCount">{status.count}</span>
        <span>{status.name}</span>
      </div>
    );
  };

  render() {
    const groupedStatusInfo = groupBy(this.props.statusInfo, "tagType");
    if (!values(groupedStatusInfo).some((group) => group.some((data) => data.count > 0)))
      return null;
    return (
      <div className={classNames("flex", "statusLegendContainer", this.props.className)}>
        {values(groupedStatusInfo).map((statusInfoItem, index) => (
          <Fragment key={index}>
            {statusInfoItem.map(
              (status, statusIndex) => status.count > 0 && this.renderStatus(status, statusIndex),
            )}
            {inRange(index, 0, values(groupedStatusInfo).length - 1) && <Divider />}
          </Fragment>
        ))}
      </div>
    );
  }
}

StatusIconLegend.propTypes = {
  statusInfo: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string,
      count: PropTypes.number,
      type: PropTypes.string,
      color: PropTypes.string,
      tagType: PropTypes.string,
    }),
  ).isRequired,
  onFilterSelect: PropTypes.func,
  className: PropTypes.string,
};

StatusIconLegend.defaultProps = {
  onFilterSelect: null,
};

export default StatusIconLegend;
