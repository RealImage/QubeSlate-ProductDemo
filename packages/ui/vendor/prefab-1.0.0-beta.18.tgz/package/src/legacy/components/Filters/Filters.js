import { Component } from "react";
import PropTypes from "prop-types";
import findIndex from "lodash/findIndex";
import flatten from "lodash/flatten";

import RightPanel from "../RightPanel";
import BaseButton from "../BaseButton";
import FilterSection from "./FilterSection";

class Filters extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
    };
  }

  closePanel = () => this.setState({ isOpen: false });
  togglePanel = () => this.setState((state) => ({ isOpen: !state.isOpen }));

  onFilterSelect = (tag, override) => {
    const { selected, onFilterChange } = this.props;
    const index = findIndex(selected, (f) => f.id === tag.id);

    if (index >= 0) {
      if (override) {
        selected[index] = tag;
        onFilterChange(selected);
      } else onFilterChange(selected.filter((f) => f.id !== tag.id));
    } else onFilterChange([tag, ...selected]);
  };

  onFilterClear = (tagType) => {
    const { selected, onFilterChange } = this.props;
    onFilterChange(selected.filter((f) => !flatten([tagType]).includes(f.type)));
  };

  render() {
    const { tagTypes, selected } = this.props;
    const filterTagTypes = flatten([tagTypes]);

    return (
      <>
        <BaseButton iconName="FilterAdjustIcon" onClick={this.togglePanel} />
        <RightPanel
          isOpen={this.state.isOpen}
          onClose={this.closePanel}
          header="Filters"
          hasFooter={false}
        >
          {filterTagTypes.map((filter) => (
            <FilterSection
              {...this.props}
              {...filter}
              tagType={filter.tagType}
              key={filter.tagType}
              selected={selected.filter((f) => flatten([filter.tagType]).includes(f.type))}
              onFilterClear={() => this.onFilterClear(filter.tagType)}
              onFilterChange={this.onFilterSelect}
            />
          ))}
        </RightPanel>
      </>
    );
  }
}

Filters.propTypes = {
  tagTypes: PropTypes.array.isRequired,
  selected: PropTypes.array,
  onFilterChange: PropTypes.func.isRequired,
};

Filters.defaultProps = {
  selected: [],
};

export default Filters;
