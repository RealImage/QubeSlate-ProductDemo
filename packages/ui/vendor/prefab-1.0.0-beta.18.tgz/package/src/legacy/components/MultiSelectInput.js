/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Position, MenuItem, Button } from "@blueprintjs/core";
import { MultiSelect as MultiSelectComponent } from "@blueprintjs/select";
import { ConfirmIcon } from "../assets/icon.js";
import BaseButton from "./BaseButton";
import Tag from "./Tag.js";

class MultiSelectInput extends Component {
  renderMenuItemWithSubText = (item) => {
    const { customSubTextName, customMenuName, showSubText, customMenuItemRender } = this.props;
    if (customMenuItemRender) return customMenuItemRender(item);
    return (
      <>
        <div className="multi_select_menu_name">{customMenuName(item)}</div>
        {showSubText && <div className="multi_select_menu_sub_text">{customSubTextName(item)}</div>}
      </>
    );
  };

  renderRightElement = () => {
    if (this.props.loading) return <Button icon="refresh" loading variant="minimal" />;

    if (this.props.query.length > 0)
      return (
        <BaseButton
          iconName="CancelIcon"
          className="rightElementClear"
          onClick={(event) => {
            if (this.props.onSearchClear) {
              this.props.onSearchClear(event);
            }
          }}
        />
      );
    return <BaseButton iconName="SearchIcon" className="rightElementSearch" />;
  };

  render() {
    const {
      classNameList: {
        containerClassName,
        menuItemClassName,
        multiSelectClassName,
        popoverClassName,
      },
      suggestionList,
      selectedItems,
      itemPredicate,
      itemRenderer,
      onQueryChange,
      popoverProps,
      tagRenderer,
      tagInputProps: { placeholder, ...otherTagInputProps },
      onMenuItemSelect,
      onFilterClear,
      onRemove,
      loading,
      noResultsText,
      query,
      customMenuName,
      showTag,
      matchTargetWidth = true,
      ...rest
    } = this.props;
    const selectedIds = selectedItems.map((s) => s.id);
    return (
      <div className={classNames("multiSelectContainer", containerClassName)}>
        <MultiSelectComponent
          selectedItems={selectedItems}
          className={classNames("inputValue", "menu", multiSelectClassName)}
          openOnKeyDown={suggestionList.length > 0}
          items={suggestionList}
          itemPredicate={itemPredicate}
          itemRenderer={
            itemRenderer
              ? itemRenderer
              : (item, itemProps) => (
                  <MenuItem
                    className={classNames(
                      menuItemClassName,
                      selectedIds.includes(item.id) && "selected",
                      itemProps.modifiers.active && "active",
                    )}
                    onClick={
                      selectedIds.includes(item.id) ? () => onRemove(item) : itemProps.handleClick
                    }
                    key={item.id}
                    text={this.renderMenuItemWithSubText(item)}
                    icon={selectedIds.includes(item.id) && <ConfirmIcon />}
                  />
                )
          }
          query={query}
          noResults={query && !loading ? <MenuItem disabled text={noResultsText} /> : null}
          onItemSelect={onMenuItemSelect}
          popoverProps={{
            matchTargetWidth: matchTargetWidth,
            popoverClassName: classNames(popoverClassName, "multiSelectPopOver"),
            minimal: true,
            usePortal: false,
            position: Position.BOTTOM,
          }}
          onQueryChange={onQueryChange}
          tagInputProps={{
            placeholder: showTag && selectedItems.length > 0 ? "" : placeholder,
            rightElement: this.renderRightElement(),
            children:
              showTag &&
              selectedItems.map((item) => (
                <Tag key={item.id} closeIcon onClose={() => onRemove(item)}>
                  {customMenuName(item)}
                </Tag>
              )),
            ...otherTagInputProps,
          }}
          tagRenderer={() => null}
          {...rest}
        />
      </div>
    );
  }
}

MultiSelectInput.propTypes = {
  classNameList: PropTypes.shape({
    containerClassName: PropTypes.string,
    menuItemClassName: PropTypes.string,
    multiSelectClassName: PropTypes.string,
    popoverClassName: PropTypes.string,
  }),
  suggestionList: PropTypes.array.isRequired,
  itemPredicate: PropTypes.func,
  onQueryChange: PropTypes.func,
  query: PropTypes.string,
  onMenuItemSelect: PropTypes.func.isRequired,
  popoverProps: PropTypes.object,
  tagRenderer: PropTypes.func,
  tagInputProps: PropTypes.object,
  showSubText: PropTypes.bool,
  customSubTextName: PropTypes.func,
  customMenuName: PropTypes.func,
  loading: PropTypes.bool,
  onSearchClear: PropTypes.func,
  onRemove: PropTypes.func,
  noResultsText: PropTypes.string,
  customMenuItemRender: PropTypes.func,
  itemRenderer: PropTypes.func,
};

MultiSelectInput.defaultProps = {
  classNameList: {
    containerClassName: "",
    menuItemClassName: "",
    multiSelectClassName: "",
    popoverClassName: "",
  },
  tagInputProps: {
    placeholder: "Search",
  },
  selectedItems: [],
  showSubText: false,
  loading: false,
  query: "",
  noResultsText: "No records found",
  customMenuName: (item) => item.name,
  customSubTextName: (item) => item.type,
};

export default MultiSelectInput;
