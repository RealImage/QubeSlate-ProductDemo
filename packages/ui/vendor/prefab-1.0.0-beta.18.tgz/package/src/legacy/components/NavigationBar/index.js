import Footer from "./Footer";
import FooterV2 from "./v2/FooterV2";
import NavigationBar from "./NavigationBar";
import NavigationBarV2 from "./NavigationBarV2";
import NavMenuAccordion from "./NavMenuAccordion";
import NavMenuItem from "./NavMenuItem";
import NavProfile from "./NavProfile";
import NavMenuAccordionV2 from "./v2/NavMenuAccordionV2";
import NavMenuItemV2 from "./v2/NavMenuItemV2";
import NavProfileV2 from "./v2/NavProfileV2";

const NavComponents = {
  Footer,
  NavigationBar,
  NavigationBarV2,
  NavMenuAccordion,
  NavMenuItem,
  NavProfile,
  NavMenuAccordionV2,
  NavMenuItemV2,
  NavProfileV2,
  FooterV2,
};

export default NavComponents;
