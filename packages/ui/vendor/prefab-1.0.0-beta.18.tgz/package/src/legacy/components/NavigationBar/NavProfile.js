import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  PopoverNext,
  Position,
  Menu,
  Intent,
  PopoverInteractionKind,
  popoverPropsToNextProps,
} from "@blueprintjs/core";
import MenuItem from "../MenuItem";
import { getInitialsFromName } from "../../utils";
import { SIZE } from "../../constants";
import BaseButton from "../BaseButton";
import { MoreHorizontalIcon } from "../../assets/icon.js";

/**
 * Component for Navigation bar to display profile details.
 *
 * @component <NavProfile />
 *
 * @example
 *
 * return (
 *   <NavProfile
 *      name={String}
 *      companyName={String}
 *      isMenuActive={Boolean}
 *      isExpanded={Boolean}
 *      isPinned={Boolean}
 *      menuList={Array}
 *      onToggleButtonClick={Function}
 *    />
 * )
 *
 */

export class NavProfile extends Component {
  state = {
    isOpen: false,
  };

  componentDidUpdate(prevProps) {
    const { isExpanded } = this.props;
    if (prevProps.isExpanded !== isExpanded) {
      this.setState({
        isOpen: false,
      });
    }
  }

  handleMenuClick = (url) => {
    this.props.history.push(url);
  };

  renderMenu = () => {
    const { menuList, isMenuActive, isExpanded } = this.props;
    const hideMenuClassName = !isExpanded && "hide";
    return (
      <Menu className={classNames("menu", "profileMenuContainer", hideMenuClassName)}>
        {menuList.map(({ Icon, ...menu }, i) => (
          <div onClick={() => this.handleMenuClick(menu.route)} key={i}>
            <MenuItem
              active={isMenuActive([menu.route])}
              menuItemClass={classNames(isMenuActive([menu.route]) && "activeMenu")}
              icon={Icon && <Icon className="popMenuItemIcon" />}
              text={<div className="popupMenuText">{menu.name}</div>}
              tagName="div"
              shouldDismissPopover={menu.shouldDismissPopover ?? true}
              {...menu}
            />
          </div>
        ))}
      </Menu>
    );
  };

  handleToggleButtonClick = (event) => {
    event.stopPropagation();

    if (this.props.onToggleButtonClick) this.props.onToggleButtonClick();
  };

  render = () => {
    const {
      name,
      companyName,
      isExpanded,
      usePortal,
      popOverProps,
      popOverPosition,
      menuList,
      isPinned,
      withUserInitial,
    } = this.props;
    const {
      container = null,
      profileContainer = null,
      portalClassName = null,
      userName: userNameClass = null,
      companyName: companyNameClass = null,
      iconContainer = null,
      profileWrapper = null,
      userInitial = null,
      toggleButton = null,
      toggleButtonActive = null,
    } = this.props.classNames;
    return (
      <div
        className={classNames("flex no-select col-12 navProfileContainer", container)}
        onClick={() =>
          this.setState({
            isOpen: !this.state.isOpen,
          })
        }
      >
        <>
          {isExpanded && (
            <div className={classNames("profileWrapper", profileWrapper)}>
              <BaseButton
                className={classNames("toggleButton", toggleButton, {
                  toggleButtonActive: isPinned,
                  [toggleButtonActive]: isPinned,
                })}
                iconName={"PinIcon"}
                buttonSize={SIZE.LARGE}
                onClick={this.handleToggleButtonClick}
              />
              <div className={classNames("profileContainer", profileContainer)}>
                <div className={classNames("flex flex-column", "content")}>
                  <div
                    className={classNames(
                      "col-11 h4 semi text-ellipsize",
                      "userName",
                      userNameClass,
                    )}
                  >
                    {name}
                  </div>
                  <div
                    className={classNames(
                      "col-11 h5 text-ellipsize",
                      "companyName",
                      companyNameClass,
                    )}
                  >
                    {companyName}
                  </div>
                </div>
                <div className={classNames("chevron", iconContainer)}>
                  <PopoverNext
                    {...popoverPropsToNextProps({
                      ...popOverProps,
                      portalClassName: classNames("popOver navProfilePopover", portalClassName),
                      usePortal,
                      onClose: () =>
                        this.setState({
                          isOpen: false,
                        }),
                      interactionKind: PopoverInteractionKind.CLICK,
                      content: menuList && this.renderMenu(),
                      position: popOverPosition,
                      minimal: true,
                    })}
                  >
                    <MoreHorizontalIcon intent={Intent.PRIMARY} />
                  </PopoverNext>
                </div>
              </div>
            </div>
          )}
          {!isExpanded && (
            <div className={classNames("userInitial", userInitial)}>
              <span>{withUserInitial ? getInitialsFromName(name) : name}</span>
            </div>
          )}
        </>
      </div>
    );
  };
}

NavProfile.propTypes = {
  /**
   *  Props to display name of the user in profile
   */
  name: PropTypes.string.isRequired,
  /**
   *  Props to display name of the company in profile
   */
  companyName: PropTypes.string.isRequired,
  /**
   *  function to validate the menu is active or not
   */
  isMenuActive: PropTypes.func.isRequired,
  /**
   *  Function to handle the event of pin and unpin
   */
  onToggleButtonClick: PropTypes.func.isRequired,
  /**
   *  Boolean props to make footer aware of Navbar is expanded
   */
  isExpanded: PropTypes.bool.isRequired,
  /**
   *  Support for bluprintjs prop to add support of portal to popover
   */
  usePortal: PropTypes.bool,
  /**
   *  Props to decide upon using initial to be used on collapsed view
   */
  withUserInitial: PropTypes.bool,
  /**
   *  Position of pop over menu
   */
  popOverPosition: PropTypes.oneOf([...Object.values(Position)]),
  /**
   *  Icon Position in the menu item
   */
  iconPosition: PropTypes.oneOf(["left", "right"]),
  /**
   *  List of classnames to add customization to component tree
   */
  classNames: PropTypes.shape({
    container: PropTypes.string,
    profileContainer: PropTypes.string,
    portalClassName: PropTypes.string,
    userName: PropTypes.string,
    companyName: PropTypes.string,
    iconContainer: PropTypes.string,
  }),
  /**
   *  Array of objects to be shown on profile click
   */
  menuList: PropTypes.array,
};

NavProfile.defaultProps = {
  menuList: [],
  classNames: {},
  iconPosition: "left",
  usePortal: true,
  withUserInitial: false,
  popOverPosition: Position.TOP_RIGHT,
};

export default NavProfile;
