import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import {
  Boundary,
  Classes,
  Menu,
  OverflowList,
  PopoverNext,
  Position,
  popoverPropsToNextProps,
} from "@blueprintjs/core";
import * as Icons from "../assets/icon";
import MenuItem from "./MenuItem";

const { ChevronRightIcon } = Icons;

export default class Breadcrumb extends React.PureComponent {
  gotoLink = (path) => {
    this.props.handleRedirect(path);
  };

  renderBreadcrumb = (props, index) => {
    if (props.path != null) {
      return (
        <li key={index}>
          <div className="breadCrumbItem" onClick={() => this.gotoLink(props.path)}>
            {props.name && props.name}
          </div>
          {this.props.nextIcon}
        </li>
      );
    }
    return (
      <li className="currentBreadCrumb" key={index}>
        {props.name && props.name}
      </li>
    );
  };

  renderOverflow = (items) => {
    const position = Position.BOTTOM_RIGHT;
    const orderedItems = items.slice().reverse();
    const menuItems = orderedItems
      .filter((item) => item.name)
      .map((item, index) => (
        <MenuItem
          className={"menuItem overflowMenuItems"}
          text={item.name}
          onClick={() => this.gotoLink(item.path)}
          key={index}
        />
      ));
    return (
      <li>
        <PopoverNext
          {...popoverPropsToNextProps({
            minimal: true,
            position,
            popoverClassName: "popOver",
            content: <Menu className="menu">{menuItems}</Menu>,
          })}
        >
          <span className={Classes.BREADCRUMBS_COLLAPSED} />
        </PopoverNext>
      </li>
    );
  };

  render() {
    const { links, style, isLoading } = this.props;
    return (
      <div className={`col-12 clearfix breadCrumbWrapper`}>
        <div className={`col-12 clearfix breadCrumbContainer`} style={style}>
          <OverflowList
            minVisibleItems={1}
            className={classNames(Classes.BREADCRUMBS, {
              breadcrumbSkeleton: isLoading,
            })}
            observeParents={true}
            collapseFrom={Boundary.START}
            items={links}
            overflowRenderer={this.renderOverflow}
            visibleItemRenderer={this.renderBreadcrumb}
          />
        </div>
      </div>
    );
  }
}

Breadcrumb.propTypes = {
  links: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string,
      path: PropTypes.string,
    }),
  ).isRequired,
  handleRedirect: PropTypes.func,
  nextIcon: PropTypes.node,
};

Breadcrumb.defaultProps = {
  isLoading: false,
  nextIcon: <ChevronRightIcon />,
};
