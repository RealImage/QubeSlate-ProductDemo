import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import NavMenuItem from "./NavMenuItem";
import NavMenuAccordion from "./NavMenuAccordion";
import Footer from "./Footer";

export class NavigationBar extends Component {
  isMenuActive = (paths) => {
    const { location } = this.props;
    return paths?.some((path) => location.pathname && location.pathname.indexOf(path) === 0);
  };

  renderNavMenuAccordion = (menu, id) => {
    const { isExpanded, isHovered, location, history, handleExpand } = this.props;
    const isExpandedNav = isExpanded || isHovered;
    return (
      <NavMenuAccordion
        key={id}
        name={menu.name}
        isExpanded={isExpandedNav}
        menuList={menu.menuList}
        accordionId={menu.accordionId}
        location={location}
        history={history}
        handleExpand={handleExpand}
        validateActiveRoute={this.isMenuActive}
        classNames={this.props.classNames}
      />
    );
  };

  renderNavMenuItem = (menu, id) => {
    const { handleExpand, isExpanded, isHovered, history } = this.props;
    const isExpandedNav = isExpanded || isHovered;
    return (
      <NavMenuItem
        key={id}
        handleExpand={handleExpand}
        isSelected={this.isMenuActive(Array.isArray(menu.route) ? menu.route : [menu.route])}
        isExpanded={isExpandedNav}
        name={menu.name}
        route={Array.isArray(menu.route) ? menu.route : menu.route[0]}
        openNewTab={menu.openNewTab}
        history={history}
        classNames={this.props.classNames}
        menuId={menu.menuId}
      />
    );
  };

  renderNavigationItems = () => {
    const { menuItemList } = this.props;
    return menuItemList?.map((menuItem, key) => {
      if (menuItem?.type === "navMenuAccordion") return this.renderNavMenuAccordion(menuItem, key);
      return this.renderNavMenuItem(menuItem, key);
    });
  };

  handleLogoEvent = () => {
    this.props.handleExpand(false);
    this.props.history.push(this.props.homeRoute);
  };
  renderNoAccessNavigationBar = () => {
    const { logoSmall } = this.props;
    const { navHeader = null, navContainer = null } = this.props.classNames;
    return (
      <div
        className={classNames("flex flex-column clearfix relative", "navContainer", navContainer)}
        style={{ height: "100vh" }}
      >
        <div className={classNames("flex", "navHeader", navHeader)}>
          <div>{logoSmall}</div>
        </div>
      </div>
    );
  };
  renderAuthorizedNavigationBar = () => {
    const {
      companyName,
      userName,
      isExpanded,
      handleExpand,
      isHovered,
      handlePinned,
      infoLinks,
      logoSmall,
      logoExpanded,
      footerMenuList,
      history,
      onSupportMenuClick,
      withUserInitial,
      styles,
      infoButtonText,
      supportButtonText,
    } = this.props;
    const {
      navMenuWrapper = null,
      navHeader = null,
      expandedNavContainer = null,
      navContainer = null,
    } = this.props.classNames;

    const isExpandedNav = isExpanded || isHovered;
    return (
      <div
        className={classNames(
          "flex flex-column clearfix relative",
          "navigationBarContainer",
          navContainer,
          {
            expandedNavContainer: isExpandedNav,
            [expandedNavContainer]: isExpandedNav,
          },
        )}
        style={{ height: "100vh", ...styles }}
      >
        <div
          onClick={() => handleExpand(false)}
          className={classNames("flex", "navHeader", navHeader)}
        >
          <div onClick={() => this.handleLogoEvent}>{isExpandedNav ? logoExpanded : logoSmall}</div>
        </div>
        <div className={classNames("flex", "navigationBarWrapper", navMenuWrapper)}>
          {this.renderNavigationItems()}
        </div>
        <Footer
          name={userName}
          companyName={companyName}
          isMenuActive={this.isMenuActive}
          withUserInitial={withUserInitial}
          isExpanded={isExpandedNav}
          isPinned={isExpanded}
          menuList={footerMenuList}
          infoLinks={infoLinks}
          infoButtonText={infoButtonText}
          supportButtonText={supportButtonText}
          history={history}
          classNames={this.props.classNames}
          onToggleButtonClick={() => handlePinned(!isExpanded)}
          onSupportMenuClick={onSupportMenuClick}
        />
      </div>
    );
  };
  render() {
    const { hasNoAccess } = this.props;
    return (
      <>{hasNoAccess ? this.renderNoAccessNavigationBar() : this.renderAuthorizedNavigationBar()}</>
    );
  }
}

NavigationBar.propTypes = {
  location: PropTypes.object.isRequired,
  logoExpanded: PropTypes.element.isRequired,
  logoSmall: PropTypes.element.isRequired,
  homeRoute: PropTypes.string.isRequired,
  isExpanded: PropTypes.bool.isRequired,
  isHovered: PropTypes.bool.isRequired,
  handlePinned: PropTypes.func.isRequired,
  handleExpand: PropTypes.func.isRequired,
  hasNoAccess: PropTypes.bool.isRequired,
  classNames: PropTypes.shape({
    navContainer: PropTypes.string,
    navHeader: PropTypes.string,
    expandedNavContainer: PropTypes.string,
    navMenuWrapper: PropTypes.string,
  }),
};

NavigationBar.defaultProps = {
  classNames: {},
  hasNoAccess: false,
};

export default NavigationBar;
