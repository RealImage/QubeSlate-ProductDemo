import { PureComponent } from "react";
import ReactTable, { ReactTableDefaults } from "react-table6";
import selectHOC from "react-table6/lib/hoc/selectTable";
import classNames from "classnames";
import xor from "lodash/xor";
import difference from "lodash/difference";
import includes from "lodash/includes";
import PropTypes from "prop-types";
import {
  AdjustIcon,
  SortIcon,
  SortAscendingIcon,
  SortDescendingIcon,
  CheckboxIcon,
  CheckboxIntermediateIcon,
  CheckboxSelectedIcon,
} from "../assets/icon";

const findEmptyStateCategory = (loading, columns, data) => {
  if (loading) return "loading";
  if (columns && columns.filter((c) => !c.hideIfOnlyColumn).length === 0) return "emptyColumns";
  if (data && data.length === 0) return "emptyData";
  return null;
};

const toggleSelection = (key, selection = [], onSelect) =>
  onSelect(xor(selection, [key.replace("select-", "")]));

const checkSelectAll = (selection, data, keyField) => {
  let selectAll = false;
  if (selection && data) {
    const dataIds = data.map((row) => row[keyField]);
    const filterData = dataIds.filter((key) => selection.includes(key));
    selectAll = filterData.length === dataIds.length;
  }
  return selectAll;
};

const toggleAllSelection = (selection = [], data = [], keyField, onSelect) => {
  const selectAll = checkSelectAll(selection, data, keyField);
  let cloneSelection = [...selection];
  const currentDataValues = data.map((d) => d[keyField]);

  if (!selectAll) {
    cloneSelection = [...cloneSelection, ...currentDataValues];
    cloneSelection = [...new Set(cloneSelection)];
  } else {
    cloneSelection = difference(cloneSelection, currentDataValues);
  }
  onSelect(cloneSelection);
};

const checkIndeterminateSelect = (selection, data, keyField) => {
  if (selection && selection.length !== 0 && data) {
    const dataIds = data.map((row) => row[keyField]);
    return dataIds.filter((key) => !selection.includes(key)).length > 0;
  }
  return false;
};

const modifyColumns = (cols, defaultSortable, defaultCopyable) =>
  cols.map((c) => {
    const { sortable = defaultSortable, copyable = defaultCopyable, Header } = c;
    return {
      copyable,
      ...c,
      Header: <TableHeader sortable={sortable} heading={Header} />,
    };
  });

function modifyClipboardFn(event, { columns, copyable, sortable }) {
  const modifiedColumns = modifyColumns(columns, sortable, copyable);
  const shouldIntercept =
    modifiedColumns &&
    modifiedColumns.filter((c) => c.copyable).length > 0 &&
    ["rt-td", "rt-tr", "rt-th", "wb-header", "wb-cell", "wb-text"].some(
      (c) => event && event.target && event.target.className.indexOf(c) > -1,
    );
  if (!shouldIntercept) return;
  event.preventDefault();
  const selectionText = window.getSelection().toString();
  let formattedSelectionText = "";
  if (selectionText) {
    const columnCount = modifiedColumns.filter((c) => c.copyable).length;
    const selectedParts = selectionText.split("\n");
    formattedSelectionText = selectedParts.reduce((fs, part, index) => {
      if ((index + 1) % columnCount === 0) fs += `${part}\n`;
      else fs += `${part}\t`;
      return fs;
    }, formattedSelectionText);
  }
  (event.clipboardData || window.clipboardData).setData("Text", formattedSelectionText);
}

const noop = () => {};

const emptyStateDefaultMessage = {
  loadingMessage: { heading: "Loading...", body: "Please wait while we fetch your data." },
  emptyColumnsMessage: { heading: "No Column Selected", body: "Select Columns to view the table." },
  emptyDataMessage: {
    heading: "No Data",
    body: "There seems to be no data for this filter or page.",
  },
};

const TableCheckbox = (props) => {
  const mergedProps = { showChildSelect: true, shouldHideSelect: () => false, ...props };
  if (mergedProps.shouldHideSelect(mergedProps)) return null;

  const onClick = (e) => {
    const { shiftKey } = e;
    e.stopPropagation();
    mergedProps.onClick(mergedProps.id, shiftKey, mergedProps.row);
  };

  let icon = <CheckboxIcon onClick={(e) => onClick(e)} />;

  if (mergedProps.checked) {
    icon = <CheckboxSelectedIcon onClick={(e) => onClick(e)} />;
  } else if (mergedProps.indeterminate) {
    icon = <CheckboxIntermediateIcon onClick={(e) => onClick(e)} />;
  }
  return <div className="wb-checkbox">{icon}</div>;
};

class TableHeader extends PureComponent {
  static propTypes = {
    heading: PropTypes.node,
    sortable: PropTypes.bool,
  };

  render() {
    const { heading, sortable } = this.props;
    if (!heading) {
      return null;
    }
    return (
      <div className="wb-table-header">
        <span className="wb-text">{heading}</span>
        <div className={classNames("wb-unSortedIcon", { "wb-hide": !sortable })}>
          <SortIcon />
        </div>
        <div className={classNames("wb-ascSortedIcon", { "wb-hide": !sortable })}>
          <SortAscendingIcon />
        </div>
        <div className={classNames("wb-descSortedIcon", { "wb-hide": !sortable })}>
          <SortDescendingIcon />
        </div>
      </div>
    );
  }
}

const CheckboxTable = selectHOC(ReactTable);

class TableResizer extends PureComponent {
  static propTypes = {
    children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]),
  };

  render() {
    const { children, ...rest } = this.props;
    return (
      <>
        <div className="wb-resizer-icon">
          <AdjustIcon />
        </div>
        <div className="wb-resizer" {...rest}>
          {children}
        </div>
      </>
    );
  }
}

class SelectTable extends PureComponent {
  static propTypes = {
    striped: PropTypes.bool,
    loading: PropTypes.bool,
    data: PropTypes.array.isRequired,
    columns: PropTypes.array.isRequired,
    checkboxComponent: PropTypes.func,
    toggleSelection: PropTypes.func.isRequired,
    shouldHideSelect: PropTypes.func.isRequired,
    toggleAll: PropTypes.func.isRequired,
    selectAll: PropTypes.bool,
    indeterminate: PropTypes.bool,
    isSelected: PropTypes.func.isRequired,
    expandableIndeterminate: PropTypes.func,
    style: PropTypes.object,
    loadingMessage: PropTypes.object,
    emptyColumnsMessage: PropTypes.object,
    emptyDataMessage: PropTypes.object,
    LoadingComponent: PropTypes.node,
    EmptyColumnsComponent: PropTypes.node,
    EmptyDataComponent: PropTypes.node,
    selectedBackground: PropTypes.string,
    selectedChildBackground: PropTypes.string,
    selection: PropTypes.array,
    className: PropTypes.string,
    showColumnSeparator: PropTypes.bool,
    tableClass: PropTypes.string,
  };

  static defaultProps = {
    striped: false,
    loading: false,
    selectAll: false,
    indeterminate: false,
    expandableIndeterminate: () => false,
    shouldHideSelect: () => false,
    sortable: true,
    copyable: true,
    loadingMessage: emptyStateDefaultMessage.loadingMessage,
    emptyColumnsMessage: emptyStateDefaultMessage.emptyColumnsMessage,
    emptyDataMessage: emptyStateDefaultMessage.emptyDataMessage,
    LoadingComponent: null,
    EmptyColumnsComponent: null,
    EmptyDataComponent: null,
    keyField: "id",
    checkboxComponent: (props) => <TableCheckbox {...props} />,
    selectedBackground: "",
    selectedChildBackground: "",
    data: [],
    selection: [],
    columns: [],
    showColumnSeparator: false,
    tableClass: "",
  };

  modifyClipboard = (event) => modifyClipboardFn(event, this.props);

  componentDidMount() {
    document.addEventListener("copy", this.modifyClipboard);
  }

  componentWillUnmount() {
    document.removeEventListener("copy", this.modifyClipboard);
  }

  render() {
    const {
      loading,
      toggleSelection,
      expandableIndeterminate,
      toggleAll,
      selectAll,
      indeterminate,
      isSelected,
      data,
      columns,
      checkboxComponent,
      loadingMessage,
      emptyColumnsMessage,
      emptyDataMessage,
      LoadingComponent,
      EmptyColumnsComponent,
      EmptyDataComponent,
      keyField,
      shouldHideSelect,
      showColumnSeparator,
      tableClass,
    } = this.props;

    const emptyStateCategory = findEmptyStateCategory(loading, columns, data);
    if (emptyStateCategory) {
      return (
        <EmptyState
          category={emptyStateCategory}
          loadingMessage={loadingMessage}
          emptyColumnsMessage={emptyColumnsMessage}
          emptyDataMessage={emptyDataMessage}
          LoadingComponent={LoadingComponent}
          EmptyColumnsComponent={EmptyColumnsComponent}
          EmptyDataComponent={EmptyDataComponent}
        />
      );
    }

    const checkboxProps = {
      isSelected,
      toggleSelection,
      toggleAll,
      keyField,
      selectAll,
      selectType: "checkbox",
    };

    return (
      <CheckboxTable
        manual
        column={{
          ...ReactTableDefaults.column,
          className: classNames(
            tableClass,
            "wb-cell-checkbox",
            { "wb-cell-border": showColumnSeparator },
            { "wb-cell": !showColumnSeparator },
          ),
          headerClassName: classNames(
            "wb-header-checkbox",
            { "wb-header-border": showColumnSeparator },
            { "wb-header": !showColumnSeparator },
          ),
        }}
        SelectInputComponent={(props) =>
          checkboxComponent({
            ...props,
            shouldHideSelect,
            indeterminate: expandableIndeterminate(props.row),
          })
        }
        SelectAllInputComponent={(props) =>
          checkboxComponent({
            ...props,
            indeterminate,
          })
        }
        {...this.props}
        {...checkboxProps}
        showPagination={false}
        ResizerComponent={TableResizer}
        LoadingComponent={() => <div />}
      />
    );
  }
}

class EmptyState extends PureComponent {
  static propTypes = {
    category: PropTypes.string.isRequired,
    loadingMessage: PropTypes.object.isRequired,
    emptyColumnsMessage: PropTypes.object.isRequired,
    emptyDataMessage: PropTypes.object.isRequired,
    LoadingComponent: PropTypes.node,
    EmptyColumnsComponent: PropTypes.node,
    EmptyDataComponent: PropTypes.node,
  };
  static defaultProps = {
    LoadingComponent: null,
    EmptyColumnsComponent: null,
    EmptyDataComponent: null,
  };

  render() {
    const { category, ...categoryProps } = this.props;
    const capitalizeCategory = category.toUpperCase().charAt(0) + category.substring(1);
    const categoryComponentAlias = `${capitalizeCategory}Component`;
    const categoryMessageAlias = `${category}Message`;
    const defaultMessage = emptyStateDefaultMessage[categoryMessageAlias];
    const categoryMessage = { ...defaultMessage, ...categoryProps[categoryMessageAlias] };
    const categoryComponent = categoryProps[categoryComponentAlias];
    if (categoryComponent) return categoryComponent;
    const { heading, body } = categoryMessage;
    return (
      <div className="wb-es-container">
        <div className="wb-es-heading">{heading}</div>
        {body && <div className="wb-es-body">{body}</div>}
      </div>
    );
  }
}

class Table extends PureComponent {
  static propTypes = {
    striped: PropTypes.bool,
    loading: PropTypes.bool,
    selectable: PropTypes.bool,
    data: PropTypes.array.isRequired,
    loadingMessage: PropTypes.object,
    emptyColumnsMessage: PropTypes.object,
    emptyDataMessage: PropTypes.object,
    LoadingComponent: PropTypes.node,
    EmptyColumnsComponent: PropTypes.node,
    EmptyDataComponent: PropTypes.node,
    columns: PropTypes.array.isRequired,
    style: PropTypes.object,
    className: PropTypes.string,
    selection: PropTypes.array,
    onSelect: PropTypes.func,
    keyField: PropTypes.string,
    expandedChildClassNames: PropTypes.string,
    selectedChildBackground: PropTypes.string,
    selectedChildClassNames: PropTypes.string,
    selectedBackground: PropTypes.string,
    selectedClassNames: PropTypes.string,
    onRowClick: PropTypes.func,
    onChildRowClick: PropTypes.func,
    showColumnSeparator: PropTypes.bool,
  };

  static defaultProps = {
    striped: false,
    loading: false,
    selectable: false,
    sortable: true,
    copyable: true,
    loadingMessage: emptyStateDefaultMessage.loadingMessage,
    emptyColumnsMessage: emptyStateDefaultMessage.emptyColumnsMessage,
    emptyDataMessage: emptyStateDefaultMessage.emptyDataMessage,
    LoadingComponent: null,
    EmptyColumnsComponent: null,
    EmptyDataComponent: null,
    data: [],
    selection: [],
    columns: [],
    onSelect: noop,
    onRowClick: noop,
    onChildRowClick: noop,
    keyField: "id",
    expandedChildClassNames: "",
    selectedChildBackground: undefined,
    selectedChildClassNames: "",
    selectedBackground: undefined,
    selectedClassNames: "",
    expandedList: [],
    showColumnSeparator: false,
  };

  modifyClipboard = (event) => modifyClipboardFn(event, this.props);

  componentDidMount() {
    document.addEventListener("copy", this.modifyClipboard);
  }

  componentWillUnmount() {
    document.removeEventListener("copy", this.modifyClipboard);
  }

  render() {
    const {
      loading,
      striped,
      sortable,
      copyable,
      loadingMessage,
      emptyColumnsMessage,
      emptyDataMessage,
      LoadingComponent,
      EmptyColumnsComponent,
      selectable,
      selection,
      onSelect,
      keyField,
      EmptyDataComponent,
      data,
      columns,
      style,
      className,
      expandedChildClassNames,
      selectedChildBackground,
      selectedChildClassNames,
      selectedBackground,
      selectedClassNames,
      onRowClick,
      onChildRowClick,
      showColumnSeparator,
    } = this.props;

    const emptyStateCategory = findEmptyStateCategory(loading, columns, data);
    if (emptyStateCategory) {
      return (
        <EmptyState
          category={emptyStateCategory}
          loadingMessage={loadingMessage}
          emptyColumnsMessage={emptyColumnsMessage}
          emptyDataMessage={emptyDataMessage}
          LoadingComponent={LoadingComponent}
          EmptyColumnsComponent={EmptyColumnsComponent}
          EmptyDataComponent={EmptyDataComponent}
        />
      );
    }

    const modifiedColumns = modifyColumns(columns, sortable, copyable);
    // maxHeight will force the table body to overflow and scroll (since there won't be enough room),
    // hence giving the effect of a fixed table header row.
    // Also, this allows for the table to be neatly scrolled away when the content is over.
    const tableStyle = { maxHeight: `${window.screen.height - 200}px`, ...style };
    const tableClass = classNames(className, { "-striped": striped });
    const isSelected = (value) => includes(selection, value);

    const props = {
      ...this.props,
      showPagination: false,
      style: tableStyle,
      pageSize: data.length,
      columns: modifiedColumns,
      ResizerComponent: TableResizer,
      getTrProps: (s, r) => {
        let selected = false;
        const validRow = r && r.original;
        if (!validRow) return {};
        const { original } = r;
        const checkSelection = (row) =>
          props.isSelected ? props.isSelected(row[keyField]) : isSelected(row[keyField]);
        if (original && original[keyField]) selected = checkSelection(r.original);
        const isChild = original.expandTableIdentifier;
        const isExpanded = r.original.id && props.expandedList.includes(r.original.id.toString());
        const className = classNames({
          "wb-row-hover":
            (!isChild && onRowClick !== noop) || (isChild && onChildRowClick !== noop),
          "wb-expand-row": isChild,
          "wb-expanded-parent": isExpanded,
          [expandedChildClassNames]: isChild,
          [selectedClassNames]: selected && !isChild,
          [selectedChildClassNames]: selected && isChild,
        });
        const backgroundColor = isChild ? selectedChildBackground : selectedBackground;
        return {
          className,
          style: { backgroundColor: selected ? backgroundColor : "" },
          onClick: () => {
            if (isChild) onChildRowClick(r);
            else onRowClick(r);
          },
        };
      },
    };
    if (selectable)
      return (
        <SelectTable
          isSelected={isSelected}
          selectAll={checkSelectAll(selection, data, keyField)}
          indeterminate={checkIndeterminateSelect(selection, data, keyField)}
          toggleSelection={(key) => toggleSelection(key, selection, onSelect)}
          toggleAll={() => toggleAllSelection(selection, data, keyField, onSelect)}
          showColumnSeparator={showColumnSeparator}
          tableClass={tableClass}
          {...props}
        />
      );
    return (
      <ReactTable
        manual // Change to false if not using from server side data
        column={{
          ...ReactTableDefaults.column,
          className: classNames(
            tableClass,
            { "wb-cell-border": showColumnSeparator },
            { "wb-cell": !showColumnSeparator },
          ),
          headerClassName: classNames(
            { "wb-header-border": showColumnSeparator },
            { "wb-header": !showColumnSeparator },
          ),
        }}
        {...props}
        LoadingComponent={() => <div />}
      />
    );
  }
}

export default Table;
