/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ICON_POS } from "../constants";
import BaseButton from "./BaseButton";

export default class Header extends Component {
  renderButtons(buttons) {
    return buttons.map((button, i) => {
      const { isHidden, isIconRight = false, scope, ...rest } = button;

      if (isHidden) return null;

      return (
        <div key={i} className="flex">
          <BaseButton iconPos={isIconRight ? ICON_POS.RIGHT : ICON_POS.LEFT} {...rest} />
        </div>
      );
    });
  }

  render() {
    const {
      name,
      count,
      renderRightSideComponent,
      isLoading,
      isPartialLoading,
      buttons,
      tagLine,
      activeCount,
      activeCountLabel,
      customBadge,
      headerIcon,
      className,
      bottomChild,
      withSeparator,
      withShadow = true,
    } = this.props;
    return (
      <div
        className={classNames(
          "flex flex-column col-12 clearfix",
          "headerContainer",
          { "headerContainer--withShadow": withShadow },
          className,
        )}
      >
        <div className="flex flex-wrap col-12 clearfix">
          <div className="flex flex-auto flex-wrap">
            <div className="flex header">
              <div
                className={classNames("flex headerText", {
                  headerLoading: isLoading,
                })}
              >
                {!isLoading && headerIcon && <div className="flex headerIcon">{headerIcon}</div>}
                {name && name}
              </div>
              {!isLoading && count !== null && count !== undefined && (
                <div className={`flex badgeContainer`}>
                  <span
                    className={classNames("flex headerBadge", {
                      headerLoading: isPartialLoading,
                    })}
                  >
                    {count}
                  </span>
                </div>
              )}
              {!isLoading && customBadge && <div>{customBadge}</div>}
            </div>
            {tagLine && <div className={`flex col-12 tagLine`}>{tagLine}</div>}
          </div>
          <div className={`flex headerButtonContainer`}>
            <div className="flex-auto" />
            {!isLoading && activeCount !== null && activeCount !== undefined && (
              <>
                <div className={`flex badge active`}>{activeCount}</div>
                {activeCountLabel && <span className="activeCountLabel">{activeCountLabel}</span>}
              </>
            )}
            {!isLoading && buttons && this.renderButtons(buttons)}
            {!isLoading && renderRightSideComponent && renderRightSideComponent()}
          </div>
        </div>
        {withSeparator && bottomChild && <div className="separator"></div>}
        {bottomChild}
      </div>
    );
  }
}

Header.propTypes = {
  name: PropTypes.oneOfType([PropTypes.node, PropTypes.element]),
  headerIcon: PropTypes.oneOfType([PropTypes.node, PropTypes.element]),
  count: PropTypes.number,
  activeCount: PropTypes.number,
  customBadge: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.node]),
  renderRightSideComponent: PropTypes.func,
  tagLine: PropTypes.string,
  activeCountLabel: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.node]),
  isLoading: PropTypes.bool,
  isPartialLoading: PropTypes.bool,
  buttons: PropTypes.array,
  className: PropTypes.string,
};

Header.defaultProps = {
  isLoading: false,
  isPartialLoading: false,
  withSeparator: true,
};
