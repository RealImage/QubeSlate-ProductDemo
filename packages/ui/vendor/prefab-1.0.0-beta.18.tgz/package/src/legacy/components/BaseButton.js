/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import * as Icons from "../assets/icon";
import { BUTTON_TYPE } from "../constants/BaseButton";
import { SIZE, ICON_POS } from "../constants";

/**
 * Button component supporting arbitrary HTML props for their underlying DOM element
 *
 * @component
 * <BaseButton />
 * @example
 * <BaseButton
 *    iconPos={STRING}
 *    buttonSize={STRING}
 *    buttonType={STRING}
 * />
 *
 */
class BaseButton extends Component {
  renderButtonIcon = () => {
    const { buttonSize, iconName, iconPos, buttonText, iconSize } = this.props;
    const size = buttonSize === "small" ? 20 : iconSize;
    if (Icons[iconName]) {
      const Icon = Icons[iconName];
      return (
        <span className={classNames("icon", { [iconPos]: !!buttonText })}>
          <Icon width={size} height={size} />
        </span>
      );
    }

    return null;
  };

  render() {
    const {
      iconPos,
      iconSize,
      buttonText,
      buttonSize,
      buttonType,
      iconName,
      isActive,
      className,
      disabled,
      count,
      activeSwitch,
      ...rest
    } = this.props;

    return (
      <button
        className={classNames("baseButton", className, buttonType, buttonSize, {
          active: isActive,
        })}
        onClick={rest.onClick}
        disabled={disabled}
        {...rest}
      >
        <div
          className={classNames("buttonContainer", {
            iconButton: iconName && !buttonText,
            textButton: buttonText && !iconName,
          })}
        >
          {buttonText && (
            <div
              className={classNames("text", {
                right: iconPos === "left",
                left: iconPos !== "left",
              })}
            >
              {buttonText}
              {activeSwitch && count > 0 && (
                <div className={count > 0 ? "activeCount" : ""}>{count}</div>
              )}
            </div>
          )}
          {iconName && this.renderButtonIcon()}
        </div>
      </button>
    );
  }
}

BaseButton.propTypes = {
  /**
   * Controls the position of Icon either left or right
   */
  iconPos: PropTypes.oneOf(Object.values(ICON_POS)),
  /**
   * Controls the size of button
   * Adds Styles for respective sizes
   */
  buttonSize: PropTypes.oneOf(Object.values(SIZE)),
  /**
   * Controls different versions of button that are applied visually
   */
  iconName: PropTypes.string,
  /**
   * Controls different versions of button that are applied visually
   */
  buttonType: PropTypes.oneOf(Object.values(BUTTON_TYPE)),
  /**
   * Content for the button rendered under button element
   */
  buttonText: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.node,
    PropTypes.element,
    PropTypes.object,
  ]),
  /**
   * Controls click events are non-interactive.
   */
  disabled: PropTypes.bool,
  /**
   * If set to true, the button will display in an active state
   * This adds className `active`
   */
  isActive: PropTypes.bool,
  /**
   * Controls size of icon within the button
   * Supports only 16, 20, 24
   */
  iconSize: PropTypes.oneOf([16, 20, 24]),
  /**
   * If set to true, the active count will be displayed.
   */
  activeSwitch: PropTypes.bool,
  /**
   * The count to be displayed when activeSwitch is true.
   */
  count: PropTypes.number,
};

BaseButton.defaultProps = {
  iconName: "",
  iconPos: ICON_POS.LEFT,
  buttonSize: SIZE.REGULAR,
  buttonType: BUTTON_TYPE.DEFAULT,
  disabled: false,
  isActive: false,
  iconSize: 24,
  activeSwitch: false,
  count: 0,
};

export default BaseButton;
