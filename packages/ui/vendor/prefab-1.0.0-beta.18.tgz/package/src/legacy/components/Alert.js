import { Component } from "react";
import PropTypes from "prop-types";
import { Button, Card, Elevation } from "@blueprintjs/core";
import isEmpty from "lodash/isEmpty";
import * as Icons from "../assets/icon";

const iconList = { warning: "AlertRoundedIcon", default: "InfoFilledIcon" };

class Alert extends Component {
  renderIcon = () => {
    const { iconName, type } = this.props;
    let icon = iconName;
    if (isEmpty(icon)) {
      if (!isEmpty(type)) {
        icon = iconList[type];
      } else {
        icon = iconList["default"];
      }
    }
    const AlertIcon = Icons[icon];
    return <AlertIcon className="alert-icon" />;
  };

  render() {
    const { title, bodyContent, closeAlert, showIcon, showClose, showSubText, type } = this.props;
    const typeClassNames = `alert ${type}`;
    let headerClassNames = "alert-header";
    if (showIcon) {
      headerClassNames += " has-icon";
    }
    if (showClose) {
      headerClassNames += " has-close";
    }
    return (
      <Card interactive={false} elevation={Elevation.ONE} className={typeClassNames}>
        <div className={headerClassNames}>
          {showIcon && this.renderIcon()}
          {title && <div className="alert-heading">{title}</div>}
          {showSubText && !title && <span className="alert-body-wrapper">{bodyContent}</span>}
          {showClose && <Button icon="cross" className="alert-cross" onClick={closeAlert} />}
        </div>
        {showSubText && title && (
          <div className="alert-body-wrapper">
            <div className="alert-body">{bodyContent}</div>
          </div>
        )}
      </Card>
    );
  }
}

Alert.propTypes = {
  title: PropTypes.string,
  bodyContent: PropTypes.string,
  closeAlert: PropTypes.func,
  showIcon: PropTypes.bool,
  showClose: PropTypes.bool,
  showSubText: PropTypes.bool,
  type: PropTypes.string,
  iconName: PropTypes.string,
};

export default Alert;
