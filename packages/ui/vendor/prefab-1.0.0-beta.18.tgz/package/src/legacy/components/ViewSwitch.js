import PropTypes from "prop-types";
import classNames from "classnames";
import { ButtonGroup } from "@blueprintjs/core";

import { BUTTON_TYPE } from "../constants";
import BaseButton from "./BaseButton";

const SwitchButtonWithText = ({ label = "VIEW AS", buttons }) => (
  <div className="flex viewSwitchContainer">
    <div className={`flex buttonGroupLabel`}>{label}</div>
    <ButtonGroup className="toggle">
      {buttons.map(({ isActive, className, id, ...rest }, i) => {
        return (
          <BaseButton
            key={id || i}
            className={classNames(className, { activeSwitch: isActive })}
            buttonType={isActive ? BUTTON_TYPE.PRIMARY : BUTTON_TYPE.SECONDARY}
            activeSwitch={isActive}
            {...rest}
          />
        );
      })}
    </ButtonGroup>
  </div>
);

SwitchButtonWithText.propTypes = {
  label: PropTypes.string,
  buttons: PropTypes.arrayOf(
    /**
     * Uses all the Props related to Base Button
     */
    PropTypes.shape({
      id: PropTypes.string,
      className: PropTypes.string,
      buttonText: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.node,
        PropTypes.element,
        PropTypes.object,
      ]),
      isActive: PropTypes.bool,
      iconName: PropTypes.string,
    }),
  ).isRequired,
};

export default SwitchButtonWithText;
