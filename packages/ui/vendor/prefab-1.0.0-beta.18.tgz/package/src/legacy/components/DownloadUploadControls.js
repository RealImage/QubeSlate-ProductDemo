import { useRef } from "react";
import PropTypes from "prop-types";
import ActionMenu from "./ActionMenu";
import BaseButton from "./BaseButton";

function UploadButton({
  onUpload,
  children,
  accept,
  isUploading,
  multiple = false,
  inputProps = {},
}) {
  const fileInput = useRef(null);

  const handleUpload = (e) => {
    const { files } = e.target;
    if (files.length !== 0) {
      if (onUpload) onUpload(e.target.files[0]);
    }
  };

  return (
    <>
      <BaseButton
        buttonText={children}
        iconName={isUploading ? "LoadingSpinner" : "UploadIcon"}
        iconSize={20}
        disabled={isUploading}
        onClick={() => fileInput.current.click()}
      />
      <input
        ref={fileInput}
        hidden
        id="upload_file"
        name="upload_file"
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={handleUpload}
        {...inputProps}
      />
    </>
  );
}

UploadButton.propTypes = {
  onUpload: PropTypes.func,
  children: PropTypes.node,
  accept: PropTypes.string,
  isUploading: PropTypes.bool,
  multiple: PropTypes.bool,
  inputProps: PropTypes.object,
};

function DownloadUploadControls({
  downloadOptions,
  onDownload,
  onUpload,
  isUploading = false,
  isDownloading = false,
  uploadAccept = ".csv",
  uploadText = "Upload CSV",
  uploadMultiple = false,
  uploadInputProps = {},
  showDownload = true,
  showUpload = true,
}) {
  return (
    <div className="download-upload-controls">
      <div className="download-upload-controls__container">
        {showDownload && (
          <ActionMenu
            popOverProps={{
              portalClassName: "download-upload-menu actionMenuPortal minimal",
            }}
            iconList={[
              {
                id: "download",
                text: "Download",
                buttonType: "default",
                iconPos: "right",
                iconSize: 20,
                iconName: isDownloading ? "LoadingSpinner" : "ChevronDownIcon",
                disabled: isDownloading,
                dropdown: (downloadOptions || []).map((option) => ({
                  text: option.text,
                  onClick: () => onDownload?.(option.id),
                })),
              },
            ]}
          />
        )}
        {showUpload && (
          <UploadButton
            accept={uploadAccept}
            onUpload={onUpload}
            isUploading={isUploading}
            multiple={uploadMultiple}
            inputProps={uploadInputProps}
          >
            {uploadText}
          </UploadButton>
        )}
      </div>
    </div>
  );
}

DownloadUploadControls.propTypes = {
  downloadOptions: PropTypes.array,
  onDownload: PropTypes.func,
  onUpload: PropTypes.func,
  isUploading: PropTypes.bool,
  isDownloading: PropTypes.bool,
  uploadAccept: PropTypes.string,
  uploadText: PropTypes.string,
  uploadMultiple: PropTypes.bool,
  uploadInputProps: PropTypes.object,
  showDownload: PropTypes.bool,
  showUpload: PropTypes.bool,
};

export default DownloadUploadControls;
