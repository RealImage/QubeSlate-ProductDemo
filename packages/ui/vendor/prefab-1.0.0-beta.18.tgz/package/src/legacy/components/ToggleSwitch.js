import { Switch } from "@blueprintjs/core";

const ToggleSwitch = (props) => {
  const { labelText = "", isChecked = false, onChange = () => {}, isDisabled = false } = props;
  return <Switch label={labelText} checked={isChecked} onChange={onChange} disabled={isDisabled} />;
};

export default ToggleSwitch;
