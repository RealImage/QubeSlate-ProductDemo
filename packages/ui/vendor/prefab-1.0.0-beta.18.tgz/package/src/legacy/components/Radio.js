import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

import { RadioButtonSelectedIcon, RadioButtonUnselectedIcon, AdjustIcon } from "../assets/icon";

/**
 * A radio input allows the user to select one option from a group of options.
 *
 * @component
 *
 * ```<Radio />```
 *
 * @example
 *
 * `<Radio
 *    value={STRING},
 *    selectedValue={BOOLEAN},
 *    onChange={FUNCTION},
 *    label={STRING},
 *    disabled={BOOLEAN},
 *    iconProps={OBJECT}
 *    className={STRING}
 * />`
 *
 */
class Radio extends Component {
  render() {
    const {
      iconProps,
      onChange,
      selectedValue,
      label,
      loading,
      disabled,
      className,
      DragDropIcon,
    } = this.props;

    const radioSelected = <RadioButtonSelectedIcon {...iconProps} />;
    const radioUnselected = <RadioButtonUnselectedIcon {...iconProps} />;
    const handleClick = () => {
      if (!disabled) {
        onChange();
      }
    };
    return (
      <div
        className={classNames(className, "col-12", "radio-input", {
          notAllowed: disabled,
        })}
      >
        <div
          className={classNames("flex", {
            skeletonLoader: loading,
            radio_container: !loading,
            disabled: disabled,
          })}
          onClick={handleClick}
        >
          {DragDropIcon && <AdjustIcon className="adjustIcon" />}
          <div className="radio">{selectedValue ? radioSelected : radioUnselected}</div>
          {label && <div className="radiolabel">{label}</div>}
        </div>
      </div>
    );
  }
}

Radio.propTypes = {
  /**
   * The value of the radio input.
   */
  value: PropTypes.string.isRequired,
  /**
   * Controls the selectedValue state of the radio input.
   */
  selectedValue: PropTypes.bool.isRequired,
  /**
   * Controls the loading state of the radio input.
   */
  loading: PropTypes.bool,
  /**
   * Event handler invoked when the radio input is clicked.
   */
  onChange: PropTypes.func.isRequired,
  /**
   * Supports only string for the label.
   */
  label: PropTypes.string,
  /**
   * Disables the radio input and makes it non-interactive.
   */
  disabled: PropTypes.bool,
};

Radio.defaultProps = {
  loading: false,
  disabled: false,
  label: "",
};

export default Radio;
