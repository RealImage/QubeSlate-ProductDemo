/* eslint-disable @typescript-eslint/no-unused-vars */
import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import MultiSelectInput from "../MultiSelectInput";
import BaseButton from "../BaseButton";

class MultiSelectFilterSection extends Component {
  render() {
    const { containerClassName, selected, label, onFilterChange, onFilterClear, ...rest } =
      this.props;

    return (
      <div className={classNames("bordered multiselect", containerClassName)}>
        <MultiSelectInput selectedItems={selected} onMenuItemSelect={onFilterChange} {...rest} />
        {selected.length > 0 && (
          <div className="selectedList">
            {selected.map((tag) => (
              // <Checkbox
              //   key={tag.id}
              //   checked
              //   label={tag.displayName}
              //   onChange={() => onFilterChange(tag)}
              // />
              <div className="selected-items__chip" key={tag.id}>
                <span className="selected-items__chip__text">{tag.displayName}</span>
                <BaseButton
                  className="selected-items__chip__icon"
                  iconName="CancelRoundedIcon"
                  buttonType="secondary"
                  onClick={() => onFilterChange(tag)}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }
}

MultiSelectFilterSection.propTypes = {
  containerClassName: PropTypes.string,
  selected: PropTypes.array,
  onFilterChange: PropTypes.func.isRequired,
};

MultiSelectFilterSection.defaultProps = {
  containerClassName: "",
  selected: [],
};

export default MultiSelectFilterSection;
