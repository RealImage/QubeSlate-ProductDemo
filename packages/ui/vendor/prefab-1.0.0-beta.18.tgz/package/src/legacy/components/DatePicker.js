import cx from "classnames";
import { DatePicker as BlueprintDatePicker } from "@blueprintjs/datetime";

/**
 * DatePicker component
 * @param {import("@blueprintjs/datetime").DatePickerProps} props
 */
export default function DatePicker(props) {
  const { className, ...rest } = props;

  return <BlueprintDatePicker className={cx("pf-datepicker", className)} {...rest} />;
}
