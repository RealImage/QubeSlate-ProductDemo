import { Component } from "react";
import PropTypes from "prop-types";
import { Collapse } from "@blueprintjs/core";
import classNames from "classnames";
import { ChevronUpIcon, ChevronDownIcon } from "../../assets/icon.js";
import NavMenuItem from "./NavMenuItem";

/**
 * Component for Navigation bar to expand and collapse.
 *
 * @component <NavMenuAccordion />
 *
 * @example
 *
 * return (
 *  <NavMenuAccordion
 *    key={any}
 *    name={String}
 *    isExpanded={Boolean}
 *    menuList={Array}
 *    location={Object}
 *  />
 * )
 *
 */
export class NavMenuAccordion extends Component {
  state = { isOpen: true };

  toggleMenuAccordion = () => this.setState({ isOpen: !this.state.isOpen });

  renderMenu(menuItems) {
    const { isExpanded, handleExpand, history, validateActiveRoute } = this.props;
    return menuItems.map((menu, i) => {
      return (
        <NavMenuItem
          key={i}
          {...menu}
          route={Array.isArray(menu.route) ? menu.route[0] : menu.route}
          isExpanded={isExpanded}
          handleExpand={handleExpand}
          history={history}
          isSelected={validateActiveRoute(Array.isArray(menu.route) ? menu.route : [menu.route])}
          classNames={this.props.classNames}
        />
      );
    });
  }

  render() {
    const { isExpanded, name, menuList, icon, validateActiveRoute, accordionId } = this.props;
    const {
      container = null,
      navWrapper = null,
      navIcon = null,
      navName = null,
    } = this.props.classNames;
    const { isOpen } = this.state;
    const NavIcon = icon ?? menuList[0].Icon;

    return (
      <>
        <div
          className={classNames("navMenuAccordionContainer", container, {
            active: !isExpanded && validateActiveRoute(menuList.map((menu) => menu.route).flat()),
            headerExpanded: isExpanded,
          })}
          onClick={this.toggleMenuAccordion}
        >
          <div className={classNames("contentWrapper", navWrapper)}>
            {NavIcon && <NavIcon className={classNames("navIcon", navIcon)} />}
            {name && (
              <div className={classNames("name", navName)} id={accordionId}>
                {name}
              </div>
            )}
          </div>
          {isExpanded && (isOpen ? <ChevronUpIcon /> : <ChevronDownIcon />)}
        </div>
        <Collapse isOpen={isOpen}>{this.renderMenu(menuList)}</Collapse>
      </>
    );
  }
}

NavMenuAccordion.propTypes = {
  /**
   *  Boolean props to make footer aware of Navbar is expanded
   */
  isExpanded: PropTypes.bool.isRequired,
  /**
   *  props to pass the user name
   */
  name: PropTypes.string.isRequired,
  /**
   *  Array of objects to be shown on profile click
   */
  menuList: PropTypes.array.isRequired,
  /**
   *  Function to check active route in the Menu
   */
  validateActiveRoute: PropTypes.func.isRequired,
  /**
   *  List of classnames to add customization to component tree
   */
  classNames: PropTypes.shape({
    container: PropTypes.string,
    navWrapper: PropTypes.string,
    navIcon: PropTypes.string,
    navName: PropTypes.string,
  }),
};

NavMenuAccordion.defaultProps = {
  classNames: {},
};

export default NavMenuAccordion;
