import { Component } from "react";
import PropTypes from "prop-types";
import moment from "moment";
import classNames from "classnames";
import { DateRangeInput } from "@blueprintjs/datetime";

export default class DateRangePicker extends Component {
  state = {
    focusDate: moment().toDate(),
  };
  static propTypes = {
    placeholder: PropTypes.string.isRequired,
    dateRange: PropTypes.array.isRequired,
    minDate: PropTypes.instanceOf(Date),
    maxDate: PropTypes.instanceOf(Date),
    handleDateChange: PropTypes.func.isRequired,
    defaultIsOpen: PropTypes.bool,
    popoverProps: PropTypes.object,
  };

  static defaultProps = {
    placeholder: "DD/MM/YYYY",
    defaultIsOpen: false,
    popoverProps: { usePortal: false },
  };

  onStartDateFocus = () => {
    this.setState({
      focusDate: this.props.dateRange[0] ? this.props.dateRange[0] : moment().toDate(),
    });
  };
  onEndDateFocus = () => {
    this.setState({
      focusDate: this.props.dateRange[1] ? this.props.dateRange[1] : moment().toDate(),
    });
  };

  render() {
    const {
      placeholder,
      handleDateChange,
      dateRange,
      minDate,
      maxDate,
      popoverProps,
      className,
      ...rest
    } = this.props;
    return (
      <DateRangeInput
        className={classNames("dateRangePicker", className, {
          drp_error: rest.error,
          drp_disabled: rest.disabled,
        })}
        dayPickerProps={{ className: "daypicker" }}
        placeholder={placeholder}
        dateFnsFormat="dd/MM/yyyy"
        shortcuts={false}
        singleMonthOnly
        allowSingleDayRange
        onChange={handleDateChange}
        contiguousCalendarMonths={false}
        value={dateRange}
        initialMonth={this.state.focusDate}
        startInputProps={{ onFocus: this.onStartDateFocus }}
        endInputProps={{ onFocus: this.onEndDateFocus }}
        minDate={minDate}
        maxDate={maxDate}
        popoverProps={popoverProps}
        {...rest}
      />
    );
  }
}
