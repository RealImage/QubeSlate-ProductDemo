export default function BreadcrumbLoading() {
  return (
    <div className={`col-12 clearfix breadCrumbWrapper`}>
      <div className={`col-12 clearfix breadCrumbContainer`}>
        <p className={"breadcrumbSkeleton"}>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</p>
      </div>
    </div>
  );
}
