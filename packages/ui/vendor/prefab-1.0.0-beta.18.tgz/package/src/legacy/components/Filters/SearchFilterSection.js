import { Component } from "react";
import PropTypes from "prop-types";
import Checkbox from "../Checkbox";
import TagSearch from "./TagSearch";

class SearchFilterSection extends Component {
  static propTypes = {
    tagType: PropTypes.string.isRequired,
    selected: PropTypes.array,
    onFilterChange: PropTypes.func.isRequired,
  };

  static defaultProps = {
    selected: [],
  };

  render() {
    const { tagType, selected, onFilterChange, placeholder, searchTags } = this.props;
    return (
      <div>
        <TagSearch
          showSubText
          tagTypes={tagType}
          placeholder={placeholder}
          onSelect={onFilterChange}
          searchTags={searchTags}
        />
        {selected.length > 0 && (
          <div className="selectedList">
            {selected.map((tag) => (
              <Checkbox
                key={tag.id}
                checked
                label={tag.displayName}
                onChange={() => onFilterChange(tag)}
              />
            ))}
          </div>
        )}
      </div>
    );
  }
}

export default SearchFilterSection;
