import PropTypes from "prop-types";
import { PopoverNext, Position, popoverPropsToNextProps } from "@blueprintjs/core";
import cx from "classnames";

/**
 * PopOver component that uses children as a trigger for displaying popover content.
 * Built on top of BlueprintJS Popover with defaults.
 *
 * @component
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - Trigger element for the popover
 * @param {React.ReactNode} props.content - Content to display inside the popover
 * @param {'auto'|'top'|'top-left'|'top-right'|'right'|'right-top'|'right-bottom'|'bottom'|'bottom-left'|'bottom-right'|'left'|'left-top'|'left-bottom'} [props.position='bottom-left'] - Position of popover relative to trigger
 * @param {boolean} [props.minimal=true] - Whether to apply minimal styling (no arrow, minimal padding)
 * @param {boolean} [props.captureDismiss=true] - Whether popover closes on outside click/escape
 * @param {boolean} [props.disabled=false] - Whether the popover is disabled
 * @param {boolean} [props.usePortal=true] - Whether to render in portal
 * @param {string} [props.contentClassName] - Additional class name(s) for the popover content wrapper
 */
const PopOver = ({ children, content, contentClassName, ...restProps }) => {
  const defaultPopoverProps = {
    position: Position.BOTTOM_LEFT,
    minimal: true,
    captureDismiss: true,
    ...restProps,
  };

  return (
    <PopoverNext
      {...popoverPropsToNextProps(defaultPopoverProps)}
      content={<div className={cx(`popover-content-wrapper`, contentClassName)}>{content}</div>}
    >
      {children}
    </PopoverNext>
  );
};

PopOver.propTypes = {
  content: PropTypes.node.isRequired,
  position: PropTypes.oneOf(Object.values(Position)),
  minimal: PropTypes.bool,
};

export default PopOver;
