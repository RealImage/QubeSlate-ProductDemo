import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { FormGroup, PopoverNext, Menu, Position, popoverPropsToNextProps } from "@blueprintjs/core";
import findIndex from "lodash/findIndex";
import { ICON_POS, BUTTON_TYPE } from "../constants";
import { ConfirmIcon } from "../assets/icon.js";
import MenuItem from "./MenuItem";
import BaseButton from "./BaseButton";
import Checkbox from "./Checkbox";
import TextInput from "./TextInput.js";
import StatusIcon from "./StatusIcon";

class Selector extends Component {
  static propTypes = {
    list: PropTypes.array.isRequired,
    selectedList: PropTypes.array,
    label: PropTypes.string,
    onSelect: PropTypes.func.isRequired,
    closeOnSelect: PropTypes.bool,
    singleSelect: PropTypes.bool,
    showLabelInButton: PropTypes.bool,
    noSelectedIcon: PropTypes.bool,
    defaultIsOpen: PropTypes.bool,
    usePortal: PropTypes.bool,
    disabled: PropTypes.bool,
    placeHolder: PropTypes.string.isRequired,
    enableCheckbox: PropTypes.bool,
    searchProps: PropTypes.object,
    hideClearSelection: PropTypes.bool,
    renderMenuContent: PropTypes.node,
    getItemColor: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
    showStatusIcon: PropTypes.bool,
    getItemShowStatusIcon: PropTypes.oneOfType([PropTypes.func, PropTypes.string]),
    fitWidthToOptions: PropTypes.bool,
  };

  static defaultProps = {
    selectedList: [],
    closeOnSelect: false,
    singleSelect: false,
    showLabelInButton: true,
    noSelectedIcon: false,
    defaultIsOpen: false,
    usePortal: true,
    disabled: false,
    enableCheckbox: false,
    getItemColor: null,
    showStatusIcon: false,
    getItemShowStatusIcon: null,
    fitWidthToOptions: false,
  };

  state = {
    contentWidth: null,
  };

  componentDidMount() {
    this.updateContentWidth();
  }

  componentDidUpdate(prevProps) {
    const shouldRecalculateWidth =
      prevProps.list !== this.props.list ||
      prevProps.placeHolder !== this.props.placeHolder ||
      prevProps.label !== this.props.label ||
      prevProps.showLabelInButton !== this.props.showLabelInButton ||
      prevProps.fitWidthToOptions !== this.props.fitWidthToOptions;

    if (shouldRecalculateWidth) {
      this.updateContentWidth();
    }
  }

  getItemDisplayText = (item) => {
    const displayValue = item?.value || item;
    return typeof displayValue === "string" || typeof displayValue === "number"
      ? String(displayValue)
      : "";
  };

  getLongestItemText = () => {
    const { list, placeHolder, label, showLabelInButton } = this.props;
    const texts = [placeHolder || "", ...list.map(this.getItemDisplayText)];

    if (showLabelInButton && label) {
      texts.push(label);
    }

    return texts.reduce((longest, current) =>
      current.length > longest.length ? current : longest,
    );
  };

  measureTextWidth = (text) => {
    if (typeof document === "undefined") {
      return text.length * 8;
    }

    if (!this.measureCanvas) {
      this.measureCanvas = document.createElement("canvas");
    }

    const context = this.measureCanvas.getContext("2d");
    if (!context) {
      return text.length * 8;
    }

    context.font = "400 14px Commissioner, sans-serif";
    return context.measureText(text).width;
  };

  updateContentWidth = () => {
    const { fitWidthToOptions } = this.props;

    if (!fitWidthToOptions) {
      if (this.state.contentWidth !== null) {
        this.setState({ contentWidth: null });
      }
      return;
    }

    const longestText = this.getLongestItemText();
    const measuredTextWidth = this.measureTextWidth(longestText);
    // 56px accounts for button paddings and chevron icon space.
    const nextWidth = Math.max(Math.ceil(measuredTextWidth + 56), 70);

    if (nextWidth !== this.state.contentWidth) {
      this.setState({ contentWidth: nextWidth });
    }
  };

  findSelectedIndex = (list, item) => {
    if (list.length === 0) return -1;
    if (item.id) return findIndex(list, item);
    return list.indexOf(item);
  };

  isEverythingSelected = (list, selectedList) => list.length === selectedList.length;

  getItemColor = (item) => {
    const { getItemColor } = this.props;
    if (!getItemColor) return null;

    if (typeof getItemColor === "function") {
      return getItemColor(item);
    }

    if (typeof getItemColor === "string") {
      return item[getItemColor];
    }

    return null;
  };

  shouldShowStatusIcon = (item) => {
    const { showStatusIcon, getItemShowStatusIcon } = this.props;

    if (showStatusIcon) return true;

    if (getItemShowStatusIcon) {
      if (typeof getItemShowStatusIcon === "function") {
        return getItemShowStatusIcon(item);
      }

      if (typeof getItemShowStatusIcon === "string") {
        return item[getItemShowStatusIcon];
      }
    }

    return false;
  };

  onItemSelect = (item) => {
    const { selectedList, singleSelect, onSelect } = this.props;
    const selected = singleSelect ? [] : [...selectedList];
    const selectedIndex = this.findSelectedIndex(selected, item);
    if (selectedIndex > -1) {
      selected.splice(selectedIndex, 1);
    } else {
      selected.push(item);
    }
    onSelect(selected);
  };

  onSelectAll = () => {
    const { selectedList, list, onSelect } = this.props;
    if (this.isEverythingSelected(list, selectedList)) onSelect([]);
    else onSelect(list);
  };

  renderMenu = () => {
    const {
      list,
      selectedList,
      singleSelect,
      closeOnSelect,
      noSelectedIcon,
      enableCheckbox,
      searchProps,
      hideClearSelection,
      renderMenuContent,
      fitWidthToOptions,
    } = this.props;

    const contentStyle =
      fitWidthToOptions && this.state.contentWidth
        ? { width: `${this.state.contentWidth}px`, minWidth: `${this.state.contentWidth}px` }
        : undefined;

    const menuStyle =
      fitWidthToOptions && this.state.contentWidth
        ? { width: "100%", minWidth: `${this.state.contentWidth}px` }
        : undefined;

    return (
      <div
        className={classNames({ "selectorMenu-with-checkbox": enableCheckbox })}
        style={contentStyle}
      >
        {enableCheckbox && !!searchProps && (
          <div className="selectorMenu__search">
            <TextInput {...searchProps} />
          </div>
        )}
        {renderMenuContent}
        <Menu className="selectorMenu menu" style={menuStyle}>
          {!singleSelect && !enableCheckbox && (
            <MenuItem
              key="selectAll"
              text="Select All"
              icon={
                !noSelectedIcon && this.isEverythingSelected(list, selectedList) ? (
                  <ConfirmIcon />
                ) : (
                  ""
                )
              }
              onClick={this.onSelectAll}
              shouldDismissPopover={closeOnSelect}
            />
          )}
          {list.map((item, index) => (
            <MenuItem
              key={index}
              text={
                <div className="menuItemText">
                  {enableCheckbox && (
                    <Checkbox
                      key={item.id}
                      checked={this.findSelectedIndex(selectedList, item) > -1}
                      style={{ marginRight: 8 }}
                    />
                  )}
                  {this.shouldShowStatusIcon(item) && this.getItemColor(item) && (
                    <StatusIcon color={item.color} />
                  )}
                  <span>{item?.value || item}</span>
                </div>
              }
              className={classNames({
                menuItemSelected: this.findSelectedIndex(selectedList, item) > -1,
              })}
              icon={
                !enableCheckbox && this.findSelectedIndex(selectedList, item) > -1 ? (
                  <ConfirmIcon />
                ) : null
              }
              onClick={() => this.onItemSelect(item)}
              shouldDismissPopover={!enableCheckbox && (singleSelect || closeOnSelect)}
            />
          ))}
        </Menu>
        {enableCheckbox && !hideClearSelection && (
          <div className="clear-selection-container">
            <BaseButton
              buttonText={this.props.clearSelectionText ?? "Clear Selection"}
              buttonType={"secondary"}
              onClick={() => this.props.onSelect([])}
            />
          </div>
        )}
      </div>
    );
  };

  getSelectedText = () => {
    const { selectedList, placeHolder, showLabelInButton, label, overridePlaceholder } = this.props;

    if (overridePlaceholder) return placeHolder;

    if (selectedList.length === 0) return placeHolder;

    if (showLabelInButton) return label;

    if (selectedList.length === 1) {
      const [selectedItem] = selectedList;
      const color = this.getItemColor(selectedItem);
      if (color) {
        return (
          <div style={{ display: "flex", alignItems: "center" }}>
            <StatusIcon color={selectedItem.color} />
            <span>{selectedItem?.value || selectedItem}</span>
          </div>
        );
      }
    }

    return selectedList.map((s) => s?.value || s).join(", ");
  };

  render() {
    const {
      error,
      label,
      selectedList,
      showLabelInButton,
      defaultIsOpen,
      usePortal,
      disabled,
      className,
      buttonType,
      id,
      enableCheckbox,
      matchTargetWidth,
      fitWidthToOptions,
    } = this.props;

    const formStyle =
      fitWidthToOptions && this.state.contentWidth
        ? { width: `${this.state.contentWidth}px` }
        : undefined;

    const buttonStyle =
      fitWidthToOptions && this.state.contentWidth
        ? { width: `${this.state.contentWidth}px` }
        : undefined;

    return (
      <FormGroup
        label={!showLabelInButton && label}
        inline
        style={formStyle}
        className={classNames("selectContainer", className, {
          placeHolderColor: selectedList.length === 0,
          error,
          "selector-with-checkbox": enableCheckbox,
        })}
        disabled={disabled}
      >
        <PopoverNext
          {...popoverPropsToNextProps({
            popoverClassName: classNames("popOver", {
              "selector-fit-width-popover": fitWidthToOptions,
            }),
            usePortal,
            disabled,
            defaultIsOpen,
            content: this.renderMenu(),
            position: Position.BOTTOM_LEFT,
            minimal: true,
            matchTargetWidth,
          })}
        >
          <BaseButton
            id={id}
            iconName="ChevronDownIcon"
            iconPos={ICON_POS.RIGHT}
            buttonText={this.getSelectedText()}
            buttonType={buttonType ?? BUTTON_TYPE.DEFAULT}
            disabled={disabled}
            style={buttonStyle}
            className={classNames({ selectButton: !buttonType })}
          />
        </PopoverNext>
      </FormGroup>
    );
  }
}

export default Selector;
