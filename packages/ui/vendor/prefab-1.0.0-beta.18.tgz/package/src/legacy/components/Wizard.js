import PropTypes from "prop-types";
import {
  Number1Icon,
  Number2Icon,
  Number3Icon,
  Number4Icon,
  Number5Icon,
  CircleDashedIcon,
  ConfirmCircleFilledIcon,
} from "../assets/icon";

const Icons = {
  0: Number1Icon,
  1: Number2Icon,
  2: Number3Icon,
  3: Number4Icon,
  4: Number5Icon,
};

const Wizard = ({ steps, current, onChange, ordered = false }) => {
  return (
    <div className="wizard_container">
      {steps.map((step, index) => (
        <>
          <Step
            {...step}
            index={index}
            current={current}
            onChange={onChange}
            showNumber={ordered}
          />
          {index + 1 !== steps.length && (
            <div className={`connection ${index < current ? `active` : ``}`}></div>
          )}
        </>
      ))}
    </div>
  );
};

const Step = ({ status, title, index, current, onChange, showNumber }) => {
  const NumberIcon = Icons[index];
  const handleStepClick = () => {
    if (onChange) onChange(index);
  };
  const stepStatus = calculateStatus(status, current, index);
  return (
    <div className={`step ${stepStatus} ${onChange && `clickable`}`} onClick={handleStepClick}>
      <div className="current_state_icon">
        {stepStatus === "finish" ? (
          <ConfirmCircleFilledIcon width={"20px"} height={"20px"} />
        ) : stepStatus === "skip" ? (
          <CircleDashedIcon width={"20px"} height={"20px"} />
        ) : showNumber ? (
          <NumberIcon width={"20px"} height={"20px"} />
        ) : (
          <CircleDashedIcon width={"20px"} height={"20px"} className="undiscovered-step" />
        )}
      </div>

      <div className="step_title">{title}</div>
    </div>
  );
};

const calculateStatus = (status, current, index) => {
  if (status) {
    return status;
  }
  if (current === index) {
    return "active";
  }
  if (current > index) {
    return "finish";
  }
  return "inactive";
};

Step.propTypes = {
  status: PropTypes.oneOf(["active", "inactive", "finish"]),
  title: PropTypes.string.isRequired,
  index: PropTypes.number.isRequired,
  onChange: PropTypes.func,
};

Wizard.propTypes = {
  steps: PropTypes.arrayOf(PropTypes.shape(Step.propTypes)),
  current: PropTypes.number,
  onChange: PropTypes.func,
};

export default Wizard;
