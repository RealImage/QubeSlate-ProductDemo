import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Tab, Tabs } from "@blueprintjs/core";

class TabView extends Component {
  renderTitle = (name, count, isActive) => {
    if (this.props.customTitleRenderer) return this.props.customTitleRenderer();
    return (
      <div className="flex tabTitle">
        <div className={`flex tabName`}>{name}</div>
        {count && (
          <div
            className={classNames("flex", {
              activeTabCount: isActive,
              tabCount: !isActive,
            })}
          >
            {count}
          </div>
        )}
      </div>
    );
  };

  render() {
    const {
      animate,
      onChange,
      selectedTabId,
      tabs,
      large,
      renderActiveTabPanelOnly,
      hideSingleTab,
      isLoader,
    } = this.props;
    return (
      <Tabs
        className={classNames("tabs", {
          hidePanel: hideSingleTab && tabs.length === 1,
          loaderContainer: isLoader,
        })}
        animate={animate}
        id="tab"
        size={large ? "large" : "medium"}
        onChange={onChange}
        selectedTabId={selectedTabId}
        renderActiveTabPanelOnly={renderActiveTabPanelOnly}
      >
        {tabs
          .filter((tab) => !tab.isHidden)
          .map((tab, i) => (
            <Tab
              key={i}
              id={tab.id}
              title={
                !hideSingleTab && this.renderTitle(tab.title, tab.count, selectedTabId === tab.id)
              }
              panel={tab.panel}
            />
          ))}
      </Tabs>
    );
  }
}

TabView.propTypes = {
  tabs: PropTypes.array.isRequired,
  onChange: PropTypes.func.isRequired,
  customTitleRenderer: PropTypes.func,
  animate: PropTypes.bool,
  renderActiveTabPanelOnly: PropTypes.bool,
  hideSingleTab: PropTypes.bool,
  isLoader: PropTypes.bool,
};

TabView.defaultProps = {
  animate: true,
  large: true,
  renderActiveTabPanelOnly: true,
  hideSingleTab: false,
  isLoader: false,
  customTitleRenderer: null,
};

export default TabView;
