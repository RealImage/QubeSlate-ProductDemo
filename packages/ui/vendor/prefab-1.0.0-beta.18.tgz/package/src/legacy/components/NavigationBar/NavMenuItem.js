import { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";

/**
 * Component for Navigation bar to display profile details and menu.
 *
 * @component <NavMenuItem />
 *
 * @example
 *
 * return (
 *   <NavMenuItem
 *      name={String}
 *      badge={Number}
 *      route={String}
 *    />
 * )
 *
 */
export class NavMenuItem extends Component {
  formatNumber = () => {
    const { badge, isExpanded } = this.props;
    if (999999 < badge) {
      return `${badge.toString().slice(0, 6)}+`;
    }
    return !isExpanded ? badge : badge.toLocaleString();
  };

  handleClick = () => {
    const { route, openNewTab, handleExpand, history } = this.props;
    handleExpand(false);
    if (openNewTab) {
      window.open(route, "_blank");
    } else {
      history.push(route);
    }
  };

  render() {
    const { isSelected, isExpanded, name, badge, persistentBadge, menuId } = this.props;
    const {
      container = null,
      menuWrapper = null,
      menuName = null,
      badge: badgeClass = null,
      selectedMenu = null,
      persistentBadge: persistentBadgeClass = null,
    } = this.props.classNames;
    return (
      <div className={classNames("navMenuItemContainer", container)} onClick={this.handleClick}>
        <div
          className={classNames(
            "flex cursor relative",
            "menuWrapper",
            menuWrapper,
            isSelected && "selectedMenu",
            isSelected && selectedMenu,
          )}
        >
          {isExpanded && name && (
            <span className={classNames("h5, flex-auto", "menuText", menuName)} id={menuId}>
              {name}
            </span>
          )}
          {isExpanded && badge > 0 && (
            <span
              className={classNames(
                "h6",
                "badge",
                persistentBadge && "red",
                badgeClass,
                persistentBadgeClass,
              )}
            >
              {this.formatNumber()}
            </span>
          )}
        </div>
      </div>
    );
  }
}

NavMenuItem.propTypes = {
  /**
   *  History object to make route change
   */
  history: PropTypes.object.isRequired,
  isSelected: PropTypes.bool.isRequired,
  /**
   *  Boolean props to make footer aware of Navbar is expanded
   */
  isExpanded: PropTypes.bool.isRequired,
  /**
   *  props to display name of the strings
   */
  name: PropTypes.string.isRequired,
  /**
   *  Route path for the nav element
   */
  route: PropTypes.string.isRequired,
  /**
   *  Function to handle expand
   */
  handleExpand: PropTypes.func,
  /**
   *  Numeric value to display along with the name
   */
  badge: PropTypes.number,
  /**
   * Boolean value to mention if the route/url has to open in new windows
   */
  openNewTab: PropTypes.bool,
  /**
   *  List of classnames to add customization to component tree
   */
  classNames: PropTypes.shape({
    container: PropTypes.string,
    profileContainer: PropTypes.string,
    portalClassName: PropTypes.string,
    userName: PropTypes.string,
    companyName: PropTypes.string,
    iconContainer: PropTypes.string,
  }),
};

NavMenuItem.defaultProps = {
  badge: 0,
  persistentBadge: false,
  classNames: {},
  openNewTab: false,
};

export default NavMenuItem;
