/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { Component } from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { SEARCH_TAG_TYPES } from "../constants";
import TablePagination from "./TablePagination";
import TagSearch from "./Filters/TagSearch";
import BaseButton from "./BaseButton";
import ColumnSelector from "./ColumnSelector";
import TextInput from "./TextInput";
import MultiSelectInput from "./MultiSelectInput";
import DateRangePicker from "./DateRangePicker";
import Selector from "./Selector";
import MultiLevelSelector from "./MultiLevelSelector";
import DownloadUploadControls from "./DownloadUploadControls";

class TableControls extends Component {
  state = {
    isInputFocussed: false,
    width: null,
    isOpen: false,
  };

  searchBar = React.createRef();

  componentDidMount() {
    this.updateWindowDimensions();
    window.addEventListener("resize", this.updateWindowDimensions);
    const hasCustomWidth = Boolean(this.props.inputWidth);
    if (this.searchBar.current && this.props.isVariableSizeInput && !hasCustomWidth) {
      document.addEventListener("click", this.updateSearchFocusState);
    }
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updateWindowDimensions);
    const hasCustomWidth = Boolean(this.props.inputWidth);
    if (this.searchBar.current && this.props.isVariableSizeInput && !hasCustomWidth) {
      document.removeEventListener("click", this.updateSearchFocusState);
    }
  }

  updateWindowDimensions = () => {
    this.setState({ width: window.innerWidth });
  };

  updateSearchFocusState = (event) => {
    const isClickInside = this.searchBar.current.contains(event.target);
    if (isClickInside) {
      this.resizeInputWidth(true);
    } else {
      this.resizeInputWidth(false);
    }
  };

  resizeInputWidth = (isInputFocussed) => {
    if (this.state.width > 767) {
      this.setState({
        isInputFocussed,
      });
    }
  };

  handleClearSearch = (event) => {
    if (this.props.onSearchClear) {
      this.props.onSearchClear(event);
    }
  };

  cancelEdit = () => {
    this.setState({
      isOpen: false,
    });
  };

  onClose = () => {
    this.setState({
      isOpen: false,
    });
  };

  onHandleApply = () => {
    this.setState({
      isOpen: false,
    });
  };

  handleRightPanel() {
    this.setState({
      isOpen: true,
    });
  }

  onSearchFilterSelect = (...args) => {
    this.props.searchInputProps.onSearchFilterSelect(...args);
  };

  renderSearchBar = () => {
    const {
      tagTypes,
      searchType,
      multiSelectProps,
      searchInputProps: {
        placeholder,
        searchTags,
        showSubText,
        searchIcon,
        resetOnSelect,
        id,
        className,
        error,
        onFocus,
        onBlur,
        onChange,
        onKeyDown,
        inputValue,
        ...otherProps
      },
    } = this.props;

    switch (searchType) {
      case SEARCH_TAG_TYPES.TAG_SEARCH:
        return (
          <TagSearch
            tagTypes={tagTypes}
            onSelect={this.onSearchFilterSelect}
            placeholder={placeholder}
            searchTags={searchTags}
            showSubText={showSubText}
            searchIcon={searchIcon}
            resetOnSelect={resetOnSelect}
            onSearchClear={this.handleClearSearch}
            {...otherProps}
          />
        );
      case SEARCH_TAG_TYPES.MULTI_SELECT_SEARCH:
        return <MultiSelectInput {...multiSelectProps} onSearchClear={this.handleClearSearch} />;
      case SEARCH_TAG_TYPES.INPUT_SEARCH:
      default:
        return (
          <TextInput
            id={id}
            className={className}
            error={error}
            onKeyDown={onKeyDown}
            placeholder={placeholder}
            onChange={onChange}
            value={inputValue}
            onSearchClear={this.handleClearSearch}
            {...otherProps}
          />
        );
    }
  };

  render() {
    const {
      dropDownSearchProps: { selectedDropDownOption, onDropDownChange, dropDownOptionList } = {
        selectedDropDownOption: [],
        onDropDownChange: () => {},
        dropDownOptionList: [],
      },
      totalResults,
      searchBar,
      searchLabel,
      inputWidth,
      searchFilterIsStatic,
      keepDateWithSearchOnFocus,
      columnFilter,
      controlsColumnFilter,
      pagination,
      filters,
      pageNeighbors,
      pageSize,
      currentPage,
      onRowSizeChange,
      controls,
      filterPresent,
      handleFilterToggle,
      filterButtonText,
      simplePagination,
      hasMoreData,
      customDateRangePicker = null,
      dateRangePickerPresent,
      dateRange,
      minDate,
      maxDate,
      handleDateChange,
      dataRangeTitle,
      onDownload,
      downloadProgress,
      onDownloadProps,
      downloadUploadProps,
      expandCollapseAll,
      expandCollapseAllLabel,
      handleExpandCollapseAll,
      multiLevelFilterPresent,
      multiLevelSelectorProps = {},
    } = this.props;

    const hasCustomWidth = Boolean(inputWidth);
    const filterOrder = this.props.filterOrder || { search: 0, "filters-cta": 1, "date-range": 2 };

    const firstFilter = {
      isSearch: filterOrder["search"] === 0,
      isDateRange: filterOrder["date-range"] === 0,
      isFiltersCTA: filterOrder["filters-cta"] === 0,
    };

    const rightOrder = this.props.rightControlsOrder || {};
    const getRightOrder = (key) => (rightOrder[key] !== undefined ? rightOrder[key] : undefined);

    return (
      <div className="tableControlsContainer">
        <div className="section"></div>
        {this.state.isOpen && (columnFilter || controlsColumnFilter) && (
          <ColumnSelector
            selectedColumns={this.props.selectedColumns}
            reorderedColumns={this.props.reorderedColumns}
            isOpen={this.state.isOpen}
            columns={this.props.columns}
            onClose={this.onClose}
            cancelEdit={this.cancelEdit}
            onHandleApply={this.onHandleApply}
            onItemSelect={this.onItemSelect}
            onColumnFilterSelect={this.props.onColumnFilterSelect}
            resetConfig={this.props.resetColumnsConfiguration}
            header={this.props.columnSelectorHeader}
            applyText={this.props.columnSelectorApplyText}
            cancelText={this.props.columnSelectorCancelText}
          />
        )}
        <div
          className={classNames("flex clearfix col-12", "searchControlWrapper", {
            filtersActive: filters.length > 0,
            searchInputActive: !hasCustomWidth && this.state.isInputFocussed,
            isStaticDate: keepDateWithSearchOnFocus,
          })}
        >
          <div className="expandContainer">
            {searchBar && (
              <div
                className={`flex searchContainer ${firstFilter.isSearch ? "first" : ""}`}
                style={{ order: `${filterOrder["search"]}` }}
              >
                {searchLabel && <div className="search-label">{searchLabel}</div>}
                <div
                  className={classNames("searchBar", {
                    focusedSearchInput: !hasCustomWidth && this.state.isInputFocussed,
                    customWidth: hasCustomWidth,
                    outline: this.props.withExpandOutline === true,
                  })}
                  style={hasCustomWidth ? { width: inputWidth } : {}}
                  ref={this.searchBar}
                >
                  {selectedDropDownOption.length > 0 && (
                    <div className="drop-down">
                      <Selector
                        onSelect={onDropDownChange}
                        label={selectedDropDownOption[0]?.value || "Select an Item"}
                        singleSelect={true}
                        list={dropDownOptionList}
                        selectedList={selectedDropDownOption}
                        fitWidthToOptions={true}
                        usePortal={false}
                      />
                    </div>
                  )}
                  {this.renderSearchBar()}
                </div>
              </div>
            )}
            {(searchFilterIsStatic || keepDateWithSearchOnFocus) && multiLevelFilterPresent && (
              <div
                className="multi-level-filter"
                style={{ order: `${filterOrder["filters-cta"]}` }}
              >
                <MultiLevelSelector {...multiLevelSelectorProps} />
              </div>
            )}
            {(searchFilterIsStatic || !this.state.isInputFocussed) && filterPresent && (
              <div
                className={`filter ${firstFilter.isFiltersCTA ? "first" : ""}`}
                style={{ order: `${filterOrder["filters-cta"]}` }}
              >
                <BaseButton
                  iconName="FilterAdjustIcon"
                  buttonText={filterButtonText}
                  onClick={handleFilterToggle}
                />
              </div>
            )}
            {(searchFilterIsStatic || keepDateWithSearchOnFocus || !this.state.isInputFocussed) &&
              dateRangePickerPresent && (
                <div
                  className={`date-range-picker ${firstFilter.isDateRange ? "first" : ""}`}
                  style={{ order: `${filterOrder["date-range"]}` }}
                >
                  {dataRangeTitle ? <div className="date-range-title">{dataRangeTitle}</div> : null}
                  {customDateRangePicker || (
                    <DateRangePicker
                      placeholder="Pick a date"
                      dateRange={dateRange}
                      minDate={minDate}
                      maxDate={maxDate}
                      handleDateChange={handleDateChange}
                    />
                  )}
                </div>
              )}
          </div>
          {(searchFilterIsStatic || !this.state.isInputFocussed) && (
            <div className="flex controlContainer">
              {controls && (
                <div
                  className="controls"
                  style={
                    getRightOrder("controls") !== undefined
                      ? { order: getRightOrder("controls") }
                      : undefined
                  }
                >
                  {controls.map((control, i) => (
                    <div
                      key={i}
                      id={control.id}
                      className={classNames(`control ${control.id}`, control.className)}
                    >
                      <>
                        {control.title && <div className="controlTitle">{control.title}</div>}
                        {control.component({
                          openColumnSelector: () => this.handleRightPanel(),
                        })}
                      </>
                    </div>
                  ))}
                </div>
              )}
              {pagination && (
                <div className="paginationContainer">
                  <TablePagination
                    totalRecords={totalResults}
                    pageSize={pageSize}
                    pageNeighbours={pageNeighbors}
                    onPageChange={(v) => onRowSizeChange(currentPage, v)}
                    currentPage={currentPage}
                    simplePagination={simplePagination}
                    hasMoreData={hasMoreData}
                  />
                </div>
              )}
              {downloadUploadProps &&
                ((downloadUploadProps.showDownload && downloadUploadProps.onDownload) ||
                  (downloadUploadProps.showUpload && downloadUploadProps.onUpload)) && (
                  <div
                    className="download-upload-container"
                    style={
                      getRightOrder("downloadUpload") !== undefined
                        ? { order: getRightOrder("downloadUpload") }
                        : undefined
                    }
                  >
                    <DownloadUploadControls {...downloadUploadProps} />
                  </div>
                )}
              {expandCollapseAll && (
                <div className="expandCollapseContainer">
                  <BaseButton
                    buttonText={expandCollapseAllLabel}
                    onClick={handleExpandCollapseAll}
                  />
                </div>
              )}
              {columnFilter && (
                <div className="settingsIconContainer">
                  <BaseButton
                    iconName="SettingsIcon"
                    onClick={() => {
                      this.handleRightPanel();
                    }}
                  />
                  <div className="controls"></div>
                </div>
              )}
              {onDownload && (
                <div
                  className="downloadIconContainer"
                  style={downloadProgress ? { marginRight: "0" } : {}}
                >
                  <BaseButton
                    iconName="DownloadIcon"
                    onClick={() => {
                      onDownload();
                    }}
                    {...onDownloadProps}
                    style={
                      downloadProgress
                        ? { borderTopRightRadius: "0", borderBottomRightRadius: "0" }
                        : {}
                    }
                  />
                </div>
              )}
              {downloadProgress && (
                <div className="progressIconContainer">{downloadProgress()}</div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }
}

TableControls.propTypes = {
  totalResults: PropTypes.number,
  searchBar: PropTypes.bool,
  columnFilter: PropTypes.bool,
  controlsColumnFilter: PropTypes.bool,
  pagination: PropTypes.bool,
  isVariableSizeInput: PropTypes.bool,
  inputWithSelection: PropTypes.bool,
  filters: PropTypes.array,
  controls: PropTypes.array,
  searchType: PropTypes.string,
  filterPresent: PropTypes.bool,
  simplePagination: PropTypes.bool,
  hasMoreData: PropTypes.bool,
  filterButtonText: PropTypes.string,
  searchInputProps: PropTypes.shape({
    placeholder: PropTypes.string,
    searchTags: PropTypes.func,
    showSubText: PropTypes.bool,
    searchIcon: PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.node,
      PropTypes.element,
      PropTypes.object,
    ]),
    resetOnSelect: PropTypes.bool,
    id: PropTypes.string,
    className: PropTypes.string,
    error: PropTypes.string,
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
    onChange: PropTypes.func,
    onKeyDown: PropTypes.func,
    inputValue: PropTypes.string,
  }),
  tagTypes: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  resetColumnsConfiguration: PropTypes.object,
  columnSelectorHeader: PropTypes.string,
  columnSelectorApplyText: PropTypes.string,
  columnSelectorCancelText: PropTypes.string,
  onDownload: PropTypes.func,
  downloadProgress: PropTypes.func,
  onDownloadProps: PropTypes.object,
  downloadUploadProps: PropTypes.shape({
    downloadOptions: PropTypes.array,
    onDownload: PropTypes.func,
    onUpload: PropTypes.func,
    isUploading: PropTypes.bool,
    isDownloading: PropTypes.bool,
    showDownload: PropTypes.bool,
    showUpload: PropTypes.bool,
  }),
  expandCollapseAll: PropTypes.bool,
  expandCollapseAllLabel: PropTypes.string,
  handleExpandCollapseAll: PropTypes.func,
  multiLevelFilterPresent: PropTypes.bool,
  multiLevelSelectorProps: PropTypes.shape({
    filterCategories: PropTypes.array,
    selectedFilters: PropTypes.object,
    onFilterChange: PropTypes.func,
    placeHolder: PropTypes.string,
    onResetAll: PropTypes.func,
    onClearSelected: PropTypes.func,
    onSearch: PropTypes.func,
    // New state management props
    selectedCategory: PropTypes.string,
    searchQuery: PropTypes.string,
    filteredResults: PropTypes.array,
    isSearching: PropTypes.bool,
    onCategorySelect: PropTypes.func,
    onSearchQueryChange: PropTypes.func,
    onOptionToggle: PropTypes.func,
  }).isRequired,
};

TableControls.defaultProps = {
  totalResults: 0,
  pageNeighbors: 1,
  searchBar: false,
  idSelection: false,
  columnFilter: false,
  controlsColumnFilter: false,
  pagination: false,
  searchType: SEARCH_TAG_TYPES.TAG_SEARCH,
  isVariableSizeInput: true,
  controls: [],
  columns: [],
  filters: [],
  tagTypes: [],
  simplePagination: false,
  hasMoreData: false,
  onColumnFilterSelect: () => {},
  onSearchFilterSelect: () => {},
  filterPresent: false,
  filterButtonText: "Filters",
  onDownload: null,
  downloadProgress: null,
  onDownloadProps: {},
  downloadUploadProps: null,
  expandCollapseAllLabel: "expand all",
  expandCollapseAll: false,
  searchInputProps: {},
  multiLevelFilterPresent: false,
  multiLevelSelectorProps: {
    filterCategories: [],
    selectedFilters: {},
    onFilterChange: () => {},
    placeHolder: "Filters",
    onResetAll: () => {},
    onClearSelected: () => {},
    onSearch: null,
    // New state management props
    selectedCategory: null,
    searchQuery: "",
    filteredResults: [],
    isSearching: false,
    onCategorySelect: () => {},
    onSearchQueryChange: () => {},
    onOptionToggle: () => {},
  },
};
export default TableControls;
