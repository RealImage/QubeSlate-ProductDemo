import TablePagination from "./TablePagination";

const PaginationControls = ({
  totalResults,
  pageNeighbors = 1,
  simplePagination = false,
  hasMoreData = false,
  onPageChange,
  controls = [],
  currentPage,
  pageSize,
}) => {
  const handlePageChange = (newPage) => {
    onPageChange(newPage, pageSize);
  };

  return (
    <div className="pagination-controls" style={{ borderRadius: "0 0 .5rem .5rem" }}>
      <div className="controls-wrapper">
        {controls.map((control) => (
          <div key={control.id} className="control-item">
            {control.component()}
          </div>
        ))}

        <TablePagination
          totalRecords={totalResults}
          pageSize={pageSize}
          pageNeighbours={pageNeighbors}
          onPageChange={handlePageChange}
          currentPage={currentPage} // Controlled from parent
          simplePagination={simplePagination}
          hasMoreData={hasMoreData}
        />
      </div>
    </div>
  );
};

PaginationControls.propTypes = {
  // ... prop types
};

export default PaginationControls;
