import Tag from "../components/Tag";
import { CancelIcon, CircleIcon, RemoveIcon } from "../assets/icon";

const colors = [
  "default",
  "primary",
  "secondary",
  "warning",
  "constructive",
  "destructive",
  "violet",
  "orange",
  "invert",
];

/** Tag Component */
export default {
  title: "Legacy/Tag",
  component: Tag,
  argTypes: {
    children: {
      control: { type: "text" },
    },
    closeIcon: {
      control: "boolean",
    },
    size: {
      options: ["sm", "md", "lg"],
      control: { type: "radio" },
    },
    color: {
      options: colors,
      control: { type: "select" },
    },
    prefixIcon: {
      options: ["CircleIcon", "RemoveIcon"],
      mapping: {
        CircleIcon: <CircleIcon />,
        RemoveIcon: <RemoveIcon color="#CF1322" />,
      },
    },
  },
  args: {
    children: "Tag",
    closeIcon: true,
    size: "md",
    color: "default",
  },
};

export const All = ({ closeIcon, children }) => (
  <div style={{ display: "flex", gap: "1rem" }}>
    {colors.map((color) => (
      <div
        key={color}
        style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "1rem" }}
      >
        <Tag size="lg" color={color} prefixIcon={<CircleIcon />} closeIcon={closeIcon}>
          {children}
        </Tag>
        <Tag size="md" color={color} prefixIcon={<CircleIcon />} closeIcon={closeIcon}>
          {children}
        </Tag>
        <Tag size="sm" color={color} prefixIcon={<CircleIcon />} closeIcon={closeIcon}>
          {children}
        </Tag>
      </div>
    ))}
  </div>
);

export const Basic = (args) => <Tag {...args} />;

export const CustomCloseIcon = (args) => <Tag {...args} closeIcon={<CancelIcon />} />;
