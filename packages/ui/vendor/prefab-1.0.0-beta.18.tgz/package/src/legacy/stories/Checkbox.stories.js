import { action } from "storybook/actions";
import Checkbox from "../components/Checkbox";

export default {
  title: "Legacy/Checkbox",
  component: Checkbox,
  argTypes: {
    label: { control: { type: "text" } },
    loading: { control: { type: "boolean" } },
    checked: { control: { type: "boolean" } },
    disabled: { control: { type: "boolean" } },
    onChange: { control: { type: "function" } },
  },
  args: {
    label: "Select an Item",
    loading: false,
    checked: false,
    disabled: false,
    onChange: (item) => {
      action("onChange", item);
    },
  },
};

export const Basic = (args) => <Checkbox {...args} />;
export const Selected = (args) => <Checkbox {...args} checked />;
export const Loading = (args) => <Checkbox {...args} loading />;
export const Disabled = (args) => <Checkbox {...args} disabled />;
export const Multiline = (args) => (
  <div style={{ width: 200 }}>
    <Checkbox {...args} checked label={"WHITESBURG DRIVE, SUITE 102, MADISON"} />
  </div>
);
