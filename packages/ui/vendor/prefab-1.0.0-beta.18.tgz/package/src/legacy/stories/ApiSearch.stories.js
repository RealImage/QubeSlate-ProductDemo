import { action } from "storybook/actions";
import ApiSearch from "../components/ApiSearch";
import MenuItem from "../components/MenuItem";
import AutoSuggest from "../components/AutoSuggest";

const props = {
  onSelect: action("Selected an Item"),
  query: "",
  showSubText: false,
  parseResults: (data) => data,
  fetchAction: () => {
    return new Promise((resolve) =>
      resolve({
        data: [
          {
            id: "974602b6-c8f3-43a3-8f4a-0770a5b170c1",
            name: "Bajaj",
            tag: "Individual Brand",
          },
        ],
      }),
    );
  },
  disabled: false,
};

export default {
  title: "Legacy/ApiSearch",
  component: ApiSearch,
  subcomponents: { AutoSuggest, MenuItem },
  argTypes: {
    searchIconPos: {
      control: {
        type: "select",
        options: ["left", "right", "none"],
      },
    },
    showSubText: "radio",
    disabled: "radio",
  },
};

export const Basic = (args) => <ApiSearch {...props} {...args} />;
