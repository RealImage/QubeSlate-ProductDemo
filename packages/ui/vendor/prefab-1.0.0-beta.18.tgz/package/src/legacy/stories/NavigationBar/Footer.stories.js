import {
  AboutUsIcon,
  TermsofServiceIcon,
  PrivacyPolicyIcon,
  SettingsIcon,
  SupportIcon,
  ProjectorIcon,
} from "../../assets/icon.js";
import MenuItem from "../../components/MenuItem";
import Footer from "../../components/NavigationBar/Footer";
import NavProfile from "../../components/NavigationBar/NavProfile";

const Links = [
  { name: "About Us", path: "https://www.qubecinema.com/about-us", Icon: AboutUsIcon },
  {
    name: "Terms of Service",
    path: "https://www.qubecinema.com/terms-use",
    Icon: TermsofServiceIcon,
  },
  {
    name: "Privacy Policy",
    path: "https://www.qubecinema.com/privacy-policy",
    Icon: PrivacyPolicyIcon,
  },
];

const Menus = [
  {
    name: "Settings",
    route: "/settings",
    Icon: SettingsIcon,
    isIconRight: false,
  },
  {
    name: "Support",
    route: "/support",
    Icon: SupportIcon,
    isIconRight: false,
  },
  {
    name: "Profile",
    route: "/profile",
    Icon: ProjectorIcon,
    isIconRight: false,
  },
];

export default {
  title: "Legacy/Footer",
  component: Footer,
  subcomponents: { NavProfile, MenuItem },
  argTypes: {
    isMenuActive: { control: { type: "function" } },
    companyName: { control: { type: "text" } },
    name: { control: { type: "text" } },
    isExpanded: { control: { type: "boolean" } },
    menuList: { control: { type: "array" } },
    infoLinks: { control: { type: "array" } },
    onToggleButtonClick: { control: { type: "function" } },
  },
  args: {
    isMenuActive: () => false,
    companyName: "Qube Cinemas",
    name: "Raghul Jayan",
    isExpanded: true,
    menuList: Menus,
    infoLinks: Links,
    onToggleButtonClick: () => {},
  },
};

export const Basic = (args) => (
  <div id="nav">
    <div className="flex flex-column align-center col-12 clearfix">
      <Footer {...args} isExpanded={false} />
    </div>
  </div>
);

export const Expanded = (args) => (
  <div id="nav">
    <div className="flex flex-column align-center col-12 clearfix">
      <Footer {...args} isExpanded />
    </div>
  </div>
);
