import { action } from "storybook/actions";
import DownloadUploadControls from "../components/DownloadUploadControls";

export default {
  title: "Legacy/DownloadUploadControls",
  component: DownloadUploadControls,
  argTypes: {
    downloadOptions: {
      control: "object",
      description: "Array of download options with id and text",
    },
    onDownload: {
      action: "downloaded",
      description: "Callback function called when download option is selected",
    },
    onUpload: {
      action: "uploaded",
      description: "Callback function called when file is uploaded",
    },
    isUploading: {
      control: "boolean",
      description: "Shows loading state for upload button",
    },
    uploadAccept: {
      control: "text",
      description: "File accept attribute for upload input",
    },
    uploadText: {
      control: "text",
      description: "Text displayed on upload button",
    },
    showDownload: {
      control: "boolean",
      description: "Whether to show the download menu button",
    },
    showUpload: {
      control: "boolean",
      description: "Whether to show the upload button",
    },
  },
};

export const Default = (args) => <DownloadUploadControls {...args} />;
Default.args = {
  downloadOptions: [
    { id: "new", text: "New Orders" },
    { id: "inProgress", text: "In Progress Orders" },
    { id: "completed", text: "Completed Orders" },
  ],
  onDownload: action("Downloading"),
  onUpload: action("Uploading"),
  isUploading: false,
  uploadAccept: ".csv",
  uploadText: "Upload CSV",
  showDownload: true,
  showUpload: true,
};

export const CustomOptions = (args) => <DownloadUploadControls {...args} />;
CustomOptions.args = {
  downloadOptions: [
    { id: "excel", text: "Export to Excel" },
    { id: "pdf", text: "Export to PDF" },
    { id: "csv", text: "Export to CSV" },
  ],
  onDownload: action("Exporting"),
  onUpload: action("Importing"),
  uploadAccept: ".xlsx,.csv,.pdf",
  uploadText: "Import File",
};

export const Uploading = (args) => <DownloadUploadControls {...args} />;
Uploading.args = {
  downloadOptions: [
    { id: "new", text: "New Orders" },
    { id: "inProgress", text: "In Progress Orders" },
  ],
  onDownload: action("Downloading"),
  onUpload: action("Uploading"),
  isUploading: true,
  uploadText: "Uploading...",
};
