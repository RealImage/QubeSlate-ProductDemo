import { action } from "storybook/actions";
import TooltipButton from "../components/TooltipButton";

const props = {
  toolTip: "Logs",
  onClick: action("Click"),
  minimal: true,
  iconName: "LogsIcon",
};

export default {
  title: "Legacy/TooltipButton",
  parameters: { layout: "centered" },
  component: TooltipButton,
};

export const Default = () => <TooltipButton {...props} />;
export const WithText = () => (
  <TooltipButton {...props} buttonText={"View Logs"} toolTip={"Click to View"} />
);
