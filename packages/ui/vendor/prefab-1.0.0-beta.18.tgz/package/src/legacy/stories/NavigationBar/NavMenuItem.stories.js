import { NavMenuItem } from "../../components/NavigationBar/NavMenuItem";

export default {
  title: "Legacy/NavMenuItem",
  component: NavMenuItem,
  argTypes: {
    route: { control: { type: "select", options: ["/support", "/settings"] } },
    badge: { control: { type: "text" } },
    name: { control: { type: "text" } },
    isSelected: { control: { type: "boolean" } },
    isExpanded: { control: { type: "boolean" } },
  },
  args: {
    route: "/support",
    badge: "555",
    name: "Settings",
    isSelected: false,
    isExpanded: true,
  },
};

export const Basic = (args) => (
  <div id="nav">
    <div className="flex align-center col-12 clearfix">
      <NavMenuItem {...args} />
    </div>
  </div>
);

export const Multiple = (args) => (
  <div id="nav">
    <div className="flex flex-column align-center col-12 clearfix">
      <NavMenuItem {...args} />
      <NavMenuItem {...args} name={"Theatres"} />
    </div>
  </div>
);

export const Selected = (args) => (
  <div id="nav">
    <div className="flex align-center col-12 clearfix">
      <NavMenuItem {...args} isSelected />
    </div>
  </div>
);

export const Formatted = (args) => (
  <div id="nav">
    <div className="flex align-center col-12 clearfix">
      <NavMenuItem {...args} isSelected badge={18999999} />
    </div>
  </div>
);

export const persistentBadge = (args) => (
  <div id="nav">
    <div className="flex align-center col-12 clearfix">
      <NavMenuItem {...args} isSelected persistentBadge badge={18999999} />
    </div>
  </div>
);
