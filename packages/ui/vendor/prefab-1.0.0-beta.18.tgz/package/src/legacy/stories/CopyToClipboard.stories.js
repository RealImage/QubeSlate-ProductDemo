import { BaseButton } from "../components";
import CopyToClipboard from "../components/CopyToClipboard";

/** CopyToClipboard Component */
export default {
  title: "Legacy/CopyToClipboard",
  component: CopyToClipboard,
  argTypes: {
    visibleValue: { control: { type: "text" } },
    iconOnLeft: { control: { type: "boolean" } },
  },
  args: {
    visibleValue: "Copy this text",
    iconOnLeft: false,
  },
};

export const Default = (args) => <CopyToClipboard {...args} />;
export const InButton = (args) => <BaseButton buttonText={<CopyToClipboard {...args} />} />;
