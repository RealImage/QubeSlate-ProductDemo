import { action } from "storybook/actions";
import values from "lodash/values";
import TableControls from "../components/TableControls";
import ApiSearch from "../components/ApiSearch";
import TextInput from "../components/TextInput";
import { SEARCH_TAG_TYPES } from "../constants";

const tableColumns = [
  {
    id: "col1",
    Header: "col1",
    accessor: "col1",
  },
  {
    id: "col2",
    Header: "col2",
    accessor: "col2",
  },
  {
    id: "col3",
    Header: "col3",
    accessor: "col3",
  },
  {
    id: "col4",
    Header: "col3",
    accessor: "col4",
  },
];

const data = [
  {
    context: null,
    displayName: "1992",
    id: "e3f69aaf-1889-47bc-8625-f68683426c67",
    name: "Year: 1992",
    type: "movieYear",
  },
];

export default {
  title: "Legacy/TableControl",
  component: TableControls,
  subcomponents: { ApiSearch, TextInput },
  argTypes: {
    searchBar: { control: { type: "boolean" } },
    searchType: { control: { type: "select", options: values(SEARCH_TAG_TYPES) } },
    columnFilter: { control: { type: "boolean" } },
    showRowSize: { control: { type: "boolean" } },
    pagination: { control: { type: "boolean" } },
    columns: { control: { type: "object" } },
    selectedColumns: { control: { type: "object" } },
    reorderedColumns: { control: { type: "object" } },
    ps: { control: { type: "string" } },
    page: { control: { type: "string" } },
    data: { control: { type: "object" } },
    onRowSizeChange: { control: { type: "function" } },
    searchInputProps: { control: { type: "object" } },
  },
  args: {
    searchBar: true,
    searchType: SEARCH_TAG_TYPES.TAG_SEARCH,
    columnFilter: false,
    showRowSize: false,
    pagination: true,
    columns: tableColumns,
    selectedColumns: tableColumns.map((d) => d.Header),
    reorderedColumns: [],
    ps: 10,
    page: 2,
    data: {
      data: [
        {
          context: null,
          displayName: "1992",
          id: "e3f69aaf-1889-47bc-8625-f68683426c67",
          name: "Year: 1992",
          type: "movieYear",
        },
      ],
      totalCount: 200,
    },
    searchInputProps: {
      placeholder: "Search or filter by work order no, booking ref, composition name, partner name",
      onChange: action("onChange"),
      onKeyDown: action("onKeyDown"),
      showSubText: false,
      searchIcon: null,
      resetOnSelect: false,
      inputValue: "Text",
    },
  },
};

export const Basic = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls {...args} tagTypes={"movieYear"} />
  </div>
);

export const withFilters = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filters={[]}
      tagList={data}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
    />
  </div>
);

export const withItemSelected = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filterPresent
      tagList={data}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
    />
  </div>
);

export const withTextInput = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filters={data}
      tagList={data}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
      searchType={SEARCH_TAG_TYPES.INPUT_SEARCH}
      searchInputProps={{
        ...args.searchInputProps,
        onChange: (value) => action("On change Event", value),
      }}
      onSearchClear={(e) => {
        console.log("event triggered", e);
      }}
    />
  </div>
);
export const withMultiSelect = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      dropDownOptionList={[{ value: "Composition Name" }, { value: "Booking Reference" }]}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filters={data}
      tagList={data}
      isVariableSizeInput={true}
      searchType={SEARCH_TAG_TYPES.MULTI_SELECT_SEARCH}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
      suggestionList={[]}
      multiSelectProps={{
        selectedItems: [],
        suggestionList: [],
        query: "hello",
        onChange: (value) => action("On change Event", value),
      }}
      onSearchClear={(e) => {
        console.log("event triggered", e);
      }}
    />
  </div>
);

export const withSimplePagination = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filters={data}
      tagList={data}
      isVariableSizeInput={true}
      searchType={SEARCH_TAG_TYPES.MULTI_SELECT_SEARCH}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
      suggestionList={[]}
      multiSelectProps={{
        selectedItems: [],
        suggestionList: [],
        query: "hello",
        onChange: (value) => console.log("On change Event", value),
      }}
      simplePagination
      hasMoreData
      currentPage={2}
      onRowSizeChange={(currentPage, nextPage) => {
        return console.log(`currentPage: ${currentPage} \nnextPage: ${nextPage}`);
      }}
      onSearchClear={(e) => console.log("event triggered", e)}
    />
  </div>
);

export const withDropdownInSearchbox = (args) => (
  <div className="flex align-center col-12 clearfix">
    <TableControls
      {...args}
      searchLabel="Search" // Add search label
      dropDownSearchProps={{
        selectedDropDownOption: [{ value: "OFE Theatre Name" }],
        onDropDownChange: action("Dropdown Change"),
        dropDownOptionList: [
          { value: "OFE Theatre Name" },
          { value: "Booking Reference" },
          { value: "Movie Name" },
        ],
      }}
      tagTypes={[
        {
          filterType: "list",
          header: "Movies",
          tagType: "movieYear",
        },
      ]}
      filters={[]}
      tagList={data}
      searchType={SEARCH_TAG_TYPES.TAG_SEARCH}
      onFilterChange={action("Filter Change")}
      onFilterSelect={action("Filter Select")}
      searchInputProps={{
        ...args.searchInputProps,
        placeholder: "label", // Update placeholder to match design
        onChange: (value) => action("Search Input Change", value),
      }}
      onSearchClear={(e) => {
        console.log("search clear event triggered", e);
      }}
    />
  </div>
);

// Sample multi-level filter categories with API search
const multiLevelFilterCategories = [
  {
    id: "transaction-type",
    label: "Transaction Type",
    enableSearch: true,
    searchPlaceholder: "Search Transaction Type",
    // No options - will be populated by API
  },
  {
    id: "qw-distributor-name",
    label: "QW Distributor Name",
    enableSearch: true,
    searchPlaceholder: "Search by QW Distributor Name",
  },
  {
    id: "qw-delivery-status",
    label: "QW Delivery Status",
    enableSearch: true,
    searchPlaceholder: "Search Delivery Status",
  },
];

// Mock API search function for TableControls
const mockApiSearch = async (categoryId, query) => {
  console.log(`TableControls API Search: ${categoryId} - "${query}"`);

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // Mock data based on category and query
  const mockData = {
    "transaction-type": [
      { id: "acknowledged", label: "Acknowledged" },
      { id: "accepted", label: "Accepted" },
      { id: "pending", label: "Pending Fulfillment" },
      { id: "completed", label: "Completed" },
      { id: "completed-ed", label: "Completed ED" },
      { id: "completed-hd", label: "Completed HD" },
      { id: "rejected", label: "Rejected" },
      { id: "cancelled", label: "Cancelled after Completion" },
    ],
    "qw-delivery-status": [
      { id: "scheduled", label: "Scheduled" },
      { id: "out-for-delivery", label: "Out for Delivery" },
      { id: "delivered", label: "Delivered" },
      { id: "failed-delivery", label: "Failed Delivery" },
      { id: "rescheduled", label: "Rescheduled" },
    ],
    "qw-distributor-name": [
      { id: "composition-update", label: "Composition Update" },
      { id: "acknowledged", label: "Acknowledged" },
      { id: "manual", label: "Manual" },
      { id: "unapproved-compos", label: "2 Unapproved Compos" },
      { id: "studio-a", label: "Studio A", note: "Chennai, Tamil Nadu" },
      { id: "studio-b", label: "Studio B", note: "Mumbai, Maharashtra" },
    ],
  };

  const results = mockData[categoryId] || [];
  return results.filter(
    (item) =>
      item.label.toLowerCase().includes(query.toLowerCase()) ||
      (item.note && item.note.toLowerCase().includes(query.toLowerCase())),
  );
};

export const WithApiSearchMultiLevelFilter = (args) => (
  <div style={{ padding: "20px" }}>
    <h3>TableControls with API Search Multi-Level Filter</h3>
    <p>
      This example demonstrates TableControls with MultiLevelSelector that includes API-based
      search. Notice that ALL categories (&quot;Transaction Type&quot;, &quot;QW Distributor
      Name&quot;, and &quot;QW Delivery Status&quot;) have search enabled and will make API calls
      when you type in the search field.
    </p>
    <TableControls
      {...args}
      multiLevelFilterPresent={true}
      multiLevelFilterCategories={multiLevelFilterCategories}
      multiLevelSelectedFilters={{}}
      onMultiLevelFilterChange={action("Multi-Level Filter Change")}
      onMultiLevelResetAll={action("Multi-Level Reset All")}
      onMultiLevelClearSelected={action("Multi-Level Clear Selected")}
      multiLevelFilterPlaceholder="Filters"
      multiLevelFilterWidth="700px"
      multiLevelFilterHeight="400px"
      onMultiLevelSearch={mockApiSearch}
      multiLevelSearchDebounceMs={500}
      searchFilterIsStatic={true}
      searchBar={true}
      pagination={true}
      totalResults={200}
      currentPage={1}
      pageSize={10}
      onRowSizeChange={action("Row Size Change")}
    />
  </div>
);

// Mixed configuration: Some categories with static data, some with API search
const mixedFilterCategories = [
  {
    id: "transaction-type",
    label: "Transaction Type",
    options: [
      { id: "acknowledged", label: "Acknowledged" },
      { id: "accepted", label: "Accepted" },
      { id: "pending", label: "Pending Fulfillment" },
      { id: "completed", label: "Completed" },
    ],
    // No enableSearch - uses static data
  },
  {
    id: "qw-distributor-name",
    label: "QW Distributor Name",
    enableSearch: true,
    searchPlaceholder: "Search by QW Distributor Name",
    // No options - will be populated by API
  },
  {
    id: "order-status",
    label: "Order Status",
    options: [
      { id: "pending-approval", label: "Pending Approval" },
      { id: "approved", label: "Approved" },
      { id: "shipped", label: "Shipped" },
      { id: "delivered", label: "Delivered" },
    ],
    // No enableSearch - uses static data
  },
  {
    id: "qw-delivery-status",
    label: "QW Delivery Status",
    enableSearch: true,
    searchPlaceholder: "Search Delivery Status",
    // No options - will be populated by API
  },
];

export const WithMixedSearchAndStaticData = (args) => (
  <div style={{ padding: "20px" }}>
    <h3>TableControls with Mixed Search and Static Data</h3>
    <p>
      This example shows a mixed configuration where some categories use static data (no search) and
      others use API search. &quot;Transaction Type&quot; and &quot;Order Status&quot; use static
      data with checkboxes, while &quot;QW Distributor Name&quot; and &quot;QW Delivery Status&quot;
      use API search.
    </p>
    <TableControls
      {...args}
      multiLevelFilterPresent={true}
      multiLevelFilterCategories={mixedFilterCategories}
      multiLevelSelectedFilters={{}}
      onMultiLevelFilterChange={action("Multi-Level Filter Change")}
      onMultiLevelResetAll={action("Multi-Level Reset All")}
      onMultiLevelClearSelected={action("Multi-Level Clear Selected")}
      multiLevelFilterPlaceholder="Filters"
      multiLevelFilterWidth="700px"
      multiLevelFilterHeight="400px"
      onMultiLevelSearch={mockApiSearch}
      multiLevelSearchDebounceMs={500}
      searchFilterIsStatic={true}
      searchBar={true}
      pagination={true}
      totalResults={200}
      currentPage={1}
      pageSize={10}
      onRowSizeChange={action("Row Size Change")}
    />
  </div>
);
