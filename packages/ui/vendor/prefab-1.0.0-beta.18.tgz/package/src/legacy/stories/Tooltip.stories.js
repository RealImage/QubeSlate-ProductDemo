import ToolTip from "../components/ToolTip";

const props = {
  toolTip: "Tool Tip Content",
  minimal: true,
};

export default {
  title: "Legacy/Tooltip",
  parameters: { layout: "centered" },
  component: ToolTip,
};

export const Default = () => (
  <ToolTip {...props}>
    <h2>Hello World</h2>
  </ToolTip>
);
