import Breadcrumb from "../components/BreadCrumb";
import BreadcrumbLoading from "../components/BreadcrumbLoading";

const links = [
  { name: "test1", path: "/test1" },
  { name: "test2", path: "/test2" },
  { name: "test3", path: "/test3" },
  { name: "test4", path: "/test4" },
  { name: "test5", path: "/test5" },
  { name: "test6", path: "/test6" },
  { name: "current" },
];

export default {
  title: "Legacy/Breadcrumb",
  component: Breadcrumb,
};

export const Default = () => <Breadcrumb links={links} />;
export const Loading = () => <BreadcrumbLoading />;
