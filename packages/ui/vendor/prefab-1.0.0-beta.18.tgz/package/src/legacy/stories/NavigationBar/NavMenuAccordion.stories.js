import { TheatreIcon, SeatIcon, ProjectorIcon } from "../../assets/icon.js";
import MenuItem from "../../components/MenuItem";
import NavMenuAccordion from "../../components/NavigationBar/NavMenuAccordion";
import NavMenuItem from "../../components/NavigationBar/NavMenuItem";

const Menus = [
  {
    name: "Theatres",
    route: "/theatres",
    Icon: TheatreIcon,
    isIconRight: false,
    badge: 59,
  },
  {
    name: "Screens",
    route: "/screens",
    Icon: SeatIcon,
    isIconRight: false,
    badge: 100,
  },
  {
    name: "Content",
    route: "/content",
    Icon: ProjectorIcon,
    isIconRight: false,
    badge: 1000000,
    persistentBadge: true,
  },
];

export default {
  title: "Legacy/NavMenuAccordion",
  component: NavMenuAccordion,
  subcomponents: { NavMenuItem, MenuItem },
  argTypes: {
    name: { control: { type: "text" } },
    isExpanded: { control: { type: "boolean" } },
    menuList: { control: { type: "array" } },
    handleExpand: { control: { type: "function" } },
  },
  args: {
    name: "Company",
    isExpanded: true,
    menuList: Menus,
  },
};

export const Basic = (args) => (
  <div id="nav">
    <div className="flex flex-column align-center col-12 clearfix">
      <NavMenuAccordion {...args} handleExpand={() => {}} validateActiveRoute={() => {}} />
    </div>
  </div>
);
