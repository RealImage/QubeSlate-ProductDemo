import values from "lodash/values";
import { BUTTON_TYPE, SIZE, ICON_POS } from "../constants";
import * as Icons from "../assets/icon";
import BaseButton from "../components/BaseButton";

/** Button Component */
export default {
  title: "Legacy/BaseButton",
  component: BaseButton,
  argTypes: {
    buttonType: {
      control: {
        type: "select",
        options: values(BUTTON_TYPE),
      },
    },
    buttonSize: {
      control: {
        type: "select",
        options: values(SIZE),
      },
    },
    iconPos: {
      control: {
        type: "select",
        options: values(ICON_POS),
      },
    },
    iconName: {
      control: {
        type: "select",
        options: Object.keys(Icons),
      },
    },
    disabled: "radio",
  },
  args: {
    buttonType: BUTTON_TYPE.DEFAULT,
    buttonSize: SIZE.REGULAR,
    iconPos: ICON_POS.LEFT,
    iconName: Object.keys(Icons)[0],
  },
};

export const Basic = (args) => <BaseButton {...args} buttonText={"Check"} />;
