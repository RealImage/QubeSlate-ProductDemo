import moment from "moment";
import DatePicker from "../components/DatePicker";

const minDate = moment().toDate();
const maxDate = moment().add(7, "days").toDate();

/** DatePicker Component */
export default {
  title: "Legacy/DatePicker",
  component: DatePicker,
  argTypes: {
    showActionsBar: { control: { type: "boolean" } },
    highlightCurrentDay: { control: { type: "boolean" } },
    shortcuts: { control: { type: "boolean" } },
    reverseMonthAndYearMenus: { control: { type: "boolean" } },
    onChange: { control: { type: "function" } },
  },
};

export const Default = (args) => {
  return <DatePicker {...args} />;
};

export const MinAndMaxValues = (args) => {
  return <DatePicker minDate={minDate} maxDate={maxDate} {...args} />;
};

export const SelectedValues = (args) => {
  return <DatePicker defaultValue={minDate} {...args} />;
};
