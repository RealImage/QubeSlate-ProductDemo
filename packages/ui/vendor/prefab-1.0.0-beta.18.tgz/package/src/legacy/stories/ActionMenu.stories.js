import { useState } from "react";
import { action } from "storybook/actions";
import ActionMenu from "../components/ActionMenu";
import TooltipButton from "../components/TooltipButton";
import MenuItem from "../components/MenuItem";

const iconList = [
  {
    toolTip: "View",
    onClick: () => action("View Click"),
    iconName: "ViewIcon",
  },
];

/** Component for Icon Menu with its dropdown. */
export default {
  title: "Legacy/Action Menu",
  component: ActionMenu,
  subcomponents: { TooltipButton, MenuItem },
};

export const Basic = () => <ActionMenu iconList={iconList} />;
export const WithDropdown = () => (
  <ActionMenu
    iconList={[
      {
        id: "info",
        toolTip: "Info",
        iconName: "InfoFilledIcon",
        onClick: () => action("Info Click"),
      },
      {
        toolTip: "More Actions",
        iconName: "MoreVerticalIcon",
        dropdown: [
          {
            text: "Pause",
            onClick: () => action("Pause Click"),
            hideMenuItem: false,
            iconName: "PauseIcon",
          },
          {
            text: "Resume",
            onClick: () => action("Resume Click"),
            hideMenuItem: false,
            iconName: "PlayIcon",
          },
          {
            text: "Stop",
            onClick: () => action("Stop Click"),
            hideMenuItem: true,
            iconName: "PlayIcon",
          },
        ],
      },
    ]}
  />
);

export const WithCustomContent = () => {
  const [useCustomContent, setUseCustomContent] = useState(false);

  const iconListWithCustomContent = [
    {
      id: "more",
      toolTip: "More Actions",
      iconName: "MoreVerticalIcon",
      dropdown: [
        {
          text: "Edit",
          onClick: () => action("Edit Click")(),
          hideMenuItem: false,
          iconName: "EditIcon",
        },
        useCustomContent
          ? {
              customContent: (
                <div style={{ padding: "4px 8px" }}>
                  <strong style={{ color: "#1F4788" }}>Advanced Settings</strong>
                  <div style={{ fontSize: "12px", color: "#5C7080", marginTop: "2px" }}>
                    Configure advanced options
                  </div>
                </div>
              ),
              onClick: () => action("Advanced Settings Click")(),
              hideMenuItem: false,
            }
          : {
              text: "Settings",
              onClick: () => action("Settings Click")(),
              hideMenuItem: false,
              iconName: "CogIcon",
            },
        {
          text: "Delete",
          onClick: () => action("Delete Click")(),
          hideMenuItem: false,
          iconName: "TrashIcon",
        },
      ],
    },
  ];

  return (
    <div>
      <div style={{ marginBottom: "20px" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
          <input
            type="checkbox"
            checked={useCustomContent}
            onChange={(e) => setUseCustomContent(e.target.checked)}
          />
          <span>Use Custom Content</span>
        </label>
        <p style={{ fontSize: "14px", color: "#5C7080", marginTop: "8px" }}>
          Toggle to switch between standard text menu item and custom content menu item
        </p>
      </div>
      <ActionMenu iconList={iconListWithCustomContent} />
    </div>
  );
};
