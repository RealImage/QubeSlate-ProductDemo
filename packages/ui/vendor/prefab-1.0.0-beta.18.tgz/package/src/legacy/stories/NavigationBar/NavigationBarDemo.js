import { Component } from "react";
import classNames from "classnames";
import { HamburgerIcon, AboutUsIcon } from "../../assets/icon.js";
import NavigationBar from "../../components/NavigationBar/NavigationBar.js";

export class NavBarDemo extends Component {
  state = {
    isExpanded: false,
    isHovered: false,
    navAction: "collapsed",
    isMobile: window.innerWidth <= 760,
  };

  handleExpand = (isExpanded) => {
    const { isHovered } = this.state;
    this.setState({
      isExpanded,
      navAction: isExpanded ? "expanded" : "collapsed",
    });
    this.setState({
      navAction: isHovered && "hovered",
    });
  };

  handleNavBarHover = (isHovered) => {
    const { isExpanded } = this.state;
    const defaultAction = isExpanded ? "expanded" : "collapsed";
    this.setState({ navAction: isHovered ? "hovered" : defaultAction, isHovered });
  };

  renderNavigationBar = () => {
    const { isExpanded, navAction, isMobile } = this.state;
    const history = { push: null, replace: null };
    const location = { search: null, match: null };
    return (
      <NavigationBar
        {...this.props}
        withUserInitial={true}
        userName={"Raghul J"}
        companyName={"Qube Cinemas"}
        isExpanded={isExpanded}
        homeRoute={"/"}
        logoSmall={<AboutUsIcon />}
        logoExpanded={<AboutUsIcon />}
        isHovered={navAction === "hovered"}
        hasNavigation={false}
        history={history}
        location={location}
        handlePinned={(bool) => this.handleExpand(bool)}
        handleExpand={(bool) => (isMobile ? this.handleExpand(bool) : {})}
      />
    );
  };

  renderMobileHeader = () => {
    const { isExpanded } = this.state;
    return (
      <div className={classNames("mobileHeader")}>
        <div
          className={classNames("flex col-2", "menuIcon")}
          onClick={() => this.handleExpand(true)}
        >
          <HamburgerIcon />
        </div>
        {!isExpanded && (
          <div className="logo">
            <AboutUsIcon />
          </div>
        )}
      </div>
    );
  };

  render() {
    const { isExpanded, navAction, isMobile } = this.state;
    return (
      <main>
        {isMobile && this.renderMobileHeader()}
        <div
          id={isMobile ? "drawer" : "sideBar"}
          onMouseOver={() => (!isExpanded && !isMobile ? this.handleNavBarHover(true) : {})}
          onMouseLeave={() => this.handleNavBarHover(false)}
          className={classNames("sideNavContainer", navAction, {
            portal: isMobile,
          })}
        >
          {this.renderNavigationBar()}
        </div>
        {isExpanded && isMobile && (
          <div className="overlay" onClick={() => this.handleExpand(false)}></div>
        )}
        <div
          className={classNames("pageLayout", `page_${navAction}`, {
            mobile: isMobile,
          })}
          onClick={() => (isMobile ? this.handleExpand(false) : null)}
        >
          <div className={classNames("col-12", "container")}>Page gets rendered here</div>
        </div>
      </main>
    );
  }
}

export default NavBarDemo;
