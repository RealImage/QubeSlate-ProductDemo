import {
  FilmIcon,
  TheatreGalleryIcon,
  AdvertiserIcon,
  AboutUsIcon,
  TermsofServiceIcon,
  PrivacyPolicyIcon,
  SwapIcon,
  LogoutIcon,
  HeartbeatBoxIcon,
} from "../../assets/icon";
import NavigationBarV2Demo from "./NavigationBarV2Demo";

const InfoLinks = [
  { name: "About Us", path: "https://www.qubecinema.com/about-us", Icon: AboutUsIcon },
  {
    name: "Terms of Service",
    path: "https://www.qubecinema.com/terms-use",
    Icon: TermsofServiceIcon,
  },
  {
    name: "Privacy Policy",
    path: "https://www.qubecinema.com/privacy-policy",
    Icon: PrivacyPolicyIcon,
  },
];

const FooterMenus = [
  {
    name: "Switch Company",
    route: "/settings",
    Icon: SwapIcon,
    isIconRight: false,
  },
  {
    name: "Sign Out",
    route: "/support",
    Icon: LogoutIcon,
    isIconRight: false,
  },
];

const NavMenus = [
  {
    type: "navMenuAccordion",
    name: "Campaigns",
    Icon: FilmIcon,
    menuList: [
      {
        name: "Campaigns",
        route: "/acampaigns",
      },
      {
        name: "Active Campaigns",
        route: "/lactivea",
      },
      {
        name: "Theatres",
        route: "/ltheatresb",
      },
      {
        name: "Screens",
        route: "/lscreensc",
      },
      {
        name: "Actives",
        route: "/actived",
      },
      {
        name: "Archived",
        route: "/archivede",
        // openNewTab: true
      },
    ],
  },
  {
    type: "navMenuAccordion",
    name: "Theatres",
    Icon: TheatreGalleryIcon,
    menuList: [
      {
        name: "Theatres",
        route: "/qtheatres",
      },
      {
        name: "Screens",
        route: "/qscreens",
      },
    ],
  },
  {
    name: "Monitoring",
    route: "/kdm",
    Icon: HeartbeatBoxIcon,
  },
  {
    type: "navMenuAccordion",
    name: "Work Order",
    Icon: AdvertiserIcon,
    menuList: [
      {
        name: "Active",
        route: "/ractive",
      },
      {
        name: "Archived",
        route: "/tarchived",
      },
    ],
  },
];

export default {
  title: "Legacy/NavigationBarV2Demo",
  component: NavigationBarV2Demo,
};

export const Basic = (args) => (
  <NavigationBarV2Demo
    {...args}
    menuItemList={NavMenus}
    footerMenuList={FooterMenus}
    infoLinks={InfoLinks}
  />
);
