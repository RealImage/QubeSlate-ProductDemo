import { Spinner } from "@blueprintjs/core";
import * as Icons from "../assets/icon.js";
import TextInput from "../components/TextInput";

const { ContentIcon } = Icons;

export default {
  title: "Legacy/TextInput",
  component: TextInput,
  argTypes: {
    label: { control: { type: "text" } },
    id: { control: { type: "text" } },
    error: { control: { type: "boolean" } },
    errorMessage: { control: { type: "text" } },
    onChange: { action: "Input Change" },
    onFocus: { action: "Input Focus" },
    onBlur: { action: "Input Blur" },
    placeholder: { control: { type: "text" } },
    value: { control: { type: "text" } },
    disabled: { control: { type: "boolean" } },
  },
  args: {
    label: "Name",
    id: "name",
    error: false,
    errorMessage: "",
    placeholder: "Enter Name",
    value: "",
    disabled: false,
  },
};

export const Default = (props) => <TextInput {...props} />;
export const NumericInput = (props) => <TextInput {...props} onlyNumbers />;
export const LeftIcon = (props) => <TextInput {...props} leftIcon={<ContentIcon />} />;
export const RightElement = (props) => (
  <TextInput {...props} rightElement={<Spinner size={16} />} />
);
export const Error = (props) => <TextInput {...props} errorMessage="Invalid Input" error />;
export const Disabled = (props) => <TextInput {...props} disabled />;
