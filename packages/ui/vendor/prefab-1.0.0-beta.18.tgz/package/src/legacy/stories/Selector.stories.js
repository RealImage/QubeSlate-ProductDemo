import Selector from "../components/Selector";
import MenuItem from "../components/MenuItem";
import BaseButton from "../components/BaseButton";

export default {
  title: "Legacy/Selector",
  component: Selector,
  subcomponents: { BaseButton, MenuItem },
  argTypes: {
    onSelect: { control: { type: "function" } },
    label: { control: { type: "text" } },
    list: { control: { type: "array" } },
    closeOnSelect: { control: { type: "boolean" } },
    singleSelect: { control: { type: "boolean" } },
    showLabelInButton: { control: { type: "boolean" } },
    noSelectedIcon: { control: { type: "boolean" } },
    usePortal: { control: { type: "boolean" } },
    defaultIsOpen: { control: { type: "boolean" } },
  },
  args: {
    label: "Select an Item",
    list: [
      "Pulp fiction",
      "Kill Bill",
      "Kill Bill 2",
      "Django Unchained",
      "Once Upon a Time in Hollywood",
    ],
    closeOnSelect: true,
    singleSelect: true,
    showLabelInButton: true,
    noSelectedIcon: false,
    usePortal: false,
    defaultIsOpen: false,
  },
};

export const Basic = (args) => <Selector {...args} />;
export const SelectedItem = (args) => <Selector {...args} selectedList={["Pulp fiction"]} />;
export const MultiSelect = (args) => (
  <Selector {...args} selectedList={["Pulp fiction", "Kill Bill"]} singleSelect={false} />
);
export const PageSize = (args) => (
  <Selector
    {...args}
    label={"Show"}
    singleSelect={true}
    list={[10, 25, 50]}
    selectedList={[50]}
    showLabelInButton={false}
  />
);

export const WithStatusIcons = (args) => (
  <Selector
    {...args}
    showStatusIcon={true}
    list={[
      { value: "Active Item", color: "GREEN" },
      { value: "Pending Item", color: "YELLOW" },
      { value: "Inactive Item", color: "GREY" },
      { value: "Error Item", color: "RED" },
    ]}
    getItemColor="color"
  />
);
