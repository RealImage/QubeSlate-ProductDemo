import { Suggest as BlueprintSuggest } from "@blueprintjs/select";
import includes from "lodash/includes";

import AutoSuggest from "../components/AutoSuggest";
import MenuItem from "../components/MenuItem";

const list = [
  { name: "Chennai", id: "600001", type: "City" },
  { name: "Bengaluru", id: "500001", type: "City" },
  { name: "Coimbatore", id: "639102", type: "City" },
  { name: "Hyderbad", id: "456321", type: "City" },
];

/** AutoSuggest Component */
export default {
  title: "Legacy/Auto Suggest",
  component: AutoSuggest,
  subcomponents: { MenuItem, BlueprintSuggest },
  argTypes: {
    items: { control: { type: "array" } },
    selectedItem: { control: { type: "object" } },
    query: { control: { type: "text" } },
    onItemSelect: { action: "Item Selected" },
    onQueryChange: { action: "Query Change" },
    noResultText: { control: { type: "text" } },
  },
  args: {
    items: list,
    selectedItem: null,
    itemPredicate: (query, item) => item.name.toLowerCase().indexOf(query.toLowerCase()) !== -1,
    query: "query",
    noResultText: "No Result Text",
  },
};

export const Basic = (props) => (
  <AutoSuggest
    items={props.items}
    selectedItem={null}
    onItemSelect={props.onItemSelect}
    itemRenderer={(item, itemProps) => (
      <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
    )}
    inputValueRenderer={(item) => item.name}
    itemsEqual={(itemA, itemB) => itemA.id === itemB.id}
    itemPredicate={(query, item) => {
      return includes(item.name.toLowerCase(), query.toLowerCase());
    }}
    noResults={<MenuItem disabled={true} text={props.noResultText} />}
    onQueryChange={props.onQueryChange}
  />
);

export const ItemSelected = (props) => (
  <AutoSuggest
    items={props.items}
    selectedItem={props.items[0]}
    onItemSelect={props.onItemSelect}
    itemRenderer={(item, itemProps) => (
      <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
    )}
    inputValueRenderer={(item) => item.name}
    itemsEqual={(itemA, itemB) => itemA.id === itemB.id}
    itemPredicate={(query, item) => {
      return includes(item.name.toLowerCase(), query.toLowerCase());
    }}
    noResults={<MenuItem disabled={true} text={props.noResultText} />}
    onQueryChange={props.onQueryChange}
  />
);
export const withQueryString = (props) => (
  <AutoSuggest
    items={props.items}
    selectedItem={null}
    query={props.query}
    onItemSelect={props.onItemSelect}
    itemRenderer={(item, itemProps) => (
      <MenuItem onClick={itemProps.handleClick} key={item.id} text={item.name} />
    )}
    inputValueRenderer={(item) => item.name}
    itemsEqual={(itemA, itemB) => itemA.id === itemB.id}
    itemPredicate={(query, item) => {
      return includes(item.name.toLowerCase(), query.toLowerCase());
    }}
    noResults={<MenuItem disabled={true} text={props.noResultText} />}
    onQueryChange={props.onQueryChange}
  />
);
