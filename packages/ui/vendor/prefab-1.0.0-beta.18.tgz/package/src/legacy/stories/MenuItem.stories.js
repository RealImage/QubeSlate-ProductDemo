import { action } from "storybook/actions";
import { Menu } from "@blueprintjs/core";
import MenuItem from "../components/MenuItem";
import { AboutUsIcon, TermsofServiceIcon, PrivacyPolicyIcon } from "../assets/icon.js";

const Links = [
  { name: "About Us", path: "https://www.qubecinema.com/about-us", Icon: AboutUsIcon },
  {
    name: "Terms of Service",
    path: "https://www.qubecinema.com/terms-use",
    Icon: TermsofServiceIcon,
  },
  {
    name: "Privacy Policy",
    path: "https://www.qubecinema.com/privacy-policy",
    Icon: PrivacyPolicyIcon,
  },
];

export default {
  title: "Legacy/MenuItem",
  component: MenuItem,
};

export const Default = () => (
  <Menu>
    {Links.map((link, i) => (
      <MenuItem
        key={i}
        icon={link.Icon && <link.Icon />}
        text={<div>{link.name}</div>}
        onClick={action("Menu Click")}
        tagName="div"
        isIconRight={false}
        shouldDismissPopover={true}
      />
    ))}
  </Menu>
);

export const WithActiveMenu = () => (
  <Menu>
    {Links.map((link, i) => (
      <MenuItem
        active={i === 0}
        key={i}
        icon={link.Icon && <link.Icon />}
        text={<div>{link.name}</div>}
        onClick={action("Menu Click")}
        tagName="div"
        isIconRight={false}
        shouldDismissPopover={true}
      />
    ))}
  </Menu>
);
