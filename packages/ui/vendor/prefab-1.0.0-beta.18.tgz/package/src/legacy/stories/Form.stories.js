import { action } from "storybook/actions";

import { FORM_FIELD_TYPES } from "../constants";
import Form from "../components/Form";

const config = [
  {
    id: "name",
    type: FORM_FIELD_TYPES.LABEL,
    label: "Label",
    value: "Non-input value",
    size: {
      lg: 4,
      md: 4,
      sm: 6,
    },
  },
  {
    id: "name",
    type: FORM_FIELD_TYPES.DATE_RANGE_PICKER,
    placeholder: "Pick a date",
    handleDateChange: action("date picked"),
    size: {
      lg: 4,
      md: 4,
      sm: 6,
    },
  },
  {
    size: {
      lg: 12,
      md: 12,
      sm: 12,
    },
    type: FORM_FIELD_TYPES.TAG_SEARCH,
    onSelect: action("Selected an Item"),
    query: "",
    showSubText: false,
    parseResults: (data) => data,
    fetchAction: () => {
      return new Promise((resolve) =>
        resolve({
          data: [
            {
              id: "974602b6-c8f3-43a3-8f4a-0770a5b170c1",
              name: "Bajaj",
              tag: "Individual Brand",
            },
          ],
        }),
      );
    },
    disabled: false,
  },
];

export default {
  title: "Legacy/Form",
  component: Form,
};

export const Default = () => <Form config={config} />;
export const HasError = () => <Form config={[config[0], { ...config[1], error: true }]} />;
