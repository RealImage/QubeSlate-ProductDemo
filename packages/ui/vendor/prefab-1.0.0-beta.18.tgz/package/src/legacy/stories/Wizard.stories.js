import Wizard from "../components/Wizard";

// need to add storybook/preview-api to manipulate args for onclicks

export default {
  title: "Legacy/Wizard",
  component: Wizard,
  argTypes: {
    current: {
      control: {
        type: "number",
      },
    },
  },
  args: {
    steps: [
      {
        // status: 'inactive',
        title: "Compositions",
      },
      {
        status: "skip",
        title: "Email",
      },
      {
        status: "skip",
        title: "Email",
      },
      {
        // status: 'active',
        title: "Step 3",
      },
      {
        // status: 'finish',
        title: "Theatres Selection",
      },
      {
        // status: 'active',
        title: "Step 5",
      },
    ],
    current: 2,
    ordered: true,
  },
};

export const BasicWizard = (args) => <Wizard {...args} />;
export const WizardWithClickAction = (args) => (
  <Wizard
    {...args}
    onChange={() => {
      // console.log(`index: ${index}`)
    }}
  />
);
