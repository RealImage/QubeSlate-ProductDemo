import { action } from "storybook/actions";
import ColumnSelector from "../components/ColumnSelector";
import RightPanel from "../components/RightPanel";
import Checkbox from "../components/Checkbox";

const tableColumns = [
  {
    id: "col1",
    Header: "col1",
    accessor: "col1",
  },
  {
    id: "col2",
    Header: "col2",
    accessor: "col2",
  },
  {
    id: "col3",
    Header: "col3",
    accessor: "col3",
  },
  {
    id: "col4",
    Header: "col4",
    accessor: "col4",
  },
];

export default {
  title: "Legacy/Column Selector",
  component: ColumnSelector,
  subcomponents: { RightPanel, Checkbox },
  args: {
    selectedColumns: ["col3", "col2"],
    columns: [...tableColumns],
  },
};

export const Basic = (args) => (
  <ColumnSelector
    selectedColumns={["col3", "col2"]}
    reorderedColumns={[]}
    isOpen={true}
    columns={tableColumns}
    onClose={action("Close")}
    cancelEdit={action("Close Edit")}
    onHandleApply={action("Apply Changes")}
    onItemSelect={action("Column Selector")}
    onColumnFilterSelect={action("Column Filter Selector")}
    {...args}
  />
);
