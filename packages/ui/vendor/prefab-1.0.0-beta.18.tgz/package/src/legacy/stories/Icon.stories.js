import BaseButton from "../components/BaseButton";
import * as Icons from "../assets/icon.js";

export default {
  title: "Legacy/Icons",
  component: BaseButton,
};

export const Default = () => (
  <div className="flex flex-wrap">
    {Object.keys(Icons).map((icon, index) => (
      <div
        key={index}
        style={{ alignItems: "center", textAlign: "center" }}
        className={"flex m1 flex-column col-lg-2 col-md-2 col-sm-6 col-xs-6"}
      >
        <BaseButton style={{ width: "max-content" }} key={index} iconName={icon} />
        <span>{icon.split(/(?=[A-Z])/).join(" ")}</span>
      </div>
    ))}
  </div>
);
