import { useState } from "react";
import { action } from "storybook/actions";
import values from "lodash/values";
import { Position } from "@blueprintjs/core";
import PopOver from "../components/PopOver";
import BaseButton from "../components/BaseButton";
import { BUTTON_TYPE, SIZE } from "../constants";

export default {
  title: "Legacy/PopOver",
  component: PopOver,
  parameters: {
    docs: {
      description: {
        component:
          "PopOver component that uses children as trigger for displaying popover content. " +
          "Pass any React element as children to act as the popover trigger. " +
          "All popover props are passed directly to the underlying Blueprint Popover.",
      },
    },
  },
  argTypes: {
    position: {
      control: {
        type: "select",
        options: Object.values(Position),
      },
    },
    minimal: {
      control: { type: "boolean" },
    },
    captureDismiss: {
      control: { type: "boolean" },
    },
    disabled: {
      control: { type: "boolean" },
    },
    // BaseButton trigger controls
    buttonText: {
      control: { type: "text" },
      description: "Text to display on the button trigger",
    },
    buttonType: {
      control: {
        type: "select",
        options: values(BUTTON_TYPE),
      },
      description: "Button style type for the trigger",
    },
    buttonSize: {
      control: {
        type: "select",
        options: values(SIZE),
      },
      description: "Button size for the trigger",
    },
    buttonDisabled: {
      control: { type: "boolean" },
      description: "Whether the button trigger is disabled",
    },
  },
  args: {
    position: Position.BOTTOM_LEFT,
    minimal: true,
    captureDismiss: true,
    disabled: false,
    buttonText: "Fill Price For All",
    buttonType: BUTTON_TYPE.DEFAULT,
    buttonSize: SIZE.REGULAR,
    buttonDisabled: false,
    buttonIconName: "ChevronDownIcon",
    buttonIconPos: "right",
    buttonIconSize: 16,
  },
};

export const Basic = (args) => {
  const { buttonText, buttonType, buttonSize, buttonDisabled, ...popoverProps } = args;

  return (
    <PopOver
      {...popoverProps}
      content={
        <div style={{ padding: "16px", maxWidth: "200px" }}>
          <h4 style={{ margin: "0 0 8px 0" }}>Popover Content</h4>
          <p style={{ margin: "0" }}>
            This is the content inside the popover. You can put any element here.
          </p>
        </div>
      }
    >
      <BaseButton
        buttonText={buttonText}
        buttonType={buttonType}
        buttonSize={buttonSize}
        disabled={buttonDisabled}
      />
    </PopOver>
  );
};

export const WithCustomContent = (args) => {
  const {
    buttonText,
    buttonType,
    buttonSize,
    buttonDisabled,
    buttonIconName,
    buttonIconPos,
    buttonIconSize,
    ...popoverProps
  } = args;
  const [priceValue, setPriceValue] = useState("");

  return (
    <PopOver
      {...popoverProps}
      content={
        <div style={{ padding: "12px", minWidth: "200px" }}>
          <label
            className="info_label"
            htmlFor="package_name"
            style={{
              display: "block",
              marginBottom: "6px",
              fontSize: "12px",
              fontWeight: "500",
              color: "#5C7080",
            }}
          >
            Enter Price (USD)
          </label>
          <input
            type="text"
            id="package_name"
            placeholder="Set price for all"
            value={priceValue}
            onChange={(e) => setPriceValue(e.target.value)}
            style={{
              width: "100%",
              padding: "6px 8px",
              border: "1px solid #D8DEE4",
              borderRadius: "4px",
              fontSize: "14px",
              marginBottom: "8px",
              boxSizing: "border-box",
            }}
          />
          <button
            className="set-price-btn"
            style={{
              width: "100%",
              padding: "6px 12px",
              backgroundColor: "#1F4788",
              color: "white",
              border: "none",
              borderRadius: "4px",
              fontSize: "12px",
              fontWeight: "500",
              cursor: "pointer",
            }}
            onClick={() => {
              action("Set Price Click")(priceValue);
              setPriceValue("");
            }}
          >
            Set Price
          </button>
        </div>
      }
    >
      <BaseButton
        buttonText={buttonText}
        buttonType={buttonType}
        buttonSize={buttonSize}
        disabled={buttonDisabled}
        iconName={buttonIconName}
        iconPos={buttonIconPos}
        iconSize={buttonIconSize}
      />
    </PopOver>
  );
};
