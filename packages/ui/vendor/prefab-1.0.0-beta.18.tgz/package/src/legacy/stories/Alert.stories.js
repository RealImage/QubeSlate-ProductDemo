import { useState } from "react";
import Alert from "../components/Alert";

const props = {
  title:
    "This content is less than 8GB and could be sent via smaller, more cost effective media (ie. USB stick/thumb drive).",
  bodyContent:
    "If this work order will be fulfilled using alternative media, please remember to update your drive inventory accordingly. ",
  showIcon: true,
  showClose: true,
  showSubText: true,
  type: "error",
  iconName: "AlertRoundedIcon",
};

const InteractiveAlert = () => {
  const [alertType, setAlertType] = useState("error");

  const alertContent = {
    error: {
      title: "Error: Action required",
      bodyContent:
        "There was an error processing your request. Please try again or contact support.",
      iconName: "AlertRoundedIcon",
    },
    warning: {
      title: "Warning: Please review",
      bodyContent:
        "This content is less than 8GB and could be sent via smaller, more cost effective media (ie. USB stick/thumb drive).",
      iconName: "AlertRoundedIcon",
    },
    info: {
      title: "Information: Good to know",
      bodyContent:
        "Your request has been processed successfully. You will receive a confirmation email shortly.",
      iconName: "InfoFilledIcon",
    },
  };

  const currentAlert = alertContent[alertType];

  return (
    <div>
      <div style={{ marginBottom: "20px" }}>
        <div style={{ marginBottom: "10px", fontSize: "14px", fontWeight: "500" }}>
          Select Alert Type:
        </div>
        <div style={{ display: "flex", gap: "12px" }}>
          {Object.keys(alertContent).map((type) => (
            <label
              key={type}
              style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer" }}
            >
              <input
                type="radio"
                name="alertType"
                value={type}
                checked={alertType === type}
                onChange={(e) => setAlertType(e.target.value)}
              />
              <span style={{ textTransform: "capitalize" }}>{type}</span>
            </label>
          ))}
        </div>
      </div>
      <Alert
        {...props}
        type={alertType}
        title={currentAlert.title}
        bodyContent={currentAlert.bodyContent}
        iconName={currentAlert.iconName}
      />
    </div>
  );
};

export default {
  title: "Legacy/Alert",
  component: Alert,
};

export const Default = () => <Alert {...props} />;
export const InteractiveTypes = () => <InteractiveAlert />;
