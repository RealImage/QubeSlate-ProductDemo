import TabPills from "../components/TabPills";

const Tabs = [
  {
    id: "details",
    title: "Details",
    goto: "/details",
    panel: <div>Details</div>,
  },
  {
    id: "Campaigns",
    title: "Campaigns",
    goto: "/Campaigns",
    panel: <div>Campaigns</div>,
  },
];

export default {
  title: "Legacy/TabPills",
  component: TabPills,
  argTypes: {
    renderActiveTabPanelOnly: { control: { type: "boolean" } },
    animate: { control: { type: "boolean" } },
    selectedTabId: { control: { type: "string" } },
    tabs: { control: { type: "array" } },
  },
  args: {
    renderActiveTabPanelOnly: false,
    animate: true,
    selectedTabId: "Campaigns",
    tabs: Tabs,
  },
};

export const Basic = (args) => <TabPills {...args} />;
