import { useArgs } from "storybook/preview-api";
import PopupDialog from "../components/PopupDialog";

export default {
  title: "Legacy/PopupDialog",
  component: PopupDialog,
  parameters: {
    docs: {
      description: {
        component:
          "<p>PopupDialog renders a modal or sheet dialog that appears on top of the current page.<p>" +
          "It has three modes: `dialog`, `sheet` and `auto`. \n\n" +
          '1. Default is `mode="dialog"` this renders the component as a dialog at the center of the page. \n' +
          '2. `mode="sheet"` always renders the component as a bottom sheet. \n' +
          '3. `mode="auto"` automatically switches between dialog and sheet based on viewport size.',
      },
    },
  },
  argTypes: {
    isOpen: { control: { type: "boolean" } },
    mode: {
      options: ["auto", "dialog", "sheet"],
      control: { type: "select" },
    },
    title: { control: { type: "text" } },
    bodyContent: { control: { type: "text" } },
    onClose: { action: "Close" },
    onConfirm: { action: "Confirm" },
    cancelButtonText: { control: { type: "text" } },
    confirmButtonText: { control: { type: "text" } },
  },
  args: {
    isOpen: true,
    mode: "auto",
    title: "Are you sure?",
    bodyContent: "Looks like you are in a hurry. Hope you know what you are doing.",
    cancelButtonText: "Cancel",
    confirmButtonText: "Confirm",
  },
};

export const Default = (props) => {
  const [{ isOpen }, updateArgs] = useArgs();

  const handleClose = () => {
    updateArgs({ isOpen: false });
    if (props.onClose) props.onClose();
  };

  const handleConfirm = () => {
    updateArgs({ isOpen: false });
    if (props.onConfirm) props.onConfirm();
  };

  return <PopupDialog {...props} isOpen={isOpen} onClose={handleClose} onConfirm={handleConfirm} />;
};
