import {
  AboutUsIcon,
  TermsofServiceIcon,
  PrivacyPolicyIcon,
  SettingsIcon,
  SupportIcon,
  ProjectorIcon,
  ArchivedMediaIcon,
  TheatreIcon,
  SeatIcon,
  AdvertiserIcon,
  OrganisationIcon,
  CampaignIcon,
} from "../../assets/icon.js";
import NavigationBarDemo from "./NavigationBarDemo";

const Links = [
  { name: "About Us", path: "https://www.qubecinema.com/about-us", Icon: AboutUsIcon },
  {
    name: "Terms of Service",
    path: "https://www.qubecinema.com/terms-use",
    Icon: TermsofServiceIcon,
  },
  {
    name: "Privacy Policy",
    path: "https://www.qubecinema.com/privacy-policy",
    Icon: PrivacyPolicyIcon,
  },
];

const Menus = [
  {
    name: "Settings",
    route: "/settings",
    Icon: SettingsIcon,
    isIconRight: false,
  },
  {
    name: "Support",
    route: "/support",
    Icon: SupportIcon,
    isIconRight: false,
  },
  {
    name: "Profile",
    route: "/profile",
    Icon: ProjectorIcon,
    isIconRight: false,
  },
];

const NavMenus = [
  {
    name: "Campaigns",
    route: ["/campaigns", "/thetres"],
    Icon: CampaignIcon,
    badge: 222,
  },
  {
    type: "navMenuAccordion",
    name: "Campaigns",
    menuList: [
      {
        name: "Campaigns",
        route: ["/campaigns", "/thetres"],
        Icon: CampaignIcon,
        badge: 222,
      },
      {
        name: "Active Campaigns",
        route: "/active-campaigns",
        Icon: ArchivedMediaIcon,
        badge: 100,
      },
    ],
  },
  {
    type: "navMenuAccordion",
    name: "Theatres",
    menuList: [
      {
        name: "Theatres",
        route: "/theatres",
        Icon: TheatreIcon,
        badge: 5,
      },
      {
        name: "Screens",
        route: "/screens",
        Icon: SeatIcon,
        badge: 12,
      },
    ],
  },
  {
    name: "Reports",
    route: "reports",
    icon: OrganisationIcon,
  },
  {
    type: "navMenuAccordion",
    name: "Work Order",
    menuList: [
      {
        name: "Active",
        route: "/active",
        Icon: AdvertiserIcon,
        badge: 5,
      },
      {
        name: "Archived",
        route: "/archived",
        Icon: OrganisationIcon,
        badge: 12,
      },
    ],
  },
];

export default {
  title: "Legacy/NavigationBarDemo",
  component: NavigationBarDemo,
};

export const Basic = (args) => (
  <NavigationBarDemo {...args} footerMenuList={Menus} infoLinks={Links} menuItemList={NavMenus} />
);
