import ToggleSwitch from "../components/ToggleSwitch";

export default {
  title: "Legacy/Toggle Switch",
  component: ToggleSwitch,
  argTypes: {
    labelText: { control: "text", description: "Label for the toggle" },
    isChecked: { control: "boolean", description: "Checked state of the toggle" },
    isDisabled: { control: "boolean", description: "Disabled state of the toggle" },
  },
};

const Template = (args) => <ToggleSwitch {...args} />;

export const Default = Template.bind({});
Default.args = {
  labelText: "Qube Cinema",
};
