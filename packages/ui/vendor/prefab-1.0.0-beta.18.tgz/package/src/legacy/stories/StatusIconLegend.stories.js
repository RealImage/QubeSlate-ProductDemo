import StatusIconLegend from "../components/StatusIconLegend";
import { STATUS_ICON_COLORS, STATUS_ICON_TYPES } from "../constants";

const props = {
  statusInfo: [
    {
      tagType: "movieStatus",
      color: STATUS_ICON_COLORS.GREEN,
      type: STATUS_ICON_TYPES.CIRCLE,
      count: 4,
      name: "Running",
    },
    {
      tagType: "movieStatus",
      color: STATUS_ICON_COLORS.GREY,
      type: STATUS_ICON_TYPES.CIRCLE,
      count: 12,
      name: "Upcoming",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.GREEN,
      type: STATUS_ICON_TYPES.DURATION,
      count: 14,
      name: "Success",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.RED,
      type: STATUS_ICON_TYPES.DURATION,
      count: 45,
      name: "Failure",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.LIGHT_GREEN,
      type: STATUS_ICON_TYPES.CONFIRM_CIRCLE,
      count: 12,
      name: "Generated",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.LIGHT_GREEN,
      type: STATUS_ICON_TYPES.CONFIRM_CIRCLE_FILLED,
      count: 12,
      name: "Sent",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.BLUE,
      type: STATUS_ICON_TYPES.CIRCLE_PARTIALLY_FILLED_ICON,
      count: 12,
      name: "In Progress",
    },
  ],
};

export default {
  title: "Legacy/StatusIconLegend",
  component: StatusIconLegend,
};

export const Default = () => <StatusIconLegend {...props} />;
