import { action } from "storybook/actions";
import RightPanel from "../components/RightPanel";
import BaseButton from "../components/BaseButton";

const buttons = {
  primaryButtonProps: {
    buttonText: "Save",
    onClick: action("Save"),
  },
  secondaryButtonProps: { text: "Cancel", onClick: action("Cancel") },
};

const multiPrimaryButtons = {
  primaryButtonProps: [
    {
      buttonText: "Save",
      onClick: action("Save"),
    },
    {
      buttonText: "Close",
      onClick: action("Close"),
    },
  ],
  secondaryButtonProps: { text: "Button.cancel", onClick: action("Cancel") },
};

const CustomFooter = () => {
  return (
    <div className="flex justify-between col-12">
      <div className="flex">
        <BaseButton buttonType="primary" style={{ marginRight: "1rem" }} buttonText="Update" />
        <BaseButton buttonText="Cancel" />
      </div>
      <BaseButton buttonType="destructive-secondary" buttonText="Delete" />
    </div>
  );
};

export default {
  title: "Legacy/RightPanel",
  component: RightPanel,
  argTypes: {
    isOpen: { control: { type: "boolean" } },
    showFooter: { control: { type: "boolean" } },
    onClose: { action: "Close" },
    header: { control: { type: "text" } },
    width: { control: { type: "number" } },
  },
  args: {
    isOpen: true,
    showFooter: false,
    header: "Filters",
    width: 320,
  },
};

export const Default = (props) => <RightPanel {...props} />;
export const Loading = (props) => <RightPanel {...props} {...buttons} isLoading showFooter />;
export const WithFooter = (props) => <RightPanel {...props} showFooter {...buttons} />;
export const WithCustomFooterComponent = (props) => (
  <RightPanel {...props} showFooter footer={<CustomFooter />} />
);
export const MultiplePrimaryButtons = (props) => (
  <RightPanel {...props} showFooter {...multiPrimaryButtons} />
);
export const WithClearAllFilterAndFilterIcon = (props) => (
  <RightPanel {...props} showFilterIcon showClearAll onClickClearAll={action("clear All")} />
);
