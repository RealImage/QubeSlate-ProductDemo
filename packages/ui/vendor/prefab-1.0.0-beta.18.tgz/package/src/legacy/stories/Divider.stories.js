import Divider from "../components/Divider";
import StatusIconLegend from "../components/StatusIconLegend";
import { STATUS_ICON_COLORS, STATUS_ICON_TYPES } from "../constants";

const props = {
  statusInfo: [
    {
      tagType: "movieStatus",
      color: STATUS_ICON_COLORS.GREEN,
      type: STATUS_ICON_TYPES.CIRCLE,
      count: 4,
      name: "Running",
    },
    {
      tagType: "movieStatus",
      color: STATUS_ICON_COLORS.GREY,
      type: STATUS_ICON_TYPES.CIRCLE,
      count: 12,
      name: "Upcoming",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.GREEN,
      type: STATUS_ICON_TYPES.DURATION,
      count: 14,
      name: "Success",
    },
    {
      tagType: "heartBeat",
      color: STATUS_ICON_COLORS.RED,
      type: STATUS_ICON_TYPES.DURATION,
      count: 45,
      name: "Failure",
    },
  ],
};

export default {
  title: "Legacy/Divider",
  component: Divider,
};

export const Default = () => <Divider />;
export const WithTwoStatus = () => <StatusIconLegend {...props} />;
export const WithMoreThanTwoStatus = () => (
  <StatusIconLegend
    statusInfo={[
      ...props.statusInfo,
      {
        color: STATUS_ICON_COLORS.RED,
        type: STATUS_ICON_TYPES.MOVIES,
        count: 45,
        name: "New",
      },
    ]}
    onFilterSelect={() => {}}
  />
);
