import { useEffect, useState, useCallback } from "react";
import classNames from "classnames";
import { HamburgerIcon, QubeLogoOnlyBlueIcon, QubeWireLogoBlueFullIcon } from "../../assets/icon";
import NavigationBarV2 from "../../components/NavigationBar/NavigationBarV2.js";

const NavigationBarV2Demo = (props) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isHovered, setIsHovered] = useState(false);
  const [navAction, setNavAction] = useState("expanded");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 760);
  const [selectedPath, setSelectedPath] = useState("/qtheatres");

  // Responsive handler
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 760);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleExpand = (expand) => {
    setIsExpanded(expand);
    setIsHovered(false);
    setNavAction(expand ? "expanded" : "collapsed");
  };

  const handleNavBarHover = (hover) => {
    setIsHovered(hover);
    setNavAction(hover ? "hovered" : isExpanded ? "expanded" : "collapsed");
  };

  const handleCollapsedItemClick = () => {
    if (isMobile) {
      handleExpand(false);
    } else if (!isExpanded) {
      handleNavBarHover(true);
    }
  };

  // dummy selection
  const history = {
    push: useCallback((path) => setSelectedPath(path), []),
    replace: null,
  };

  const location = { pathname: selectedPath, search: null, match: null };

  const renderMobileHeader = () => (
    <div className={classNames("mobileHeader")}>
      <div className={classNames("flex col-2", "menuIcon")} onClick={() => handleExpand(true)}>
        <HamburgerIcon />
      </div>
      {!isExpanded && (
        <div className="logo">
          <QubeWireLogoBlueFullIcon />
        </div>
      )}
    </div>
  );

  return (
    <main>
      {isMobile && renderMobileHeader()}
      <div
        id={isMobile ? "drawer" : "sideBar"}
        onMouseLeave={() => handleNavBarHover(false)}
        className={classNames("sideNavContainer v2", navAction, {
          portal: isMobile,
        })}
      >
        <NavigationBarV2
          isExpanded={isExpanded}
          homeRoute={"/"}
          logo={{
            logoSmall: <QubeLogoOnlyBlueIcon />,
            logoExpanded: <QubeWireLogoBlueFullIcon />,
          }}
          isHovered={isHovered}
          history={history}
          location={location}
          handlePinned={handleExpand}
          handleExpand={isMobile ? handleExpand : () => {}}
          onCollapsedItemClick={handleCollapsedItemClick}
          isMobile={isMobile}
          menuItemList={props.menuItemList}
          classNames={props.classNames}
          styles={props.styles}
          footerProps={{
            withUserInitial: true,
            companyName: "Yash Raj Films",
            userName: "Kube Wireson",
            infoLinks: props.infoLinks,
            footerMenuList: props.footerMenuList,
          }}
        />
      </div>

      {isExpanded && isMobile && (
        <div className="overlay" onClick={() => handleExpand(false)}></div>
      )}

      <div
        className={classNames("pageLayout v2", `page_${navAction}`, {
          mobile: isMobile,
        })}
        onClick={() => (isMobile ? handleExpand(false) : null)}
      >
        <div className={classNames("col-12", "container")}>Page gets rendered here</div>
      </div>
    </main>
  );
};

export default NavigationBarV2Demo;
