import { action } from "storybook/actions";
import Header from "../components/Header";

const props = {
  name: "Qube Slate",
  count: "2",
  isLoading: false,
};

const rightSideComponent = () => (
  <div className="flex align-center flex-wrap">
    <p>Right Side Component</p>
  </div>
);

const buttons = [
  {
    text: "Button",
    iconName: "ViewIcon",
    onClick: action("Button OnClick"),
  },
];

export default {
  title: "Legacy/Header",
  component: Header,
};

export const Default = () => <Header {...props} />;
export const OnlyTitle = () => <Header {...props} count={null} />;
export const Tagline = () => <Header {...props} tagLine="Theatre Advertisement Marketplace" />;
export const PartialLoading = () => <Header {...props} isPartialLoading count={0} />;
export const RightSideComponent = () => (
  <Header {...props} renderRightSideComponent={rightSideComponent} />
);
export const Buttons = () => <Header {...props} buttons={buttons} />;
export const ActiveCount = () => <Header {...props} activeCount={10} />;
export const WithChild = () => <Header {...props} bottomChild={<div>React Child Element</div>} />;
