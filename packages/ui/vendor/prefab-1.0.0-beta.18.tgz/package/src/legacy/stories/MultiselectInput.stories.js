import includes from "lodash/includes";
import { action } from "storybook/actions";
import MultiSelectInput from "../components/MultiSelectInput";
import MenuItem from "../components/MenuItem";

const items = [
  {
    id: "32b4ca99-5622-4909-b626-510bd57cb972",
    name: "Watches",
    type: "Category",
    updatedAt: "2019-05-29T11:16:24.318123Z",
    subCategory: "branded",
  },
  {
    id: "bae15eb7-fe77-41d6-9be3-b4bf9f7940d0",
    name: "Clothes",
    type: "Category",
    updatedAt: "2019-05-28T08:01:56.534239Z",
    subCategory: "local",
  },
];

export default {
  title: "Legacy/MultiSelectInput",
  component: MultiSelectInput,
  subcomponents: { MenuItem },
  argTypes: {
    itemPredicate: { control: { type: "function" } },
    onMenuItemSelect: { control: { type: "function" } },
    onQueryChange: { control: { type: "function" } },
    onRemove: { control: { type: "function" } },
    onSearchClear: { control: { type: "function" } },
    resetOnSelect: { control: { type: "boolean" } },
    noResultsText: { control: { type: "test" } },
    suggestionList: { control: { type: "object" } },
    selectedItems: { control: { type: "object" } },
    tagInputProps: { control: { type: "object" } },
  },
  args: {
    itemPredicate: (query, item) => includes(item.name.toLowerCase(), query.toLowerCase()),
    onMenuItemSelect: action("Item Selected"),
    onQueryChange: action("Input change"),
    onRemove: action("Item Removed"),
    onSearchClear: action("Clear Search Input"),
    resetOnSelect: false,
    noResultsText: "No Result Found",
    suggestionList: items,
    selectedItems: [],
    tagInputProps: { placeholder: "Search Theatres", value: "" },
  },
};

export const Basic = (props) => <MultiSelectInput {...props} />;
export const Loading = (props) => <MultiSelectInput {...props} loading />;
export const WithSearchQuery = (props) => <MultiSelectInput {...props} query="Search Query" />;
export const WithSubText = (props) => <MultiSelectInput {...props} showSubText />;
export const CustomSubText = (props) => (
  <MultiSelectInput {...props} showSubText customSubTextName={(item) => item.subCategory} />
);
export const CustomMenuName = (props) => (
  <MultiSelectInput {...props} customMenuName={(item) => `${item.name}, ${item.type}`} />
);
export const CustomMenuRendered = (props) => (
  <MultiSelectInput {...props} customMenuItemRender={(item) => <h3>{item.name}</h3>} />
);
export const WithMenuSelected = (props) => {
  return (
    <MultiSelectInput
      {...props}
      selectedItems={[
        {
          id: "32b4ca99-5622-4909-b626-510bd57cb972",
          name: "Watches",
          type: "Category",
          updatedAt: "2019-05-29T11:16:24.318123Z",
        },
      ]}
    />
  );
};
