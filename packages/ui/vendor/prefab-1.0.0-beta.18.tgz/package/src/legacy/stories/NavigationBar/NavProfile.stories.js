import { Position } from "@blueprintjs/core";
import { SettingsIcon, SupportIcon, ProjectorIcon } from "../../assets/icon.js";
import MenuItem from "../../components/MenuItem";
import NavProfile from "../../components/NavigationBar/NavProfile";

const ProfileMenus = [
  {
    name: "Settings",
    route: "/settings",
    Icon: SettingsIcon,
    isIconRight: false,
  },
  {
    name: "Support",
    route: "/support",
    Icon: SupportIcon,
    isIconRight: false,
  },
  {
    name: "Profile",
    route: "/profile",
    Icon: ProjectorIcon,
    isIconRight: false,
  },
];

export default {
  title: "Legacy/NavProfile",
  component: NavProfile,
  subcomponents: { MenuItem },
  argTypes: {
    isMenuActive: { control: { type: "function" } },
    popOverPosition: { control: { type: "select", options: [...Object.values(Position)] } },
    companyName: { control: { type: "text" } },
    name: { control: { type: "text" } },
    isExpanded: { control: { type: "boolean" } },
    menuList: { control: { type: "object" } },
  },
  args: {
    isMenuActive: () => true,
    popOverPosition: Position.LEFT,
    companyName: "Qube Cinemas",
    name: "Raghul Jayan",
    isExpanded: true,
    menuList: ProfileMenus,
  },
};

export const Basic = (args) => (
  <div id="nav">
    <div className="flex align-center col-12 clearfix">
      <NavProfile {...args} />
    </div>
  </div>
);
