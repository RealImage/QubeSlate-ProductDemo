import Tabs from "../components/Tabs";

const TabData = [
  {
    id: "details",
    title: "Details",
    panel: <div>Details</div>,
  },
  {
    id: "Campaigns",
    title: "Campaigns",
    panel: <div>Campaigns</div>,
  },
  {
    id: "Deliveries",
    title: "Deliveries",
    panel: <div>Deliveries</div>,
    count: 10,
  },
];
export default {
  title: "Legacy/Tabs",
  component: Tabs,
  argTypes: {
    renderActiveTabPanelOnly: { control: { type: "boolean" } },
    animate: { control: { type: "boolean" } },
    tabs: { control: { type: "array" } },
  },
  args: {
    renderActiveTabPanelOnly: false,
    animate: true,
    tabs: TabData,
  },
};

export const Basic = (args) => <Tabs {...args} />;
