import FilterChips from "../components/Filters/FilterChips";

export default {
  title: "Legacy/FilterChips",
  component: FilterChips,
  argTypes: {
    showResultsCount: { control: { type: "boolean" } },
    resultsCount: { control: { type: "number" } },
    onFilterChange: { control: { type: "function" } },
    loading: { control: { type: "boolean" } },
    selected: { control: { type: "object" } },
  },
  args: {
    showResultsCount: false,
    resultsCount: 5,
    selected: [
      {
        id: "c6277525-3320-477b-ba27-6a436aae70fc",
        name: "TEST_CODE (Code)",
        type: "notificationCode",
        displayName: "Test",
        context: {},
      },
      {
        id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971cc",
        name: "TEST (Code)",
        type: "notificationCode",
        displayName: "Test",
        context: {},
      },
      {
        id: "c11f042c-2e4d-49c8-b369-83bfa9cabfe7",
        name: "Test 1 (Sub Category 1)",
        type: "productCategory",
        displayName: "Test 1",
        context: null,
      },
      {
        id: "ceafa120-b261-41d6-9236-2513a6fd8fa0",
        name: "Test_2 (Sub Category 2)",
        type: "productCategory",
        displayName: "Test_2",
        context: null,
      },
      {
        id: "325e71d2-5002-4921-9e44-f852bc4552fe",
        name: "test ----1 (Sub Category 1)",
        type: "productCategory",
        displayName: "Test -1",
        context: {},
      },
    ],
    loading: false,
  },
};

export const Default = (props) => <FilterChips {...props} />;
