import { useState, useEffect } from "react";
import { action } from "storybook/actions";
import includes from "lodash/includes";
import FilterSection from "../components/Filters/FilterSection";
import MenuItem from "../components/MenuItem";
import { FILTER_TAG_TYPES } from "../constants";

const props = {
  selected: [
    {
      id: "c6277525-3320-477b-ba27-6a436aae70fc",
      name: "Government",
      type: "businessType",
      displayName: "Government",
      context: {},
    },
    {
      id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971cc",
      name: "Private",
      type: "businessType",
      displayName: "Private Org",
      context: {},
    },
  ],
};

const selectedScreens = [
  {
    id: "c6277525-3320-477b-ba27-6a436aae70fc",
    name: "Screen 1",
    type: "screen",
    displayName: "Screen 5",
    context: {},
  },
  {
    id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971cc",
    name: "Screen 3",
    type: "screen",
    displayName: "Central Cinemas",
    context: {},
  },
];

const countrySuggestionList = [
  {
    id: "ar",
    name: "Argentina",
    type: "theatreLocation",
    displayName: "Argentina",
  },
  {
    id: "au",
    name: "Australia",
    type: "theatreLocation",
    displayName: "Australia",
  },
  {
    id: "at",
    name: "Austria",
    type: "theatreLocation",
    displayName: "Austria",
  },
  {
    id: "be",
    name: "Belgium",
    type: "theatreLocation",
    displayName: "Belgium",
  },
  {
    id: "br",
    name: "Brazil",
    type: "theatreLocation",
    displayName: "Brazil",
  },
];

export default {
  title: "Legacy/FilterSection",
  component: FilterSection,
  subcomponents: { MenuItem },
  argTypes: {
    filterType: { control: { type: "select", options: [...Object.values(FILTER_TAG_TYPES)] } },
    header: { control: { type: "text" } },
    tagType: { control: { type: "text" } },
    selected: { control: { type: "object" } },
    onFilterClear: { control: { type: "function" } },
    onFilterChange: { control: { type: "function" } },
    handleDateChange: { control: { type: "function" } },
    searchTags: { control: { type: "function" } },
  },
  args: {
    filterType: FILTER_TAG_TYPES.LIST,
    header: "Section Title",
    tagType: "Actual Tag Type",
    selected: props.selected,
    tagList: props.tagList,
  },
};

export const ListFilter = (args) => {
  const [tagList, updateList] = useState([]);

  useEffect(() => {
    updateList([
      ...props.selected,
      {
        id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971aac",
        name: "LLP",
        type: "businessType",
        displayName: "LLP",
        context: {},
      },
    ]);
  }, []);

  return (
    <div className="flex align-center col-12 clearfix">
      <FilterSection
        {...args}
        filterType={FILTER_TAG_TYPES.LIST}
        header="Business Type"
        tagType="businessType"
        selected={props.selected}
        tagList={tagList}
        onFilterClear={action("Clear")}
        onFilterChange={action("Change")}
      />
    </div>
  );
};

export const SearchFilter = (args) => (
  <div className="flex align-center col-12 clearfix">
    <FilterSection
      {...args}
      filterType={FILTER_TAG_TYPES.SEARCH}
      header="Screen List"
      tagType="screen"
      selected={selectedScreens}
      tagList={[
        ...selectedScreens,
        {
          id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971aac",
          name: "Screen 2",
          type: "screen",
          displayName: "Screen 2",
          context: {},
        },
      ]}
      searchTags={action("Search Action")}
      onFilterClear={action("Clear")}
      onFilterChange={action("Change")}
    />
  </div>
);

export const MultiSelectFilter = (args) => (
  <div className="flex align-center col-12 clearfix">
    <FilterSection
      {...args}
      filterType={FILTER_TAG_TYPES.MULTI_SELECT_SEARCH}
      suggestionList={props.selected}
      itemPredicate={(query, item) => includes(item.name.toLowerCase(), query.toLowerCase())}
      inputValueRenderer={(item) => item.name}
      onItemSelect={action("Item Selected")}
      onQueryChange={action("Input change")}
      resetOnSelect={false}
      selectedItems={[
        ...selectedScreens,
        {
          id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971aac",
          name: "Screen 2",
          type: "screen",
          displayName: "Screen 2",
          context: {},
        },
      ]}
      tagInputProps={{
        placeholder: "Search Theatres",
        value: "",
      }}
      onSearchClear={action("Clear Search Input")}
      noResultsText={"No results found"}
      header="Screen List"
      tagType="screen"
      selected={selectedScreens}
      tagList={[
        ...selectedScreens,
        {
          id: "2b8979cd-1d1f-4a5c-85d6-f30bab1971aac",
          name: "Screen 2",
          type: "screen",
          displayName: "Screen 2",
          context: {},
        },
      ]}
      onFilterClear={action("Clear")}
      onFilterChange={action("Change")}
    />
  </div>
);
export const DateRangeFilter = (args) => (
  <div className="flex align-center col-12 clearfix">
    <FilterSection
      {...args}
      filterType={FILTER_TAG_TYPES.DATE_RANGE}
      header="Created At"
      tagType="createdAt"
      selected={[]}
      onFilterClear={action("Clear")}
      onFilterChange={action("Change")}
      handleDateChange={action("Date")}
    />
  </div>
);

export const RadioWithSearchFilter = () => {
  const [selected, setSelected] = useState([]);
  const [radioValue, setRadioValue] = useState("include");
  const [query, setQuery] = useState("");

  const handleFilterChange = (item) => {
    action("Change")(item);
    const exists = selected.find((s) => s.id === item.id);
    if (exists) {
      setSelected(selected.filter((s) => s.id !== item.id));
    } else {
      setSelected([...selected, item]);
    }
  };

  const handleRadioChange = (value) => {
    action("Radio Changed")(value);
    setRadioValue(value);
  };

  return (
    <div className="flex align-center col-12 clearfix">
      <FilterSection
        filterType={FILTER_TAG_TYPES.RADIO_WITH_SEARCH}
        header="Theatre Location"
        tagType="theatreLocation"
        selected={selected}
        suggestionList={countrySuggestionList}
        itemPredicate={(q, item) => includes(item.name.toLowerCase(), q.toLowerCase())}
        inputValueRenderer={(item) => item.name}
        query={query}
        onQueryChange={(val) => {
          action("Input change")(val);
          setQuery(val);
        }}
        resetOnSelect={false}
        tagInputProps={{
          placeholder: "Search country",
        }}
        onSearchClear={() => {
          action("Clear Search Input")();
          setQuery("");
        }}
        noResultsText={"No results found"}
        radioOptions={[
          { label: "Include", value: "include" },
          { label: "Exclude", value: "exclude" },
        ]}
        selectedRadioValue={radioValue}
        onRadioChange={handleRadioChange}
        onFilterChange={handleFilterChange}
      />
    </div>
  );
};
