import React from "react";
import { action } from "storybook/actions";
import TableControls from "../components/TableControls";

// Mock data for MultiSelectInput
const mockSuggestionList = [
  { id: "1", displayName: "AHI Film", type: "Company", subText: "Chennai, Tamil Nadu" },
  { id: "2", displayName: "Studio B", type: "Company", subText: "Mumbai, Maharashtra" },
  { id: "3", displayName: "Studio C", type: "Company", subText: "Bangalore, Karnataka" },
  { id: "4", displayName: "Acknowledged", type: "Status", subText: "Transaction Status" },
  { id: "5", displayName: "Completed", type: "Status", subText: "Transaction Status" },
  { id: "6", displayName: "Pending", type: "Status", subText: "Transaction Status" },
];

// Mock search result types
const SearchResultType = {
  CPL: "CPL",
  BOOKING_REF: "BOOKING_REF",
  COMPANY: "COMPANY",
  MOVIE: "MOVIE",
  RECIPIENT_THEATRE: "RECIPIENT_THEATRE",
  RECIPIENT_EMAIL: "RECIPIENT_EMAIL",
};

// Mock filters state
const mockFilters = {
  [SearchResultType.CPL]: [],
  [SearchResultType.BOOKING_REF]: [],
  [SearchResultType.COMPANY]: ["1", "2"],
  [SearchResultType.MOVIE]: [],
  [SearchResultType.RECIPIENT_THEATRE]: [],
  [SearchResultType.RECIPIENT_EMAIL]: [],
};

// Mock dropdown options
const dropDownOptionSelected = [{ label: "Company", value: "Company", type: "company" }];

const SHOW_SUBTEXT_FOR_TYPES = {
  company: true,
  status: true,
  movie: false,
};

export default {
  title: "Legacy/TableControl/MultiSelectInput",
  component: TableControls,
  argTypes: {
    searchBar: {
      defaultValue: true,
      control: {
        type: "boolean",
      },
    },
    pagination: {
      defaultValue: true,
      control: {
        type: "boolean",
      },
    },
  },
};

export const WithMultiSelectInput = (args) => {
  const [globalQuery, setGlobalQuery] = React.useState("");
  const [loadingResults, setLoadingResults] = React.useState(false);
  const [filters] = React.useState(mockFilters);

  // Mock debounced search function
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const createDebouncedGlobalSuggestionList = React.useCallback(
    debounce((query) => {
      if (query.trim()) {
        setLoadingResults(true);
        // Simulate API call
        setTimeout(() => {
          setLoadingResults(false);
        }, 1000);
      }
    }, 300),
    [],
  );

  // Mock search selection handler
  const searchSelectionHandler = (item) => {
    action("MultiSelect Item Selected")(item);
  };

  // Mock debounce function
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  const multiSelectProps = {
    tagInputProps: {
      placeholder: dropDownOptionSelected[0]?.label || "Select an Item",
    },
    query: globalQuery,
    suggestionList: mockSuggestionList,
    showSubText: SHOW_SUBTEXT_FOR_TYPES[dropDownOptionSelected[0]?.type] || false,
    selectedItems: [
      ...filters[SearchResultType.CPL],
      ...filters[SearchResultType.BOOKING_REF],
      ...filters[SearchResultType.COMPANY],
      ...filters[SearchResultType.BOOKING_REF],
      ...filters[SearchResultType.MOVIE],
      ...filters[SearchResultType.RECIPIENT_THEATRE],
      ...filters[SearchResultType.RECIPIENT_EMAIL],
    ].map((val) => ({ id: val })),
    onQueryChange: (q) => {
      setGlobalQuery(q);
      createDebouncedGlobalSuggestionList(q);
      action("Query Changed")(q);
    },
    onMenuItemSelect: searchSelectionHandler,
    onRemove: searchSelectionHandler,
    noResultsText: "No Data Found",
    loading: loadingResults,
    customMenuName: (item) => item.displayName,
    customSubTextName: (item) => (item.subText ? item.subText : item.type),
  };

  return (
    <div style={{ padding: "20px" }}>
      <h3>TableControls with MultiSelectInput</h3>
      <p>
        This example demonstrates TableControls with MultiSelectInput for handling multiple
        categories with search functionality, similar to your existing pattern.
      </p>
      <p>
        <strong>Features:</strong>
        <br />
        • Multi-category search with tags
        <br />
        • Debounced search with loading states
        <br />
        • Custom menu names and sub-text
        <br />
        • Selected items display as tags
        <br />• Integration with TableControls layout
      </p>
      <TableControls
        {...args}
        multiSelectPresent={true}
        multiSelectProps={multiSelectProps}
        searchBar={true}
        pagination={true}
        totalResults={200}
        currentPage={1}
        pageSize={10}
        onRowSizeChange={action("Row Size Change")}
      />
    </div>
  );
};

export const WithMultiSelectAndMultiLevel = (args) => {
  const [globalQuery, setGlobalQuery] = React.useState("");
  const [loadingResults] = React.useState(false);
  const [filters] = React.useState(mockFilters);

  // MultiLevelSelector categories
  const multiLevelFilterCategories = [
    {
      id: "transaction-type",
      label: "Transaction Type",
      options: [
        { id: "acknowledged", label: "Acknowledged" },
        { id: "accepted", label: "Accepted" },
        { id: "pending", label: "Pending Fulfillment" },
        { id: "completed", label: "Completed" },
      ],
    },
    {
      id: "qw-distributor-name",
      label: "QW Distributor Name",
      enableSearch: true,
      searchPlaceholder: "Search by QW Distributor Name",
    },
  ];

  // Mock API search function
  const mockApiSearch = async (categoryId) => {
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const mockData = {
      "qw-distributor-name": [
        { id: "1", display_name: "AHI Film", address: { city: "Chennai" } },
        { id: "2", display_name: "Studio B", address: { city: "Mumbai" } },
      ],
    };

    return mockData[categoryId] || [];
  };

  const multiSelectProps = {
    tagInputProps: {
      placeholder: "Search Companies, Status, etc.",
    },
    query: globalQuery,
    suggestionList: mockSuggestionList,
    showSubText: true,
    selectedItems: [...filters[SearchResultType.COMPANY]].map((val) => ({ id: val })),
    onQueryChange: (q) => {
      setGlobalQuery(q);
      action("Query Changed")(q);
    },
    onMenuItemSelect: (item) => {
      action("MultiSelect Item Selected")(item);
    },
    onRemove: (item) => {
      action("MultiSelect Item Removed")(item);
    },
    noResultsText: "No Data Found",
    loading: loadingResults,
    customMenuName: (item) => item.displayName,
    customSubTextName: (item) => (item.subText ? item.subText : item.type),
  };

  return (
    <div style={{ padding: "20px" }}>
      <h3>TableControls with Both MultiSelectInput and MultiLevelSelector</h3>
      <p>
        This example shows how to use both MultiSelectInput and MultiLevelSelector together in
        TableControls for comprehensive filtering capabilities.
      </p>
      <TableControls
        {...args}
        multiSelectPresent={true}
        multiSelectProps={multiSelectProps}
        multiLevelFilterPresent={true}
        multiLevelFilterCategories={multiLevelFilterCategories}
        multiLevelSelectedFilters={{}}
        onMultiLevelFilterChange={action("Multi-Level Filter Change")}
        onMultiLevelResetAll={action("Multi-Level Reset All")}
        onMultiLevelClearSelected={action("Multi-Level Clear Selected")}
        multiLevelFilterPlaceholder="Filters"
        multiLevelFilterWidth="700px"
        multiLevelFilterHeight="400px"
        onMultiLevelSearch={mockApiSearch}
        multiLevelSearchDebounceMs={500}
        searchBar={true}
        pagination={true}
        totalResults={200}
        currentPage={1}
        pageSize={10}
        onRowSizeChange={action("Row Size Change")}
      />
    </div>
  );
};
