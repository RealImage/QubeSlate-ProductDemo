import moment from "moment";
import { action } from "storybook/actions";
import DateRangePicker from "../components/DateRangePicker";

const minDate = moment().toDate();
const maxDate = moment().add(7, "days").toDate();

const startDate = moment().toDate();
const endDate = moment().add(3, "days").toDate();

export default {
  title: "Legacy/DateRangePicker",
  component: DateRangePicker,
};

export const Default = () => (
  <DateRangePicker placeholder="Pick a date" handleDateChange={action("date picked")} />
);

export const MinAndMaxValues = () => (
  <DateRangePicker
    placeholder="Pick a date"
    dateRange={[]}
    minDate={minDate}
    maxDate={maxDate}
    handleDateChange={action("date picked")}
  />
);

export const SelectedValues = () => (
  <DateRangePicker
    placeholder="Pick a date"
    dateRange={[startDate, endDate]}
    handleDateChange={action("date picked")}
  />
);
