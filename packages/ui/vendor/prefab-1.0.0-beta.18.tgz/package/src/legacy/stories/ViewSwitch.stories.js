import { action } from "storybook/actions";
import BaseButton from "../components/BaseButton";
import SwitchButtonWithText from "../components/ViewSwitch";

export default {
  title: "Legacy/SwitchButtonWithText",
  component: SwitchButtonWithText,
  subcomponents: { BaseButton },
  argTypes: {
    label: { control: { type: "text" } },
    buttons: { control: { type: "object" } },
  },
  args: {
    label: "View As",
    buttons: [
      { buttonText: "Theatres", onClick: action("Theatres OnClick"), isActive: true },
      { buttonText: "Screens", onClick: action("Screens OnClick"), isActive: false },
      { buttonText: "Movies", onClick: action("Movies OnClick"), isActive: false },
    ],
  },
};

export const Basic = (args) => (
  <div className="flex align-center col-12 clearfix">
    <SwitchButtonWithText {...args} />
  </div>
);
