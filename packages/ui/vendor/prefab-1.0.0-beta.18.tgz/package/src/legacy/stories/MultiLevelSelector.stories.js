import React, { useState } from "react";
import { action } from "storybook/actions";
import MultiLevelSelector from "../components/MultiLevelSelector";
import BaseButton from "../components/BaseButton";

export default {
  title: "Legacy/MultiLevelSelector",
  component: MultiLevelSelector,
  subcomponents: { BaseButton },
  argTypes: {
    onFilterChange: {
      control: {
        type: "function",
      },
      defaultValue: (categoryId, newCategoryFilters) => {
        action("onFilterChange")(categoryId, newCategoryFilters);
      },
    },
    onResetAll: {
      control: {
        type: "function",
      },
      defaultValue: () => {
        action("onResetAll")();
      },
    },
    onClearSelected: {
      control: {
        type: "function",
      },
      defaultValue: (categoryId) => {
        action("onClearSelected")(categoryId);
      },
    },
    placeHolder: {
      defaultValue: "Filters",
      control: {
        type: "text",
      },
    },
    disabled: {
      defaultValue: false,
      control: {
        type: "boolean",
      },
    },
    usePortal: {
      defaultValue: false,
      control: {
        type: "boolean",
      },
    },
    defaultIsOpen: {
      defaultValue: false,
      control: {
        type: "boolean",
      },
    },
    showActionButtons: {
      defaultValue: true,
      control: {
        type: "boolean",
      },
    },
  },
};

// Sample filter data with per-category search configuration
const sampleFilterCategories = [
  {
    id: "transaction-type",
    label: "Transaction Type",
    options: [
      { id: "acknowledged", label: "Acknowledged" },
      { id: "accepted", label: "Accepted" },
      { id: "pending", label: "Pending Fulfillment" },
      { id: "completed", label: "Completed" },
      { id: "completed-ed", label: "Completed ED" },
      { id: "completed-hd", label: "Completed HD" },
      { id: "rejected", label: "Rejected" },
      { id: "cancelled", label: "Cancelled after Completion" },
    ],
  },
  {
    id: "ofe-order-status",
    label: "OFE Order Status",
    options: [
      { id: "pending-approval", label: "Pending Approval" },
      { id: "approved", label: "Approved" },
      { id: "in-progress", label: "In Progress" },
      { id: "shipped", label: "Shipped" },
      { id: "delivered", label: "Delivered" },
      { id: "returned", label: "Returned" },
      { id: "refunded", label: "Refunded" },
      { id: "cancelled-order", label: "Cancelled" },
    ],
  },
  {
    id: "order-type",
    label: "Order Type",
    options: [
      { id: "regular", label: "Regular Order" },
      { id: "express", label: "Express Order" },
      { id: "bulk", label: "Bulk Order" },
      { id: "subscription", label: "Subscription" },
    ],
  },
  {
    id: "qw-delivery-status",
    label: "QW Delivery Status",
    enableSearch: true,
    searchPlaceholder: "Search Delivery Status",
    options: [
      { id: "scheduled", label: "Scheduled" },
      { id: "out-for-delivery", label: "Out for Delivery" },
      { id: "delivered-qw", label: "Delivered" },
      { id: "failed-delivery", label: "Failed Delivery" },
      { id: "rescheduled", label: "Rescheduled" },
    ],
  },
  {
    id: "qw-distributor-name",
    label: "QW Distributor Name",
    enableSearch: true,
    searchPlaceholder: "Studios",
    options: [
      { id: "ags-studios", label: "AGS Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "annapurna-studios", label: "Annapurna Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "avm-studios", label: "AVM Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "excel-studios", label: "Excel Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "fox-star-studios", label: "Fox Star Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "lyca-studios", label: "Lyca Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "madras-studios", label: "Madras Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "raj-kamal-studios", label: "Raj Kamal Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "sun-studios", label: "Sun Studios", note: "Chennai, Tamil Nadu, India" },
      { id: "vijaya-studios", label: "Vijaya Studios", note: "Chennai, Tamil Nadu, India" },
    ],
  },
];

const StatefulMultiLevelSelector = ({ initialFilters = {}, initialCategory = null, ...args }) => {
  const [selectedFilters, setSelectedFilters] = useState(initialFilters);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredResults, setFilteredResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  // Handle search functionality
  React.useEffect(() => {
    if (args.onSearch && searchQuery.trim()) {
      setIsSearching(true);
      const timeoutId = setTimeout(async () => {
        try {
          const results = await args.onSearch(selectedCategory, searchQuery);
          setFilteredResults(results);
        } catch (error) {
          console.error("Search error:", error);
          setFilteredResults([]);
        } finally {
          setIsSearching(false);
        }
      }, args.searchDebounceMs || 300);

      return () => clearTimeout(timeoutId);
    } else if (selectedCategory && args.filterCategories) {
      // When no search query, show category options if available
      const category = args.filterCategories.find((cat) => cat.id === selectedCategory);
      if (category && category.options) {
        setFilteredResults(category.options);
      } else {
        setFilteredResults([]);
      }
      setIsSearching(false);
    } else {
      setFilteredResults([]);
      setIsSearching(false);
    }
  }, [searchQuery, selectedCategory, args.searchDebounceMs, args]);

  const handleFilterChange = (categoryId, newCategoryFilters) => {
    setSelectedFilters((prev) => ({
      ...prev,
      [categoryId]: newCategoryFilters,
    }));
    action("onFilterChange")(categoryId, newCategoryFilters);
  };

  const handleResetAll = () => {
    setSelectedFilters({});
    setSelectedCategory(null);
    setSearchQuery("");
    setFilteredResults([]);
    action("onResetAll")();
  };

  const handleClearSelected = (categoryId) => {
    setSelectedFilters((prev) => ({
      ...prev,
      [categoryId]: [],
    }));
    action("onClearSelected")(categoryId);
  };

  const handleOptionToggle = (categoryId, option) => {
    const categoryFilters = selectedFilters[categoryId] || [];
    const optionIndex = categoryFilters.findIndex((filter) => filter.id === option.id);

    let newCategoryFilters;
    if (optionIndex > -1) {
      newCategoryFilters = categoryFilters.filter((filter) => filter.id !== option.id);
    } else {
      newCategoryFilters = [...categoryFilters, option];
    }

    handleFilterChange(categoryId, newCategoryFilters);
  };

  // Initialize selected category
  React.useEffect(() => {
    if (args.filterCategories && args.filterCategories.length > 0 && !selectedCategory) {
      setSelectedCategory(args.filterCategories[0].id);
    }
  }, [args.filterCategories, selectedCategory]);

  return (
    <MultiLevelSelector
      {...args}
      selectedFilters={selectedFilters}
      onFilterChange={handleFilterChange}
      onResetAll={handleResetAll}
      onClearSelected={handleClearSelected}
      // New state management props
      selectedCategory={selectedCategory}
      searchQuery={searchQuery}
      filteredResults={filteredResults}
      isSearching={isSearching}
      onCategorySelect={setSelectedCategory}
      onSearchQueryChange={setSearchQuery}
      onOptionToggle={handleOptionToggle}
    />
  );
};

export const WithPreselectedFilters = (args) => (
  <StatefulMultiLevelSelector
    {...args}
    filterCategories={sampleFilterCategories}
    initialFilters={{
      "transaction-type": [
        { id: "acknowledged", label: "Acknowledged" },
        { id: "accepted", label: "Accepted" },
        { id: "completed", label: "Completed" },
        { id: "completed-hd", label: "Completed HD" },
      ],
      "ofe-order-status": [
        { id: "approved", label: "Approved" },
        { id: "shipped", label: "Shipped" },
      ],
      "order-type": [{ id: "express", label: "Express Order" }],
    }}
  />
);
