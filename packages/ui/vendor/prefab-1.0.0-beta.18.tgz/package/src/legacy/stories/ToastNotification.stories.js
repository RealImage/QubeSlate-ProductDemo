import { useRef } from "react";
import ToastNotification from "../components/ToastNotification";
import BaseButton from "../components/BaseButton";

export default {
  title: "Legacy/ToastNotification",
  component: ToastNotification,
  parameters: {
    docs: {
      description: {
        component:
          "A toast notification component that displays temporary messages with different intents and sizes.",
      },
    },
  },
  argTypes: {
    position: {
      control: {
        type: "select",
        options: ["top", "top-left", "top-right", "bottom", "bottom-left", "bottom-right"],
      },
      description: "Position of the toast notifications",
    },
  },
  args: {
    position: "top-right",
  },
};

// Demo component that shows how to use ToastNotification
const ToastDemo = ({ position }) => {
  const toastRef = useRef(null);

  const showToast = (intent, size = "large") => {
    const toastConfigs = {
      primary: {
        title: "Primary Toast",
        message: "This is a primary toast notification with additional message content.",
        intent: "primary",
      },
      success: {
        title: "Success Toast",
        message: "Operation completed successfully!",
        intent: "success",
      },
      danger: {
        title: "Error Toast",
        message: "Something went wrong. Please try again.",
        intent: "danger",
      },
      warning: {
        title: "Warning Toast",
        message: "Please review your input before proceeding.",
        intent: "warning",
      },
      reject: {
        title: "Reject Toast",
        message: "Action was rejected or cancelled.",
        intent: "reject",
      },
    };

    const config = toastConfigs[intent];
    if (config && toastRef.current) {
      toastRef.current.showToast({
        ...config,
        size,
      });
    }
  };

  const showSmallToast = (intent) => {
    showToast(intent, "small");
  };

  const showLargeToast = (intent) => {
    showToast(intent, "large");
  };

  const showActionToast = (intent) => {
    const toastConfigs = {
      danger: {
        title: "Prioritization Partially Failed",
        message: "Downloads for 4 of 11 selected theatres.",
        intent: "danger",
      },
      primary: {
        title: "Remediation Initiated",
        message: "Some theatres need your attention before proceeding.",
        intent: "primary",
      },
    };

    const config = toastConfigs[intent];
    if (config && toastRef.current) {
      toastRef.current.showToast({
        ...config,
        size: "large",
        timeout: 0,
        action: {
          label: "View Theatres",
          onClick: () => window.alert("Action button clicked"),
        },
      });
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ marginBottom: "20px" }}>
        <h3>Toast Notification Demo</h3>
        <p>Click the buttons below to show different types of toast notifications.</p>
      </div>

      <div style={{ marginBottom: "20px" }}>
        <h4>Large Toasts (with message)</h4>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <BaseButton
            buttonText="Primary"
            buttonType="primary"
            onClick={() => showLargeToast("primary")}
          />
          <BaseButton
            buttonText="Success"
            buttonType="success"
            onClick={() => showLargeToast("success")}
          />
          <BaseButton
            buttonText="Danger"
            buttonType="danger"
            onClick={() => showLargeToast("danger")}
          />
          <BaseButton
            buttonText="Warning"
            buttonType="warning"
            onClick={() => showLargeToast("warning")}
          />
          <BaseButton
            buttonText="Reject"
            buttonType="default"
            onClick={() => showLargeToast("reject")}
          />
        </div>
      </div>

      <div style={{ marginBottom: "20px" }}>
        <h4>Small Toasts (title only)</h4>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <BaseButton
            buttonText="Primary Small"
            buttonType="primary"
            buttonSize="small"
            onClick={() => showSmallToast("primary")}
          />
          <BaseButton
            buttonText="Success Small"
            buttonType="success"
            buttonSize="small"
            onClick={() => showSmallToast("success")}
          />
          <BaseButton
            buttonText="Danger Small"
            buttonType="danger"
            buttonSize="small"
            onClick={() => showSmallToast("danger")}
          />
          <BaseButton
            buttonText="Warning Small"
            buttonType="warning"
            buttonSize="small"
            onClick={() => showSmallToast("warning")}
          />
          <BaseButton
            buttonText="Reject Small"
            buttonType="default"
            buttonSize="small"
            onClick={() => showSmallToast("reject")}
          />
        </div>
        <div style={{ marginBottom: "20px" }}>
          <h4>Toasts with action button</h4>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <BaseButton
              buttonText="Danger + Action"
              buttonType="danger"
              onClick={() => showActionToast("danger")}
            />
            <BaseButton
              buttonText="Primary + Action"
              buttonType="primary"
              onClick={() => showActionToast("primary")}
            />
          </div>
        </div>
      </div>

      <ToastNotification ref={toastRef} position={position} />
    </div>
  );
};

export const Default = (args) => <ToastDemo {...args} />;

export const TopLeft = (args) => <ToastDemo {...args} position="top-left" />;
export const TopRight = (args) => <ToastDemo {...args} position="top-right" />;
export const BottomLeft = (args) => <ToastDemo {...args} position="bottom-left" />;
export const BottomRight = (args) => <ToastDemo {...args} position="bottom-right" />;
export const Top = (args) => <ToastDemo {...args} position="top" />;
export const Bottom = (args) => <ToastDemo {...args} position="bottom" />;
