import Collapse from "../components/Collapse";

const props = {
  isOpen: true,
  bodyContent: ["QubeCinema"],
  keepChildrenMounted: false,
  className: "",
  transitionDuration: undefined,
};

const style = {
  width: "100%",
  height: "100%",
  padding: "10px",
  border: "1px solid #e5e5e5",
  borderRadius: "3px",
};

/** Collapsible Card Component */
export default {
  title: "Legacy/CollapsibleCard",
  component: Collapse,
};

export const Default = () => {
  return (
    <Collapse {...props}>
      <p style={style}>Quick Brown Fox</p>
    </Collapse>
  );
};

export const Closed = () => {
  return (
    <Collapse {...{ ...props, isOpen: false }}>
      {" "}
      <p style={style}>Quick Brown Fox</p>
    </Collapse>
  );
};

export const WithCustomDuration = () => {
  return (
    <Collapse {...{ ...props, transitionDuration: 500 }}>
      {" "}
      <p style={style}>Quick Brown Fox</p>
    </Collapse>
  );
};
