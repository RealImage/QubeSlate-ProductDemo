import InputRadio from "../components/InputRadio";

/** InputRadio Component */
export default {
  title: "Legacy/InputRadio",
  component: InputRadio,
};

export const BasicRadio = () => (
  <InputRadio label="Label of Input Element" labelProps={{ className: "radio-btn" }} />
);

export const RadioWithElementLabel = () => (
  <InputRadio label={<input type="text" placeholder="Other reason" />} />
);
