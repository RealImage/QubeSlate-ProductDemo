import "@testing-library/jest-dom";

// Setup DOM elements that your components might need
const portalRoot = global.document.createElement("div");
portalRoot.setAttribute("id", "right-panel-portal");
const bpPortal = global.document.createElement("div");
bpPortal.setAttribute("class", "bp6-portal");
const body = global.document.querySelector("body");
body.appendChild(portalRoot);
body.appendChild(bpPortal);

// Console error handling for prop type validation
const originalConsoleError = console.error;

console.error = (message) => {
  // Fail tests on prop type errors. There's some required prop missing if you see this in stack trace!
  if (/(Failed prop type)/.test(message)) {
    throw new Error(message);
  }
  originalConsoleError(message);
};

// Mock timezone utility
jest.mock("./utils/getUserTimezone", () =>
  jest.fn(() => ({ zone: "Asia/Calcutta", offset: 330, abbr: "IST" })),
);
