import {
  Time,
  fromDate,
  getLocalTimeZone,
  parseTime,
  type DateValue,
} from "@internationalized/date";
import type { RangeValue } from "react-aria-components";

/** Parse a ISO 8601 time string to Time object. */
export function stringToTime(str?: string | null): Time | null | undefined {
  if (str === undefined) return undefined;
  if (!str) return null;

  try {
    const time = parseTime(str);
    return time;
  } catch {
    return null;
  }
}

/** Convert ISO 8601 date time string to DateValue. */
export function parseAriaDateTime(input?: string | null): DateValue | null | undefined {
  if (input === null || input === undefined) return input;

  const date = new Date(input);
  if (isNaN(date.getTime())) {
    return null;
  }

  return fromDate(date, getLocalTimeZone());
}

/** Convert ranged ISO 8601 date time string to RangeValue. */
export function parseAriaDateTimeRange(
  input?: { start: string; end: string } | null,
): RangeValue<DateValue> | null | undefined {
  if (input === null || input === undefined) return input;
  const startDate = parseAriaDateTime(input.start);
  const endDate = parseAriaDateTime(input.end);

  if (!startDate || !endDate) {
    return null;
  }

  return { start: startDate, end: endDate };
}

/** Convert DateValue to ISO 8601 string. e.g. "2026-05-03" */
export function dateValueToIsoString(dateValue: DateValue): string {
  return dateValue.toString().slice(0, 10);
}

export function defaultFormatDateValue(date: Date): string {
  const day = String(date.getDate()).padStart(2, "0");
  const month = date.toLocaleString("en-US", { month: "short" });
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
}

/** Convert a date string to Date. */
export function defaultParseDateValue(input: string): Date | null {
  return new Date(input);
}

/** Check if a date is valid. */
export function isValidDate(date: Date | undefined) {
  if (!date) {
    return false;
  }
  return !isNaN(date.getTime());
}
