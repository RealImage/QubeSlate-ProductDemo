import * as Icons from "./icon";
import preview from "#storybook/preview";

const ICON_LIST = Object.keys(Icons) as (keyof typeof Icons)[];
const DemoIcon = (props: React.ComponentProps<"svg"> & { icon?: keyof typeof Icons }) => {
  const IconComponent = props.icon ? Icons[props.icon] : null;
  return IconComponent ? <IconComponent {...props} /> : null;
};

const meta = preview.meta({
  title: "Icons/Icons",
  component: DemoIcon,
  args: {
    color: "black",
    width: 24,
    height: 24,
  },
});

export const Default = meta.story({
  render: ({ color, width, height }) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))",
        gap: "1.5rem",
      }}
    >
      {ICON_LIST.map((icon, index) => (
        <div key={index} style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ fontSize: "2rem" }}>
            <DemoIcon icon={icon} color={color} width={width} height={height} />
          </div>
          <div style={{ fontSize: "0.75rem", color: "#526273", fontWeight: 500 }}>{icon}</div>
        </div>
      ))}
    </div>
  ),
});
